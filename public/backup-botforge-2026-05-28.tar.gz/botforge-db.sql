--
-- PostgreSQL database dump
--

\restrict ccY4hWoKNeLPjmBBhMqkTbGCbr7O1jUTC2C1c8UH8Dv6qsiJoqe57pHpXNfi9u3

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- Name: AgentChat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AgentChat" (
    id text NOT NULL,
    "agentId" text NOT NULL,
    "conversationId" text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "resolvedAt" timestamp(3) without time zone
);


--
-- Name: BillingLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BillingLog" (
    id text NOT NULL,
    "companyId" text NOT NULL,
    month timestamp(3) without time zone NOT NULL,
    "tokensUsed" integer NOT NULL,
    amount double precision,
    paid boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Bot; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Bot" (
    id text NOT NULL,
    name text NOT NULL,
    "companyId" text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "systemPrompt" text,
    temperature double precision DEFAULT 0.7,
    "maxTokens" integer DEFAULT 2048,
    "useRag" boolean DEFAULT true NOT NULL,
    "ragChunkSize" integer DEFAULT 1000 NOT NULL,
    "ragChunkOverlap" integer DEFAULT 200 NOT NULL,
    "handoffTrigger" text DEFAULT 'auto'::text NOT NULL,
    "handoffKeywords" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ChatWidget; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ChatWidget" (
    id text NOT NULL,
    "botId" text NOT NULL,
    "companyId" text NOT NULL,
    "primaryColor" text DEFAULT '#00f0ff'::text NOT NULL,
    "backgroundColor" text DEFAULT '#0a0e1a'::text NOT NULL,
    "textColor" text DEFAULT '#ffffff'::text NOT NULL,
    "position" text DEFAULT 'bottom-right'::text NOT NULL,
    title text DEFAULT 'Need help?'::text NOT NULL,
    subtitle text DEFAULT 'Ask us anything'::text NOT NULL,
    "greetingMessage" text DEFAULT 'Hi! How can I help you today?'::text NOT NULL,
    "widgetCode" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Company; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Company" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    domain text,
    logo text,
    plan text DEFAULT 'starter'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "tokenLimit" integer DEFAULT 50000 NOT NULL,
    "tokensUsed" integer DEFAULT 0 NOT NULL,
    "billingMonth" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "aiProvider" text,
    "aiApiKey" text,
    "aiModel" text,
    "systemPrompt" text,
    temperature double precision DEFAULT 0.7,
    "maxTokens" integer DEFAULT 2048,
    "enableHumanHandoff" boolean DEFAULT true NOT NULL,
    "enableShopify" boolean DEFAULT false NOT NULL,
    "enableFacebook" boolean DEFAULT false NOT NULL,
    "enableInstagram" boolean DEFAULT false NOT NULL,
    "shopifyToken" text,
    "facebookToken" text,
    "instagramToken" text,
    "googleSheetId" text,
    "googleSheetRange" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Conversation" (
    id text NOT NULL,
    "companyId" text NOT NULL,
    "botId" text NOT NULL,
    channel text DEFAULT 'widget'::text NOT NULL,
    "customerName" text,
    "customerEmail" text,
    "customerId" text,
    status text DEFAULT 'active'::text NOT NULL,
    "agentId" text,
    "tokenCost" integer DEFAULT 0 NOT NULL,
    "messageCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: KnowledgeBase; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."KnowledgeBase" (
    id text NOT NULL,
    name text NOT NULL,
    type text DEFAULT 'document'::text NOT NULL,
    "botId" text NOT NULL,
    "companyId" text NOT NULL,
    "fileName" text,
    "fileUrl" text,
    "fileSize" integer,
    "fileType" text,
    "qaData" text,
    "sourceUrl" text,
    "chunkCount" integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    source text,
    metadata text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    email text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PlatformSetting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PlatformSetting" (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    name text,
    password text,
    image text,
    role text DEFAULT 'company_admin'::text NOT NULL,
    "companyId" text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: VerificationToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VerificationToken" (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Account" (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- Data for Name: AgentChat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AgentChat" (id, "agentId", "conversationId", status, "joinedAt", "resolvedAt") FROM stdin;
cmpnkltbr0003uu5nzjhyo0v2	cmpn21mz20003105ol5l8xyjw	cmpn5aixt0011tex1kcpzkra8	resolved	2026-05-27 04:35:00.663	2026-05-27 04:35:04.764
cmpnzsvw5000bnr56rv2khhnq	cmpn21mz20003105ol5l8xyjw	cmpnzsuro0001nr56ze1we4qc	active	2026-05-27 11:40:24.822	\N
cmpnzxfg2001pnr5655inqxkk	cmpn21mz20003105ol5l8xyjw	cmpnzxeej001fnr56xzefo5fj	active	2026-05-27 11:43:56.786	\N
cmpnzz1u70025nr56sr0hp578	cmpn21mz20003105ol5l8xyjw	cmpnzz0w6001vnr56g42oosqr	active	2026-05-27 11:45:12.464	\N
cmpo01dqy003fnr56w2tmjmbb	cmpn21mz20003105ol5l8xyjw	cmpo01cl90037nr56e9qhp204	active	2026-05-27 11:47:01.211	\N
cmpo029u0003rnr56xkmixeew	cmpn21mz20003105ol5l8xyjw	cmpo025x2003jnr56f12ldk4y	active	2026-05-27 11:47:42.793	\N
cmpp1x17l001ltdruqu1bkh9z	cmpnyqwnx0001wutrystfl3fg	cmpojd25b000ntdru4n18y0wk	resolved	2026-05-28 05:27:23.745	2026-05-28 05:45:35.526
cmpp1wwpg001htdruq75qvbk2	cmpnyqwnx0001wutrystfl3fg	cmpojejlh0019tdru8mqhwjty	resolved	2026-05-28 05:27:17.908	2026-05-28 05:45:40.678
cmpo0q3w7001lqd4cgt1gs1xq	cmpnyqwnx0001wutrystfl3fg	cmpo0m4gi000dj2fdhz837nf5	resolved	2026-05-27 12:06:14.839	2026-05-28 05:46:00.101
cmpo0qv720021qd4coyftqeax	cmpnyqwnx0001wutrystfl3fg	cmpo0qa8l001pqd4cryk8dev0	resolved	2026-05-27 12:06:50.222	2026-05-27 12:07:05.243
cmpojaav60009tdrufw9igao5	cmpn21mz20003105ol5l8xyjw	cmpoimq2x0001tdrurr0h5dxa	active	2026-05-27 20:45:50.082	\N
cmpojcegt000ftdruzfprhki5	cmpn21mz20003105ol5l8xyjw	cmpoiiuct002nqd4c8fedhf06	active	2026-05-27 20:47:28.061	\N
cmpojdyuq0013tdru8i4inwce	cmpn21mz20003105ol5l8xyjw	cmpojdoip000vtdru7ubzv2o0	active	2026-05-27 20:48:41.139	\N
cmpp222wb002jtdruls8zo8pg	cmpn21mz20003105ol5l8xyjw	cmpp21q9u002btdruz4rzgpp8	active	2026-05-28 05:31:19.212	\N
cmpp24auk002xtdru4t0oqfyf	cmpn21mz20003105ol5l8xyjw	cmpp248ae002ptdru37hosng8	active	2026-05-28 05:33:02.829	\N
cmpp26dzp000fyzqx3nkc874n	cmpn21mz20003105ol5l8xyjw	cmpp26bxl0007yzqx1ojap9ke	resolved	2026-05-28 05:34:40.213	2026-05-28 05:34:53.435
cmpo0pwur001hqd4cppm49h82	cmpnyqwnx0001wutrystfl3fg	cmpo0m56q000lj2fdmck8isie	resolved	2026-05-27 12:06:05.715	2026-05-28 05:46:09.442
cmpo0psdc001dqd4c7l1irf70	cmpnyqwnx0001wutrystfl3fg	cmpo0m61y000tj2fd03hs3lyf	resolved	2026-05-27 12:05:59.905	2026-05-28 05:46:18.874
cmpo0pn6f0019qd4cpakthqky	cmpnyqwnx0001wutrystfl3fg	cmpo0o48v0001qd4csziv48e7	resolved	2026-05-27 12:05:53.175	2026-05-28 05:46:25.084
cmpo0pjzo0015qd4c61bvkz0m	cmpnyqwnx0001wutrystfl3fg	cmpo0o5gj0009qd4ccn15l6zc	resolved	2026-05-27 12:05:49.044	2026-05-28 05:46:32.579
cmpp2im4l0009t1pqy4os6g9a	cmpnyqwnx0001wutrystfl3fg	cmpp2ifsr0001t1pq2e2ih66z	resolved	2026-05-28 05:44:10.629	2026-05-28 05:44:34.139
cmpp2d5ne000vyzqxm0l312cy	cmpnyqwnx0001wutrystfl3fg	cmpp2cv9z000nyzqxj8hppavh	resolved	2026-05-28 05:39:55.994	2026-05-28 05:44:39.445
cmpnz0ppn000193pw33hrefmp	cmpnyqwnx0001wutrystfl3fg	cmpn5aixt0011tex1kcpzkra8	resolved	2026-05-27 11:18:30.443	2026-05-28 05:44:47.913
cmpnz0x5f000h93pwmf3vv5nu	cmpnyqwnx0001wutrystfl3fg	cmpnz0pzl000593pwgfzj7c94	resolved	2026-05-27 11:18:40.084	2026-05-28 05:44:53.373
cmpnzl277001110l1csq81y6i	cmpnyqwnx0001wutrystfl3fg	cmpnzkfyq000p10l1lkrgtqfa	resolved	2026-05-27 11:34:19.747	2026-05-28 05:45:01.264
cmpnzlji5001510l1tyxcr367	cmpnyqwnx0001wutrystfl3fg	cmpnzjv16000110l1j9cn5eix	resolved	2026-05-27 11:34:42.173	2026-05-28 05:45:04.746
cmpnzprzw0001x0d2v9oatqs9	cmpnyqwnx0001wutrystfl3fg	cmpnzjw5o000910l13txvc147	resolved	2026-05-27 11:37:59.804	2026-05-28 05:45:07.346
cmpnzvdte0017nr562arcw0wa	cmpnyqwnx0001wutrystfl3fg	cmpnzv8qa000znr56kihwmfh2	resolved	2026-05-27 11:42:21.362	2026-05-28 05:45:09.483
cmpp1xs650025tdru8vmxqcxv	cmpnyqwnx0001wutrystfl3fg	cmpp1xfvh001ttdrup96rzsr0	resolved	2026-05-28 05:27:58.686	2026-05-28 05:45:21.256
cmpp1x52z001ptdrumcpq85n8	cmpnyqwnx0001wutrystfl3fg	cmpoihtlw002fqd4ckmayyry6	resolved	2026-05-28 05:27:28.763	2026-05-28 05:45:30.375
cmpo0phhf0011qd4cwydo02gk	cmpnyqwnx0001wutrystfl3fg	cmpo0o6ez000hqd4cnzzb983a	resolved	2026-05-27 12:05:45.795	2026-05-28 05:46:35.745
cmpo0peku000xqd4cbui5miy5	cmpnyqwnx0001wutrystfl3fg	cmpo0odij000pqd4cs3pfqmt9	resolved	2026-05-27 12:05:42.03	2026-05-28 05:46:42.692
cmpo03jja004hnr56bsxqaoa1	cmpnyqwnx0001wutrystfl3fg	cmpo03dk20049nr56gb5mx307	resolved	2026-05-27 11:48:42.022	2026-05-28 05:46:47.714
cmpo035fp0045nr56vwtggkv9	cmpnyqwnx0001wutrystfl3fg	cmpo00kxr002pnr56ruv6t4k8	resolved	2026-05-27 11:48:23.749	2026-05-28 05:46:56.755
cmpo0315j0041nr56sooepa37	cmpnyqwnx0001wutrystfl3fg	cmpo00oua002xnr5665pie7cd	resolved	2026-05-27 11:48:18.199	2026-05-28 05:47:05.008
cmpo02x2o003xnr56le78eue5	cmpnyqwnx0001wutrystfl3fg	cmpnzzqf5002bnr568dr9gj4d	resolved	2026-05-27 11:48:12.913	2026-05-28 05:47:10.669
cmpnzqj84000hx0d2m87iehru	cmpnyqwnx0001wutrystfl3fg	cmpnzq44u0005x0d27ptk6pr0	resolved	2026-05-27 11:38:35.092	2026-05-28 05:47:45.098
cmpnzlp05001l10l1ie1abfk5	cmpnyqwnx0001wutrystfl3fg	cmpnzjxap000h10l14enqacrw	resolved	2026-05-27 11:34:49.301	2026-05-28 05:47:50.153
cmpp2uald002pt1pq4qwpkxr4	cmpn21mz20003105ol5l8xyjw	cmpp2u8rn002ht1pqb6xubaag	active	2026-05-28 05:53:15.553	\N
cmpp2w19u003ht1pqa08r6cg5	cmpn21mz20003105ol5l8xyjw	cmpp2vxa40039t1pqyli5adk4	active	2026-05-28 05:54:36.786	\N
cmpp6tyot000df4c5ed78qili	cmpnyqwnx0001wutrystfl3fg	cmpp6svmb0001f4c5xhd7bhjk	resolved	2026-05-28 07:44:58.589	2026-05-28 07:47:55.369
cmpp33m30003nt1pqz76cxb0b	cmpnyqwnx0001wutrystfl3fg	cmpp2vfll0031t1pq9rg3hba7	resolved	2026-05-28 06:00:30.348	2026-05-28 06:00:44.155
cmpp3k1710053t1pq8i2wzi05	cmpn21mz20003105ol5l8xyjw	cmpp3jz1p004vt1pqvxfi2zcr	active	2026-05-28 06:13:16.429	\N
cmpp3kfku005ht1pqa8tihjw8	cmpn21mz20003105ol5l8xyjw	cmpp3kd6i0059t1pqssibnnxd	active	2026-05-28 06:13:35.07	\N
cmpp3xgub006pt1pqyb30qpl5	cmpn21mz20003105ol5l8xyjw	cmpp3xcwe006ht1pqurdr7oqd	active	2026-05-28 06:23:43.236	\N
cmpp3zn0p0073t1pq0ylgskhr	cmpn21mz20003105ol5l8xyjw	cmpp3zj41006vt1pqtigruxju	active	2026-05-28 06:25:24.553	\N
cmpp3517g004pt1pq7q7r6eek	cmpnyqwnx0001wutrystfl3fg	cmpp341o4003xt1pq30jb8w0k	resolved	2026-05-28 06:01:36.605	2026-05-28 06:26:57.3
cmpp3s4ux005zt1pqh82dh7za	cmpnyqwnx0001wutrystfl3fg	cmpp3rkh5005nt1pqgjuvl7qb	resolved	2026-05-28 06:19:34.425	2026-05-28 06:27:00.863
cmpp42i0o007jt1pqeiusls8s	cmpn21mz20003105ol5l8xyjw	cmpp3wm900069t1pql2u9fr1o	resolved	2026-05-28 06:27:38.04	2026-05-28 06:28:00.819
cmpp43f7y0083t1pqvgdqztdr	cmpnyqwnx0001wutrystfl3fg	cmpp438qe007vt1pqrs77fhxb	active	2026-05-28 06:28:21.07	\N
cmpp4t4f100096q21iexyevkj	cmpn21mz20003105ol5l8xyjw	cmpp4t0jl00016q2124xzauzi	active	2026-05-28 06:48:20.125	\N
cmpp4w6ml000n6q2125hktxv0	cmpn21mz20003105ol5l8xyjw	cmpp4w06y000f6q21sryahue7	active	2026-05-28 06:50:42.957	\N
cmpp7r49i000b111xtruqllc2	cmpn21mz20003105ol5l8xyjw	cmpp6svmb0001f4c5xhd7bhjk	resolved	2026-05-28 08:10:45.462	2026-05-28 08:12:09.775
\.


--
-- Data for Name: BillingLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BillingLog" (id, "companyId", month, "tokensUsed", amount, paid, "createdAt") FROM stdin;
\.


--
-- Data for Name: Bot; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Bot" (id, name, "companyId", active, "systemPrompt", temperature, "maxTokens", "useRag", "ragChunkSize", "ragChunkOverlap", "handoffTrigger", "handoffKeywords", "createdAt", "updatedAt") FROM stdin;
bot_support	BotForge AI	cmpn_support	t	You are BotForge Support Assistant — an AI chatbot platform called BotForge ("Forge your AI. Connect your world.").\n\nYour job: help visitors understand BotForge features, pricing (Free/€49 Pro/€149 Enterprise/Custom), integrations (website widget, Shopify, Facebook Messenger, Instagram), AI capabilities (DeepSeek-powered, RAG, custom knowledge base), Agent Panel for human handoff, and token-based billing. Be concise, friendly, and helpful. If you don't know the answer, suggest they contact hello@benzos.uk.	0.7	1024	f	1000	200	auto	\N	2026-05-26 20:54:04.41	2026-05-26 20:54:04.41
cmpnkg2dt00053jan70fws8yc	Demo Support Bot	cmpn21muo0001105o9aefgepi	t	You are a helpful customer support assistant for Demo Company.	0.7	2048	t	1000	200	auto	\N	2026-05-27 04:30:32.465	2026-05-27 04:30:32.465
cmpnkidsx000bhf9jve2qrflc	Test Company Subagent Bot	cmpnkidsk0007hf9ja8uxgeb2	t	You are a helpful customer support assistant for Test Company Subagent. Be friendly and concise.	0.7	2048	t	1000	200	auto	\N	2026-05-27 04:32:20.577	2026-05-27 04:32:20.577
cmpn21mzw0005105obvhtmm61	Alfred	cmpn21muo0001105o9aefgepi	t	შენ ხარ მეგობრული ასისტენტი, რომელიც მარტივად და მოკლედ, მაგრამ სრულყოფილად პასუხობს კითხვებს	0.7	2048	t	1000	200	auto	\N	2026-05-26 19:55:26.252	2026-05-27 05:17:57.232
\.


--
-- Data for Name: ChatWidget; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ChatWidget" (id, "botId", "companyId", "primaryColor", "backgroundColor", "textColor", "position", title, subtitle, "greetingMessage", "widgetCode", "createdAt", "updatedAt") FROM stdin;
widget_support	bot_support	cmpn_support	#00f0ff	#0a0e1a	#ffffff	bottom-right	BotForge AI	Ask about the platform	Hey! Got questions about BotForge?	botforge-support	2026-05-26 20:54:07.163	2026-05-26 20:54:07.163
cmpnkidt3000ehf9jsuzkkul9	cmpnkidsx000bhf9jve2qrflc	cmpnkidsk0007hf9ja8uxgeb2	#00f0ff	#0a0e1a	#ffffff	bottom-right	Need help?	Ask us about Test Company Subagent	Hi there! How can I help you today?	cmpnkidt3000fhf9j31c7gxhe	2026-05-27 04:32:20.583	2026-05-27 04:32:20.583
cmpn21n0d0008105ohvzcgqm3	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	#00f0ff	#0a0e1a	#ffffff	bottom-right	Need help?	Ask us anything about our products	Hi there! How can I help you today?	demo-company-widget	2026-05-26 19:55:26.27	2026-05-26 19:55:26.27
\.


--
-- Data for Name: Company; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Company" (id, name, slug, domain, logo, plan, active, "tokenLimit", "tokensUsed", "billingMonth", "aiProvider", "aiApiKey", "aiModel", "systemPrompt", temperature, "maxTokens", "enableHumanHandoff", "enableShopify", "enableFacebook", "enableInstagram", "shopifyToken", "facebookToken", "instagramToken", "googleSheetId", "googleSheetRange", "createdAt", "updatedAt") FROM stdin;
cmpn_support	BotForge Support	botforge-support	\N	\N	starter	t	1000000	6820	2026-05-26 20:54:01.542	\N	\N	\N	You are a helpful BotForge assistant.	0.7	2048	t	f	f	f	\N	\N	\N	\N	\N	2026-05-26 20:54:01.542	2026-05-28 06:13:16.259
cmpn21muo0001105o9aefgepi	Demo Company	demo	\N	\N	business	t	250000	1528530	2026-05-26 19:55:26.064	\N	\N	\N	You are a helpful AI assistant for Demo Company. Answer questions based on the provided knowledge base.	0.7	2048	t	f	f	f	\N	\N	\N	\N	\N	2026-05-26 19:55:26.064	2026-05-28 08:09:46.99
cmpnkidsk0007hf9ja8uxgeb2	Test Company Subagent	test-company-subagent-mpnkidfx	\N	\N	starter	t	50000	0	2026-05-27 04:32:20.564	\N	\N	\N	You are a helpful AI assistant for Test Company Subagent. Answer questions based on the provided knowledge base. If you don't know, say you don't know.	0.7	2048	t	f	f	f	\N	\N	\N	\N	\N	2026-05-27 04:32:20.564	2026-05-27 04:32:20.564
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Conversation" (id, "companyId", "botId", channel, "customerName", "customerEmail", "customerId", status, "agentId", "tokenCost", "messageCount", "createdAt", "updatedAt") FROM stdin;
cmpnmomft000z1p6qlousvl7j	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	29951	4	2026-05-27 05:33:10.937	2026-05-27 05:33:23.274
cmpn31nkj0001syhu8n22vyq2	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	603	6	2026-05-26 20:23:26.61	2026-05-26 20:26:08.929
cmpn4lejj0007k7m1aqoah29v	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	1322	8	2026-05-26 21:06:47.647	2026-05-26 21:07:20.109
cmpn4o97c0001kp4yykib1ear	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	298	2	2026-05-26 21:09:00.696	2026-05-26 21:09:02.867
cmpn35lbn000jsyhufxyh45pq	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	3409	10	2026-05-26 20:26:30.323	2026-05-26 20:29:10.365
cmpn4qfr70001rcnoyy7qff4m	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	5799	2	2026-05-26 21:10:42.5	2026-05-26 21:10:44.057
cmpnmq8c00001y6mpt6g6d3ba	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	15131	2	2026-05-27 05:34:25.968	2026-05-27 05:34:30.098
cmpn3b6aq0019syhu3niwe52u	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	1543	8	2026-05-26 20:30:50.786	2026-05-26 20:31:31.436
cmpn3svak0001pmd4pgmx31b0	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	203	2	2026-05-26 20:44:36.333	2026-05-26 20:44:37.43
cmpn3t6ia0007pmd4cib6btp2	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	166	2	2026-05-26 20:44:50.866	2026-05-26 20:44:51.834
cmpn3u1u7000112njh3tgjunt	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	154	2	2026-05-26 20:45:31.471	2026-05-26 20:45:32.282
cmpn401uv0001ylri3pbdw348	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	612	4	2026-05-26 20:50:11.431	2026-05-26 20:50:22.913
cmpn41jd6000bylris3daj9gq	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	462	2	2026-05-26 20:51:20.778	2026-05-26 20:51:23.48
cmpn45shs0001935nrfx5hazz	cmpn_support	bot_support	widget	\N	\N	\N	active	\N	662	2	2026-05-26 20:54:39.232	2026-05-26 20:54:43.958
cmpn4r2780007rcnovc8op8st	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	23560	8	2026-05-26 21:11:11.589	2026-05-26 21:12:07.609
cmpn4uslo000btvm672fndozo	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	11599	4	2026-05-26 21:14:05.773	2026-05-26 21:14:22.597
cmpn46hbj0007935nsoq0mzrt	cmpn_support	bot_support	widget	\N	\N	\N	active	\N	4298	12	2026-05-26 20:55:11.407	2026-05-26 20:57:09.796
cmpn4b31i000x935njp8nift5	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	530	4	2026-05-26 20:58:46.182	2026-05-26 20:59:01.096
cmpnm37h30001e6dokvsnec8t	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	29369	4	2026-05-27 05:16:31.766	2026-05-27 05:16:43.838
cmpn4d03m0019935ni1wb32cz	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	1261	6	2026-05-26 21:00:15.682	2026-05-26 21:00:43.644
cmpnn12vk00011qbjvxxf3yfz	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14826	2	2026-05-27 05:42:52.112	2026-05-27 05:42:55.612
cmpn4gaaj001t935nj6bhbf3o	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	554	4	2026-05-26 21:02:48.859	2026-05-26 21:02:59.563
cmpn4jeo70001k7m19vc97tau	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	160	2	2026-05-26 21:05:14.503	2026-05-26 21:05:15.436
cmpnm58o6000de6dow0fd8423	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	29439	4	2026-05-27 05:18:06.63	2026-05-27 05:18:13.499
cmpn4zkjh000ntvm6i6weziou	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	23273	8	2026-05-26 21:17:48.605	2026-05-26 21:18:29.54
cmpnmc79l00011p6q5mzb3r4k	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	29846	4	2026-05-27 05:23:31.401	2026-05-27 05:23:40.041
cmpnmerc3000b1p6q6wkhy63k	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	14687	2	2026-05-27 05:25:30.723	2026-05-27 05:25:31.906
cmpn56c020001tex1x297jvex	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	36408	12	2026-05-26 21:23:04.13	2026-05-26 21:24:32.234
cmpn59wgh000rtex1ydaeez52	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	11758	4	2026-05-26 21:25:50.609	2026-05-26 21:26:07.647
cmpnmevxa000h1p6q1184wl5r	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	15099	2	2026-05-27 05:25:36.67	2026-05-27 05:25:41.046
cmpnms22m0007y6mpvwk4qmue	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	44722	6	2026-05-27 05:35:51.166	2026-05-27 05:36:16.25
cmpnmg057000n1p6qrcqzquzh	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	15174	2	2026-05-27 05:26:28.795	2026-05-27 05:26:33.503
cmpnmhur4000t1p6quvm28x19	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	active	\N	15052	2	2026-05-27 05:27:55.12	2026-05-27 05:27:58.604
cmpnn15ov00071qbjx7rmgzih	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14801	2	2026-05-27 05:42:55.76	2026-05-27 05:42:58.754
cmpnmt9ld000ly6mp5mgmkpbr	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	15046	2	2026-05-27 05:36:47.569	2026-05-27 05:36:52.683
cmpnmvprv0001u2rasgaih3a4	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	15089	2	2026-05-27 05:38:41.851	2026-05-27 05:38:47.157
cmpnn217g000113e3rxvkyuhc	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14747	2	2026-05-27 05:43:36.605	2026-05-27 05:43:39.441
cmpnmxhmm0007u2ra91ntklwj	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	61721	8	2026-05-27 05:40:04.598	2026-05-27 05:41:20.15
cmpnn23iv000713e3bo08lmu2	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	15132	2	2026-05-27 05:43:39.607	2026-05-27 05:43:44.423
cmpnn2iep000d13e30g7rmkyl	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14629	2	2026-05-27 05:43:58.897	2026-05-27 05:44:00.489
cmpnn8z4y001113e3p8dlwefa	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14687	2	2026-05-27 05:49:00.514	2026-05-27 05:49:02.593
cmpnn912v001713e3mpso7esq	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	15078	2	2026-05-27 05:49:03.031	2026-05-27 05:49:07.431
cmpnn52st000j13e3lwwrdxq6	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	62724	8	2026-05-27 05:45:58.637	2026-05-27 05:47:07.377
cmpnncja3001n13e3is3r38f9	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14691	2	2026-05-27 05:51:46.587	2026-05-27 05:51:48.601
cmpnnb28h001d13e3vwbxsp1t	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	30135	4	2026-05-27 05:50:37.842	2026-05-27 05:51:06.417
cmpnndvnl0001qu8jxoees8hu	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14689	2	2026-05-27 05:52:49.281	2026-05-27 05:52:52.692
cmpnndyc90007qu8jswd350p9	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14612	2	2026-05-27 05:52:52.761	2026-05-27 05:52:54.719
cmpnndzwn000dqu8j4nfif3mt	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	15031	2	2026-05-27 05:52:54.791	2026-05-27 05:53:00.153
cmpnnfasg000jqu8jki0qiw9d	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	59504	8	2026-05-27 05:53:55.552	2026-05-27 05:54:50.384
cmpnnji4h0001q910rex6uajb	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14678	2	2026-05-27 05:57:11.681	2026-05-27 05:57:13.574
cmpnnjorn0007q9109xla6rr6	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14689	2	2026-05-27 05:57:20.292	2026-05-27 05:57:22.227
cmpnnjqb4000dq9106cp6k8j5	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14925	2	2026-05-27 05:57:22.289	2026-05-27 05:57:25.632
cmpnnjsye000jq910sjpmole9	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	14632	2	2026-05-27 05:57:25.718	2026-05-27 05:57:27.102
cmpnywj0t0003wutryxu8ji9v	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	active	\N	12420	4	2026-05-27 11:15:15.15	2026-05-27 11:15:25.252
cmpnnkqe1000pq910krgkntwc	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	74836	10	2026-05-27 05:58:09.049	2026-05-27 05:59:27.297
cmpnz0pzl000593pwgfzj7c94	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6217	2	2026-05-27 11:18:30.802	2026-05-28 05:44:53.368
cmpnzzuc2002jnr56jy1o8ht8	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	6272	2	2026-05-27 11:45:49.394	2026-05-27 11:45:50.349
cmpnzjw5o000910l13txvc147	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6291	2	2026-05-27 11:33:25.261	2026-05-28 05:45:07.301
cmpo025x2003jnr56f12ldk4y	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6280	3	2026-05-27 11:47:37.719	2026-05-28 05:47:16.66
cmpnnsaem0001mzccjn17jnso	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	37674	12	2026-05-27 06:04:01.582	2026-05-27 06:05:49.937
cmpnnv86l000rmzccq9iu360l	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	6012	2	2026-05-27 06:06:18.669	2026-05-27 06:06:20.61
cmpoihtlw002fqd4ckmayyry6	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6297	2	2026-05-27 20:23:41.348	2026-05-28 05:45:30.371
cmpnnzcd4000zmzccvggggpfq	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	18367	6	2026-05-27 06:09:30.712	2026-05-27 06:09:47.857
cmpnzv8qa000znr56kihwmfh2	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6233	4	2026-05-27 11:42:14.77	2026-05-28 05:45:09.478
cmpnzkfyq000p10l1lkrgtqfa	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	12517	4	2026-05-27 11:33:50.931	2026-05-28 05:45:01.251
cmpno1x0y001fmzccp61q8aa8	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	test	\N	\N	\N	active	\N	25105	8	2026-05-27 06:11:30.802	2026-05-27 06:12:20.305
cmpnzexhq000t93pwpqay9vv2	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	active	\N	12463	4	2026-05-27 11:29:33.71	2026-05-27 11:29:49.892
cmpnzzqf5002bnr568dr9gj4d	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6280	2	2026-05-27 11:45:44.32	2026-05-28 05:47:10.66
cmpnu3hw8000112bh1wzxbicq	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	active	\N	60441	18	2026-05-27 09:00:42.2	2026-05-27 09:02:47.47
cmpnzjxap000h10l14enqacrw	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6280	2	2026-05-27 11:33:26.737	2026-05-28 05:47:50.144
cmpo00oua002xnr5665pie7cd	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6271	2	2026-05-27 11:46:28.93	2026-05-28 05:47:04.99
cmpnx45mv0001arcfdjnlbqd4	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	active	\N	26021	8	2026-05-27 10:25:11.81	2026-05-27 10:27:31.933
cmpnzsuro0001nr56ze1we4qc	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6279	3	2026-05-27 11:40:23.364	2026-05-28 05:47:41.254
cmpnzjv16000110l1j9cn5eix	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6296	2	2026-05-27 11:33:23.777	2026-05-28 05:45:04.727
cmpnzq44u0005x0d27ptk6pr0	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	12522	4	2026-05-27 11:38:15.534	2026-05-28 05:47:45.091
cmpnzxeej001fnr56xzefo5fj	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6276	3	2026-05-27 11:43:55.436	2026-05-28 05:47:34.735
cmpnztxit000hnr56k36pett9	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	active	\N	25169	8	2026-05-27 11:41:13.589	2026-05-27 11:41:53.288
cmpnzz0w6001vnr56g42oosqr	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6280	3	2026-05-27 11:45:11.238	2026-05-28 05:47:30.215
cmpo03dk20049nr56gb5mx307	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6228	3	2026-05-27 11:48:34.274	2026-05-28 05:46:47.698
cmpo0m56q000lj2fdmck8isie	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6288	2	2026-05-27 12:03:09.891	2026-05-28 05:46:09.433
cmpo00kxr002pnr56ruv6t4k8	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6281	2	2026-05-27 11:46:23.871	2026-05-28 05:46:56.744
cmpo01cl90037nr56e9qhp204	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6293	2	2026-05-27 11:46:59.709	2026-05-28 05:47:21.505
cmpo0lsgf0001j2fdg7eaxc4j	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	6301	2	2026-05-27 12:02:53.391	2026-05-27 12:02:55.2
cmpo0m36o0007j2fdpumomud3	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	6297	2	2026-05-27 12:03:07.296	2026-05-27 12:03:08.72
cmpo0o48v0001qd4csziv48e7	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6294	2	2026-05-27 12:04:41.983	2026-05-28 05:46:25.079
cmpo0m61y000tj2fd03hs3lyf	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6278	2	2026-05-27 12:03:11.014	2026-05-28 05:46:18.868
cmpo0o6ez000hqd4cnzzb983a	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6285	2	2026-05-27 12:04:44.795	2026-05-28 05:46:35.739
cmpo0o5gj0009qd4ccn15l6zc	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6282	2	2026-05-27 12:04:43.555	2026-05-28 05:46:32.549
cmpo0odij000pqd4cs3pfqmt9	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6297	2	2026-05-27 12:04:53.996	2026-05-28 05:46:42.679
cmpo0qa8l001pqd4cryk8dev0	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	12479	5	2026-05-27 12:06:23.061	2026-05-27 12:07:05.22
cmpn5aixt0011tex1kcpzkra8	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	test	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	5824	3	2026-05-26 21:26:19.745	2026-05-28 05:44:47.907
cmpo0m4gi000dj2fdhz837nf5	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6280	2	2026-05-27 12:03:08.946	2026-05-28 05:46:00.09
cmpoiiuct002nqd4c8fedhf06	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6297	3	2026-05-27 20:24:28.973	2026-05-28 05:45:50.164
cmpp3wm900069t1pql2u9fr1o	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6296	2	2026-05-28 06:23:03.588	2026-05-28 06:28:00.813
cmpp2vfll0031t1pq9rg3hba7	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6296	2	2026-05-28 05:54:08.697	2026-05-28 06:00:44.131
cmpp6svmb0001f4c5xhd7bhjk	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	25645	17	2026-05-28 07:44:07.955	2026-05-28 08:12:09.741
cmpp438qe007vt1pqrs77fhxb	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6232	3	2026-05-28 06:28:12.663	2026-05-28 06:33:58.202
cmpp2ifsr0001t1pq2e2ih66z	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6228	3	2026-05-28 05:44:02.427	2026-05-28 05:44:34.134
cmpp2cv9z000nyzqxj8hppavh	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6232	3	2026-05-28 05:39:42.55	2026-05-28 05:44:39.441
cmpp1xfvh001ttdrup96rzsr0	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	12502	5	2026-05-28 05:27:42.75	2026-05-28 05:45:21.251
cmpojd25b000ntdru4n18y0wk	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6301	2	2026-05-27 20:47:58.752	2026-05-28 05:45:35.519
cmpojejlh0019tdru8mqhwjty	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	6282	2	2026-05-27 20:49:08.022	2026-05-28 05:45:40.675
cmpojdoip000vtdru7ubzv2o0	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6297	3	2026-05-27 20:48:27.745	2026-05-28 05:45:45.077
cmpp21q9u002btdruz4rzgpp8	cmpn_support	bot_support	widget	\N	\N	\N	handoff_active	cmpn21mz20003105ol5l8xyjw	260	3	2026-05-28 05:31:02.85	2026-05-28 05:31:21.916
cmpoimq2x0001tdrurr0h5dxa	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6297	3	2026-05-27 20:27:30.057	2026-05-28 05:45:55.425
cmpp248ae002ptdru37hosng8	cmpn_support	bot_support	widget	\N	\N	\N	handoff_active	cmpn21mz20003105ol5l8xyjw	341	3	2026-05-28 05:32:59.511	2026-05-28 05:33:06.729
cmpp266fa0001yzqx5jr6r0dh	cmpn_support	bot_support	widget	\N	\N	\N	active	\N	221	2	2026-05-28 05:34:30.405	2026-05-28 05:34:31.355
cmpp2u8rn002ht1pqb6xubaag	cmpn_support	bot_support	widget	\N	\N	\N	handoff_active	cmpn21mz20003105ol5l8xyjw	316	3	2026-05-28 05:53:13.187	2026-05-28 05:53:15.68
cmpp26bxl0007yzqx1ojap9ke	cmpn_support	bot_support	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	359	3	2026-05-28 05:34:37.546	2026-05-28 05:34:53.43
cmpp2uxlw002vt1pq3v3ml565	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	active	\N	6298	2	2026-05-28 05:53:45.38	2026-05-28 05:53:46.523
cmpp3jz1p004vt1pqvxfi2zcr	cmpn_support	bot_support	widget	\N	\N	\N	handoff_active	cmpn21mz20003105ol5l8xyjw	363	3	2026-05-28 06:13:13.645	2026-05-28 06:13:16.543
cmpp3zj41006vt1pqtigruxju	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6296	3	2026-05-28 06:25:19.489	2026-05-28 06:26:50.653
cmpp3xcwe006ht1pqurdr7oqd	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6296	3	2026-05-28 06:23:38.126	2026-05-28 06:26:53.337
cmpp2vxa40039t1pqyli5adk4	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6293	3	2026-05-28 05:54:31.612	2026-05-28 06:00:35.878
cmpp3kd6i0059t1pqssibnnxd	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6293	3	2026-05-28 06:13:31.963	2026-05-28 06:26:55.315
cmpp341o4003xt1pq30jb8w0k	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	37877	13	2026-05-28 06:00:50.548	2026-05-28 06:26:57.295
cmpp3rkh5005nt1pqgjuvl7qb	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpnyqwnx0001wutrystfl3fg	12498	7	2026-05-28 06:19:08.01	2026-05-28 06:27:00.853
cmpp4awsv008bt1pqdpb1jphz	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	\N	6231	4	2026-05-28 06:34:10.447	2026-05-28 06:44:53.903
cmpp4w06y000f6q21sryahue7	cmpn21muo0001105o9aefgepi	cmpnkg2dt00053jan70fws8yc	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6231	4	2026-05-28 06:50:34.618	2026-05-28 07:48:04.576
cmpp4t0jl00016q2124xzauzi	cmpn21muo0001105o9aefgepi	cmpn21mzw0005105obvhtmm61	widget	\N	\N	\N	closed	cmpn21mz20003105ol5l8xyjw	6296	3	2026-05-28 06:48:15.105	2026-05-28 07:48:06.951
\.


--
-- Data for Name: KnowledgeBase; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."KnowledgeBase" (id, name, type, "botId", "companyId", "fileName", "fileUrl", "fileSize", "fileType", "qaData", "sourceUrl", "chunkCount", active, "createdAt", "updatedAt") FROM stdin;
cmpn4g0xv001r935ndbfqghxt	Karcher	crawl	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	\N	\N	\N	\N	[{"question":"Website content from Karcher","answer":"Cleaning equipment and pressure washers | Kärcher International Skip to content Skip to navigation International Home &amp; Garden Kärcher Know How When Hygiene Matters Most Kärcher Services Dealer Search FAQs Safety data sheets Home &amp; Garden App Pressure washers Wet and dry vacuum cleaners Patio Cleaner Mobile cleaning Pressure washers with combustion engine Pumps Watering systems Push Sweepers Vacuum cleaners Ash vacuum cleaners Spray extraction cleaners Robot vacuums and mops Window cleaning robot Cordless electric brooms Steam cleaners Steam vacuum cleaner Window Vacs Floor Cleaner Vacuum mop Electric wiping mop Garden Tools Robotic lawn mowers Electric Ice Scraper Air treatment Water filters Accessories Detergents Battery Power Professional Kärcher Know How Work more economically with battery-powered vacuum cleaners Disinfectant and hygiene solutions Product Finder High-pressure cleaners Outdoor Power Equipment Vacuums Wet and dry vacuum cleaners Window and surface vacuum cleaner Cleaning robots Floor scrubbers / scrubber driers Carpet cleaner Manual Cleaning Equipment Sweepers and vacuum sweepers Industrial vacuum cleaners Municipal Equipment Vehicle Wash Systems Water reclamation Steam cleaners &amp; steam vacuum cleaners Dry ice cleaning Drinking water treatment Water dispenser Work protection Generators and waste water pump Air Purifier Connected Cleaning Accessories Cleaning agents Battery Power+ Product Finder Services Dealer and Service Search Register your product Service Spare parts Rental Kärcher Financial Solutions FAQs Download Operating manuals Safety data sheets Data sheets for content materials Contact Inside Kärcher Company Go!Further: The products that go a step further About Kärcher Factory Tours Supplier Area Innovation Sponsoring Media information Company Home &amp; Garden Professional Press contact Virtual Brand Space Compliance &amp; Integrity Careers WOW Jobs Culture and insights Why Kärcher? Sustainability Sustainability at Kärcher Goals 2030 Facts and Figures History Culture, Nature &amp; Society Cultural Sponsorship Supply Chain and Products Employees Kärcher Newsroom Under the Dubai Sun A never-ending source A DAZZLING DISPLAY ON CENTER COURT Fast game, speedy cleaning BE THE DIFFERENCE Sustainability at Kärcher. SUSTAINABLE DETERGENTS From the concept through to series production. CULTURAL SPONSORSHIP Preservation of the monuments of the world. HOME &amp; GARDEN Cleaning devices for use around the home. Petrol running through her veins A woman with the WOW factor PROFESSIONAL Cleaning machines for professional use. CLEANING HELPS COMBAT DAILY STRESS Kärcher study 2019. EVERDAY IS A DAY FOR BIG TARGETS Information about Kärcher. Kärcher KNOW HOW HOME &amp; GARDEN DIFFERENCE – THE KÄRCHER MAGAZINE Join us on our journey through the world of Kärcher. Kärcher KNOW HOW PROFESSIONAL Legal information Imprint Copyright Disclaimer Privacy Information Cookie Policy Conditions of use for the press section Product and Service Security Reporting Contact Alfred K&auml;rcher SE &amp; Co. KG Alfred-K&auml;rcher-Strasse 28-40 71364 Winnenden / Germany P.O. Box 160 71349 Winnenden / Germany Tel.&nbsp; +49 (0) 7195 / 14-0 Social Media &copy; 2026 Alfred K&auml;rcher SE &amp; Co. KG"}]	https://karcher.com	1	t	2026-05-26 21:02:36.739	2026-05-26 21:02:36.739
cmpn331xa0007syhupv67e9lm	მისალმება	qa	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	\N	\N	\N	\N	[{"question":"როდესაც გესალმებიან ან ახალ ჩათს იწყებ უნდა მიწერო ასე: მოგესალმებით, რით შემიძლია დაგეხმაროთ","answer":""}]	\N	1	f	2026-05-26 20:24:31.865	2026-05-26 20:25:17.114
cmpn34z8g000dsyhuxxhg07iy	მისალმება	qa	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	\N	\N	\N	\N	[{"question":"როდესაც გესალმებიან ან ახალ ჩათს იწყებ, უნდა მიწერო ასე: გამარჯობა, რით შემიძლია დაგეხმაროთ","answer":""}]	\N	1	f	2026-05-26 20:26:01.688	2026-05-27 05:36:38.361
cmpnkhgse0003hf9jgm3w8ms8	large.txt	document	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	large.txt	\N	11700	text/plain	[{"question":"From large.txt — section 1","answer":"This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file. This is test content for a large file."}]	\N	1	f	2026-05-27 04:31:37.79	2026-05-27 05:59:55.329
cmpn4fa4h001n935nngfl3bej	კონტაქტები	crawl	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	\N	\N	\N	\N	[{"question":"Website content from კონტაქტები","answer":"კონტაქტები &ndash; Kärcher Georgia კალათა ( 0 ) სახლი &amp; ბაღი მაღალი წნევის აპარატები ორთქლის აპარატები მტვერსასრუტები სველი წმენდის მტვერსასრუტები ქიმწმენდის აპარატები ელექტრო ცოცხები რობოტი-მტვერსასრუტი მოსახვეტი აპარატი მინის საწმენდი აპარატი ბაღი ბაღის ტექნიკა ელექტროხერხი ბალახის ტრიმერი გაზონის სათიბი ბალახის სათიბი ფოთლების მტვერსასრუტი ბაღის აქსესუარები დრენაჟული წყლის სატუმბი აპარატები სახლის და ბაღის პომპები საწმენდი საშუალებები Signature Line აქსესუარები ჰაერის გამწმენდი პროფესიონალი მაღალი წნევის აპარატი მტვერსასრუტები ორთქლის აპარატი ქიმწმენდის აპარატი აქსესუარები გაყიდვები და მომსახურება წესები და პირობები ინფორმაცია მიწოდების შესახებ გადახდის სისტემები კერხერის შესახებ კონტაქტები | ☎ 032 238-03-06 ძიება ძიება ანგარიში კალათა 0 ძიება ძიება ანგარიში კალათა 0 სახლი &amp; ბაღი მაღალი წნევის აპარატები ორთქლის აპარატები მტვერსასრუტები სველი წმენდის მტვერსასრუტები ქიმწმენდის აპარატები ელექტრო ცოცხები რობოტი-მტვერსასრუტი მოსახვეტი აპარატი მინის საწმენდი აპარატი ბაღი ბაღის ტექნიკა ელექტროხერხი ბალახის ტრიმერი გაზონის სათიბი ბალახის სათიბი ფოთლების მტვერსასრუტი ბაღის აქსესუარები დრენაჟული წყლის სატუმბი აპარატები სახლის და ბაღის პომპები საწმენდი საშუალებები Signature Line აქსესუარები ჰაერის გამწმენდი პროფესიონალი მაღალი წნევის აპარატი მტვერსასრუტები ორთქლის აპარატი ქიმწმენდის აპარატი აქსესუარები გაყიდვები და მომსახურება წესები და პირობები ინფორმაცია მიწოდების შესახებ გადახდის სისტემები კერხერის შესახებ კონტაქტები | ☎ 032 238-03-06 კონტაქტები კერხერ ცენტრები კერხერ ცენტრი დიღომი ა.ბელიაშვილის ქუჩა 167, თბილისი, 0159 ტელ: +995 32 238-03-06 ელ.ფოსტა: sales@karcher.ge service@karcher.ge დეტალები კერხერ ცენტრი საბურთალო ვაჟა-ფშაველას გამზ. 4, თბილისი ,0160 ტელ: +995 32 238-03-06 ელ.ფოსტა: sales@karcher.ge service@karcher.ge დეტალები კერხერ ცენტრი ბათუმი პ. ბაგრატიონის 129, ბათუმი,6000 ტელ: +995 32 238-03-06 ელ.ფოსტა: sales@karcher.ge service@karcher.ge დეტალები კერხერ ცენტრი ქუთაისი შ.რუსთაველის გამზ. 96, ქუთაისი,4602 ტელ: +995 32 238-03-06 ელ.ფოსტა: sales@karcher.ge service@karcher.ge დეტალები კერხერ ცენტრი ზუგდიდი დ.აღმაშენებლის გამზირი 6, ზუგდიდი, 2100 ტელ: +995 32 238-03-06 ელ.ფოსტა: sales@karcher.ge service@karcher.ge დეტალები კერხერ ცენტრი თელავი ალაზნის გამზირი 71, თელავი, 2200 ტელ: +995 32 238-03-06 ელ.ფოსტა: sales@karcher.ge service@karcher.ge დეტალები კერხერ ცენტრი ხეივანი დ. აღმაშენებლის ხეივანი 193, თბილისი, ტელ: +995 32 238-03-06 ელ.ფოსტა: sales@karcher.ge service@karcher.ge დეტალები დაგვიკავშირდით სახელი გვარი ელფოსტა კომპანია ბმული ტელეფონის ნომერი შეტყობინება კერხერ საქართველო თბილისი: აკაკი ბელიაშვილის ქ. 167, 0159 თბილისი: ვაჟა-ფშაველას გამზ. 4 თბილისი: აღმაშენებლის ხეივანი 193 ქუთაისი: შოთა-რუსთაველის გამზ. 96 ბათუმი: პეტრე ბაგრატიონის 129 ბათუმი: მეტრო სითი ზუგდიდი: დ. აღმაშენებლის გამზ. 6 თელავი: ალაზნის გამზირი 71 საიტზე ნავიგაცია სახლი & ბაღი პროფესიონალი გაყიდვები და მომსახურება კონტაქტები | ☎ 032 238-03-06 სერვის ცენტრები მონაცემთა კონფიდენციალურობის დაცვის პოლიტიკა ბლოგი კონტაქტები info@karcher.ge sales@karcher.ge service@karcher.ge www.kaercher.com/ge &copy; 2026 Kärcher Georgia Join us and get nice things Free stuff and general goodness ელფოსტა *By completing this form you're signing up to receive our emails and can unsubscribe at any time. ქართული ინგლისური ქართული"}]	https://karchershop.ge/pages/contact	1	t	2026-05-26 21:02:01.962	2026-05-26 21:02:01.962
cmpn4fqpj001p935nf2b9wmep	Karchershop	crawl	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	\N	\N	\N	\N	[{"question":"Website content from Karchershop","answer":"კერხერის ოფიციალური ონლაინ მაღაზია &ndash; Kärcher Georgia კალათა ( 0 ) სახლი &amp; ბაღი მაღალი წნევის აპარატები ორთქლის აპარატები მტვერსასრუტები სველი წმენდის მტვერსასრუტები ქიმწმენდის აპარატები ელექტრო ცოცხები რობოტი-მტვერსასრუტი მოსახვეტი აპარატი მინის საწმენდი აპარატი ბაღი ბაღის ტექნიკა ელექტროხერხი ბალახის ტრიმერი გაზონის სათიბი ბალახის სათიბი ფოთლების მტვერსასრუტი ბაღის აქსესუარები დრენაჟული წყლის სატუმბი აპარატები სახლის და ბაღის პომპები საწმენდი საშუალებები Signature Line აქსესუარები ჰაერის გამწმენდი პროფესიონალი მაღალი წნევის აპარატი მტვერსასრუტები ორთქლის აპარატი ქიმწმენდის აპარატი აქსესუარები გაყიდვები და მომსახურება წესები და პირობები ინფორმაცია მიწოდების შესახებ გადახდის სისტემები კერხერის შესახებ კონტაქტები | ☎ 032 238-03-06 ძიება ძიება ანგარიში კალათა 0 ძიება ძიება ანგარიში კალათა 0 სახლი &amp; ბაღი მაღალი წნევის აპარატები ორთქლის აპარატები მტვერსასრუტები სველი წმენდის მტვერსასრუტები ქიმწმენდის აპარატები ელექტრო ცოცხები რობოტი-მტვერსასრუტი მოსახვეტი აპარატი მინის საწმენდი აპარატი ბაღი ბაღის ტექნიკა ელექტროხერხი ბალახის ტრიმერი გაზონის სათიბი ბალახის სათიბი ფოთლების მტვერსასრუტი ბაღის აქსესუარები დრენაჟული წყლის სატუმბი აპარატები სახლის და ბაღის პომპები საწმენდი საშუალებები Signature Line აქსესუარები ჰაერის გამწმენდი პროფესიონალი მაღალი წნევის აპარატი მტვერსასრუტები ორთქლის აპარატი ქიმწმენდის აპარატი აქსესუარები გაყიდვები და მომსახურება წესები და პირობები ინფორმაცია მიწოდების შესახებ გადახდის სისტემები კერხერის შესახებ კონტაქტები | ☎ 032 238-03-06 სახლი & ბაღი გაიგე მეტი პროფესიონალი გაიგე მეტი კატეგორიების ჩამონათვალი ორთქლით საწმენდი აპარატი რობოტი მტვერსასრუტი მტვერსასრუტები მაღალი წნევით რეცხვის აპარატი სველი წმენდის მტვერსასრუტი ბაღის ტექნიკა როგორ ავირჩიოთ მაღალი წნევით რეცხვის აპარატი? კითხვა ჩვენ გირჩევთ მეტი დანაზოგი 26% მაღალი წნევით რეცხვის აპარატი K Silent Anniversary Edition რეგულარული ფასი 588.30 ₾ გასაყიდი ფასი 588.30 ₾ რეგულარული ფასი 795.00 ₾ ერთეულის ფასი / per&nbsp; დანაზოგი 26% მაღალი წნევით რეცხვის აპარატი K 4 Power Control Flex რეგულარული ფასი 736.30 ₾ გასაყიდი ფასი 736.30 ₾ რეგულარული ფასი 995.00 ₾ ერთეულის ფასი / per&nbsp; დანაზოგი 26% მაღალი წნევით რეცხვის აპარატი K3 Classic რეგულარული ფასი 366.30 ₾ გასაყიდი ფასი 366.30 ₾ რეგულარული ფასი 495.00 ₾ ერთეულის ფასი / per&nbsp; დანაზოგი 26% მაღალი წნევით რეცხვის აპარატი K5 COMPACT რეგულარული ფასი 851.00 ₾ გასაყიდი ფასი 851.00 ₾ რეგულარული ფასი 1,150.00 ₾ ერთეულის ფასი / per&nbsp; დანაზოგი 26% მაღალი წნევით რეცხვის აპარატი K4 COMPACT რეგულარული ფასი 662.30 ₾ გასაყიდი ფასი 662.30 ₾ რეგულარული ფასი 895.00 ₾ ერთეულის ფასი / per&nbsp; დანაზოგი 26% მაღალი წნევით რეცხვის აპარატი K3 POWER CONTROL რეგულარული ფასი 440.30 ₾ გასაყიდი ფასი 440.30 ₾ რეგულარული ფასი 595.00 ₾ ერთეულის ფასი / per&nbsp; გამორჩეული კოლექცია დანაზოგი 40% რობოტი მტვერსასრუტი RVF 7 რეგულარული ფასი 1,677.00 ₾ გასაყიდი ფასი 1,677.00 ₾ რეგულარული ფასი 2,795.00 ₾ ერთეულის ფასი / per&nbsp; დანაზოგი 40% რობოტი მტვერსასრუტი RVM 4 Comfort Extra რეგულარული ფასი 1,437.00 ₾ გასაყიდი ფასი 1,437.00 ₾ რეგულარული ფასი 2,395.00 ₾ ერთეულის ფასი / per&nbsp; დანაზოგი 40% რობოტი მტვერსასრუტი RVC 3 რეგულარული ფასი 537.00 ₾ გასაყიდი ფასი 537.00 ₾ რეგულარული ფასი 895.00 ₾ ერთეულის ფასი / per&nbsp; დანაზოგი 40% რობოტი მტვერსასრუტი RVC 3 Comfort რეგულარული ფასი 777.00 ₾ გასაყიდი ფასი 777.00 ₾ რეგულარული ფასი 1,295.00 ₾ ერთეულის ფასი / per&nbsp; RVF 7 Comfort + SC 1 Multi&Up რეგულარული ფასი 3,999.00 ₾ გასაყიდი ფასი 3,999.00 ₾ რეგულარული ფასი ერთეულის ფასი / per&nbsp; დანაზოგი 26% ქიმიური წმენდის აპარატი cleaner SE 2 Spot Care რეგულარული ფასი 333.00 ₾ გასაყიდი ფასი 333.00 ₾ რეგულარული ფასი 450.00 ₾ ერთეულის ფასი / per&nbsp; დანაზოგი 26% ორთქლის აპარატი SC 1 Multi Comfort რეგულარული ფასი 281.20 ₾ გასაყიდი ფასი 281.20 ₾ რეგულარული ფასი 380.00 ₾ ერთეულის ფასი / per&nbsp; დანაზოგი 26% სველი წმენდის მტვერსასრუტი FCV 4 რეგულარული ფასი 1,032.30 ₾ გასაყიდი ფასი 1,032.30 ₾ რეგულარული ფასი 1,395.00 ₾ ერთეულის ფასი / per&nbsp; სპეციალური შეთავაზება RVF 7 Comfort + SC 1 Multi&amp;Up რეგულარული ფასი 3,999.00 ₾ გასაყიდი ფა"}]	https://karchershop.ge/	1	t	2026-05-26 21:02:23.478	2026-05-26 21:02:23.478
cmpnkpatb00016tmp39ggb9fe	multi-para.txt	document	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	multi-para.txt	\N	15604	text/plain	[{"question":"From multi-para.txt — section 1 1","answer":"Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1."},{"question":"From multi-para.txt — section 1 2","answer":"agraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Pa"},{"question":"From multi-para.txt — section 1 3","answer":"aph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Parag"},{"question":"From multi-para.txt — section 1 4","answer":"1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragrap"},{"question":"From multi-para.txt — section 1 5","answer":"Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1"},{"question":"From multi-para.txt — section 1 6","answer":"ragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1. Paragraph 1."},{"question":"From multi-para.txt — section 7 1","answer":"Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2."},{"question":"From multi-para.txt — section 7 2","answer":"agraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Pa"},{"question":"From multi-para.txt — section 7 3","answer":"aph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Parag"},{"question":"From multi-para.txt — section 7 4","answer":"2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragrap"},{"question":"From multi-para.txt — section 7 5","answer":"Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2"},{"question":"From multi-para.txt — section 7 6","answer":"ragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2. Paragraph 2."},{"question":"From multi-para.txt — section 13 1","answer":"Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3."},{"question":"From multi-para.txt — section 13 2","answer":"agraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Pa"},{"question":"From multi-para.txt — section 13 3","answer":"aph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Parag"},{"question":"From multi-para.txt — section 13 4","answer":"3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragrap"},{"question":"From multi-para.txt — section 13 5","answer":"Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3"},{"question":"From multi-para.txt — section 13 6","answer":"ragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3. Paragraph 3."}]	\N	18	f	2026-05-27 04:37:43.296	2026-05-27 05:59:58.972
cmpn4zd9g000ltvm6aj5j089b	სამუშაო საათები	qa	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	\N	\N	\N	\N	[{"question":"ყველა კერხერ-ცენტრი მუშაობს დილის 10დან საღამოს 7მდე, გარდა კერხერ-ცენტრი მეტრო სითი, რომელიც მუშაობს დილის 10 დან საღამოს 10 მდე","answer":""}]	\N	1	t	2026-05-26 21:17:39.161	2026-05-27 06:06:39.405
cmpnkpduj00056tmpsqpz1qpj	Edited Document KB	document	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	one-big-block.txt	\N	108000	text/plain	[{"question":"Edited doc content","answer":"This content was edited via the API"}]	\N	1	f	2026-05-27 04:37:47.227	2026-05-27 06:00:02.097
cmpnm4bbs000be6do01we3z72	ჩამონათვალები	qa	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	\N	\N	\N	\N	[{"question":"როდესაც ჩამონათვალს აკეთებ გამოყავი ბულეთებად","answer":""}]	\N	1	f	2026-05-27 05:17:23.414	2026-05-27 06:00:04.321
cmpnkhd2d0001hf9jsuhwgy40	test-kb.txt	document	cmpn21mzw0005105obvhtmm61	cmpn21muo0001105o9aefgepi	test-kb.txt	\N	794	text/plain	[{"question":"From test-kb.txt — section 1","answer":"Welcome to Demo Company! We are a leading provider of customer support solutions.\\n\\nOur Mission: We help businesses automate their customer service with AI-powered chatbots.\\n\\nOur Products:\\n1. BotForge Basic - AI chatbot with knowledge base integration\\n2. BotForge Pro - Adds human handoff, Shopify integration, and analytics\\n3. BotForge Enterprise - Unlimited everything, custom AI models, priority support\\n\\nPricing:\\n- Basic: $29/month\\n- Pro: $99/month  \\n- Enterprise: Custom pricing\\n\\nContact us:\\n- Email: support@democompany.com\\n- Phone: 1-800-DEMO\\n- Hours: Monday-Friday, 9AM-6PM EST\\n\\nOur AI chatbot can answer questions about:\\n- Product features and pricing\\n- Account management\\n- Technical support\\n- Billing inquiries\\n- Integration setup\\n\\nFor urgent issues, ask to speak with a human agent."}]	\N	1	f	2026-05-27 04:31:32.965	2026-05-27 06:00:07.055
cmpnnx5e5000xmzcclujdp7uk	მისალმება	qa	cmpnkg2dt00053jan70fws8yc	cmpn21muo0001105o9aefgepi	\N	\N	\N	\N	[{"question":"როდესაც გესალმებიან მიესალმე და დამატებით სამუშაო საათებზე არ მიწერო რამე.","answer":""},{"question":"უმიზეზოდ ნუ მიწერ ზედმეტ ინფორმაციას.","answer":""}]	\N	2	t	2026-05-27 06:07:48.343	2026-05-27 06:07:48.343
cmpno0ou8001dmzcce1xju836	მისალმება 2	qa	cmpnkg2dt00053jan70fws8yc	cmpn21muo0001105o9aefgepi	\N	\N	\N	\N	[{"question":"გამარჯობა - ბევრჯერ არ გამოიყენო, მხოლოდ მაშინ როცა გესალმებიან","answer":""}]	\N	1	t	2026-05-27 06:10:33.534	2026-05-27 06:10:33.534
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Message" (id, "conversationId", role, content, source, metadata, "createdAt") FROM stdin;
cmpn31nl00003syhu3g274vbz	cmpn31nkj0001syhu8n22vyq2	user	გამარჯობა	user	\N	2026-05-26 20:23:26.628
cmpn31of30005syhu0syd1myq	cmpn31nkj0001syhu8n22vyq2	assistant	გამარჯობა! 👋 მოგესალმებით! როგორ შემიძლია დაგეხმაროთ დღეს?	ai	\N	2026-05-26 20:23:27.711
cmpn337uw0009syhuc739l87d	cmpn31nkj0001syhu8n22vyq2	user	გამარჯობა	user	\N	2026-05-26 20:24:39.56
cmpn338ko000bsyhurtbv9oyq	cmpn31nkj0001syhu8n22vyq2	assistant	გამარჯობა! 👋 მოგესალმებით! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 20:24:40.488
cmpn353wz000fsyhu02gnzf2c	cmpn31nkj0001syhu8n22vyq2	user	გამარჯობა	user	\N	2026-05-26 20:26:07.763
cmpn354t8000hsyhuvhkpus5q	cmpn31nkj0001syhu8n22vyq2	assistant	გამარჯობა! 👋 სიამოვნებით დაგეხმარებით. რა საკითხზე გჭირდებათ ინფორმაცია ან დახმარება?	ai	\N	2026-05-26 20:26:08.924
cmpn35lbv000lsyhuxoedrldg	cmpn35lbn000jsyhufxyh45pq	user	გამარჯობა	user	\N	2026-05-26 20:26:30.331
cmpn35luo000nsyhuv6h894gk	cmpn35lbn000jsyhufxyh45pq	assistant	რით შემიძლია დაგეხმაროთ? 😊	ai	\N	2026-05-26 20:26:31.009
cmpn37aiu000tsyhuzb739ne3	cmpn35lbn000jsyhufxyh45pq	user	რა პროდუქციას ყიდით?	user	\N	2026-05-26 20:27:49.638
cmpn37cmd000vsyhu81wogotv	cmpn35lbn000jsyhufxyh45pq	assistant	Kärcher-ის ძირითადი პროდუქცია მოიცავს მაღალი წნევის საწმენდებს, მტვერსასრუტებს, ორთქლის საწმენდებს, ფანჯრის საწმენდებს, ბატარეაზე მომუშავე მოწყობილობებს, იატაკის საწმენდებს, ტუმბოებს, მორწყვის სისტემებსა და მათთვის განკუთვნილ აქსესუარებს. \n\nთუ გაინტერესებთ კონკრეტული კატეგორია ან პროდუქტი, დამატებითი ინფორმაციის მოწოდება შემიძლია!	ai	\N	2026-05-26 20:27:52.355
cmpn37s1n000xsyhunqqyozbx	cmpn35lbn000jsyhufxyh45pq	user	აქცია ეხლა რაზე გაქვთ?	user	\N	2026-05-26 20:28:12.347
cmpn37ty0000zsyhu0cfs3fdm	cmpn35lbn000jsyhufxyh45pq	assistant	ამჟამად მიმდინარე აქციების შესახებ ზუსტი ინფორმაცია არ მაქვს. გთხოვთ, ეწვიოთ ჩვენს ოფიციალურ ვებგვერდს [karchershop.ge](https://karchershop.ge) ან გვერდზე "აქციები" განყოფილებას, სადაც უახლესი შეთავაზებებია განთავსებული.\n\nთუ რაიმე კონკრეტული პროდუქტით ხართ დაინტერესებული, შემიძლია მის შესახებ დეტალური ინფორმაცია მოგაწოდოთ! 😊	ai	\N	2026-05-26 20:28:14.809
cmpn38c5s0011syhupmzt255m	cmpn35lbn000jsyhufxyh45pq	user	VC3	user	\N	2026-05-26 20:28:38.417
cmpn38e2f0013syhuybmqzhmz	cmpn35lbn000jsyhufxyh45pq	assistant	VC3 - Kärcher-ის მტვერსასრუტების ერთ-ერთი მოდელია. გთხოვთ, დამაზუსტოთ, კონკრეტულად რა გაინტერესებთ ამ პროდუქტთან დაკავშირებით:\n\n- მახასიათებლები\n- ფასი\n- ხელმისაწვდომობა\n- ან სხვა დეტალები\n\n(მინიშნება: თუ VC3-ს გულისხმობთ, ზუსტი მოდელის დასახელება, მაგალითად, **VC 3 Cordless** ან **VC 3 Premium**, დამეხმარება ზუსტი ინფორმაციის მოწოდებაში.)	ai	\N	2026-05-26 20:28:40.887
cmpn38yo20015syhu9sjuasve	cmpn35lbn000jsyhufxyh45pq	user	რა ღირს	user	\N	2026-05-26 20:29:07.586
cmpn390t30017syhujkqgby22	cmpn35lbn000jsyhufxyh45pq	assistant	VC3 მოდელის ზუსტი ფასის შესახებ ინფორმაცია არ მაქვს, რადგან ფასები შესაძლოა განსხვავდებოდეს მოდელის ვერსიის (მაგ. VC 3 Cordless, VC 3 Premium ან სხვა) და მიმდინარე აქციების მიხედვით.\n\nგთხოვთ, გადახედოთ ჩვენს ოფიციალურ ვებგვერდს: [karchershop.ge](https://karchershop.ge) – იქ ნახავთ ზუსტ ფასს და ხელმისაწვდომობას.\n\nთუ მომაწოდებთ კონკრეტული მოდელის სრულ დასახელებას, შევეცდები უფრო დეტალური ინფორმაცია მოგაწოდოთ! 😊	ai	\N	2026-05-26 20:29:10.36
cmpn3b6b2001bsyhuyuloesz9	cmpn3b6aq0019syhu3niwe52u	user	ზდაროვა	user	\N	2026-05-26 20:30:50.799
cmpn3b71c001dsyhuybz4wkj0	cmpn3b6aq0019syhu3niwe52u	assistant	გამარჯობა! 👋\n\nრით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 20:30:51.745
cmpn3bg4t001fsyhuww9u4utw	cmpn3b6aq0019syhu3niwe52u	user	Rogor xar?	user	\N	2026-05-26 20:31:03.533
cmpn3bgw4001hsyhutmwoxkbd	cmpn3b6aq0019syhu3niwe52u	assistant	მე კარგად ვარ, მადლობა! იმედია შენც კარგად ხარ 😊\n\nრით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 20:31:04.516
cmpn3bnbh001jsyhuzj5wtd4l	cmpn3b6aq0019syhu3niwe52u	user	Uto minda	user	\N	2026-05-26 20:31:12.845
cmpn3bot9001lsyhu6ca7ggjv	cmpn3b6aq0019syhu3niwe52u	assistant	უტო? გთხოვთ, განმარტოთ, რას გულისხმობთ? იქნებ კონკრეტულად რაიმე პროდუქტზე ან მომსახურებაზე გაქვთ შეკითხვა? 😊\n\nმაგალითად, თუ Karcher-ის ტექნიკასთან დაკავშირებით გაინტერესებთ რამე, სიამოვნებით დაგეხმარებით!	ai	\N	2026-05-26 20:31:14.781
cmpn3bysa001nsyhu3fgaf8pt	cmpn3b6aq0019syhu3niwe52u	user	Sautovebeli magida ra	user	\N	2026-05-26 20:31:27.706
cmpnu3hx3000312bhfrs2n2vn	cmpnu3hw8000112bh1wzxbicq	user	ჰაი	user	\N	2026-05-27 09:00:42.231
cmpnu3j6j000512bhvqz89eq4	cmpnu3hw8000112bh1wzxbicq	assistant	ჰაი, როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 09:00:43.868
cmpnu3ma4000712bh5ws4ra16	cmpnu3hw8000112bh1wzxbicq	user	რა იცი	user	\N	2026-05-27 09:00:47.885
cmpn3c1ni001psyhu96s3knfp	cmpn3b6aq0019syhu3niwe52u	assistant	გმადლობთ კითხვისთვის! 😊\n\n**სარეცხი მანქანებს** (საუთოვებელ მანქანებს) ვერ გირჩევთ, რადგან Karcher-ის ასორტიმენტში ძირითადად არის:\n\n- მაღალი წნევის საწმენდები\n- მტვერსასრუტები\n- ფანჯრის საწმენდები\n- პარკეტისა და იატაკის საწმენდები\n- საბურავების ტუმბოები\n\n**საუთოვებელი მაგიდა** (საუთაო დაფა) — Karcher-ს ასეთი პროდუქტი არ აქვს.\n\nთუმცა, თუ გაინტერესებთ Karcher-ის რომელიმე კონკრეტული მოწყობილობა (მაგ: მტვერსასრუტი, საწმენდი და ა.შ.), სიამოვნებით დაგეხმარებით ინფორმაციით! 🧹✨	ai	\N	2026-05-26 20:31:31.42
cmpn3svau0003pmd4zlve28ys	cmpn3svak0001pmd4pgmx31b0	user	Hello, who are you?	user	\N	2026-05-26 20:44:36.342
cmpn3sw4y0005pmd4xryuftcv	cmpn3svak0001pmd4pgmx31b0	assistant	გამარჯობა! მე ვარ თქვენი მეგობრული და კორპორატიული ასისტენტი. რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 20:44:37.426
cmpn3t6if0009pmd4gracw5ok	cmpn3t6ia0007pmd4cib6btp2	user	test	user	\N	2026-05-26 20:44:50.871
cmpn3t790000bpmd4et82np1j	cmpn3t6ia0007pmd4cib6btp2	assistant	მოგესალმებით! 👋\n\nრით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 20:44:51.826
cmpn3u1uh000312nj97pvjie9	cmpn3u1u7000112njh3tgjunt	user	hello	user	\N	2026-05-26 20:45:31.482
cmpn3u2gk000512njx75qmvnh	cmpn3u1u7000112njh3tgjunt	assistant	რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 20:45:32.277
cmpn401v80003ylri2cfig62f	cmpn401uv0001ylri3pbdw348	user	ჰაი	user	\N	2026-05-26 20:50:11.444
cmpn402k20005ylriioxh9hzv	cmpn401uv0001ylri3pbdw348	assistant	რით შემიძლია დაგეხმაროთ? 😊	ai	\N	2026-05-26 20:50:12.338
cmpn408q80007ylrijj4m24nc	cmpn401uv0001ylri3pbdw348	user	რა იცი?	user	\N	2026-05-26 20:50:20.337
cmpn40aph0009ylriht63y0od	cmpn401uv0001ylri3pbdw348	assistant	მე ვარ თქვენი მეგობრული და კორპორატიული ასისტენტი! ვიცი ინფორმაცია **Karchershop**-სა და **Karcher**-თან დაკავშირებით, ასევე შემიძლია დაგეხმაროთ ზოგად კითხვებში. \n\nთუ გსურთ, შემიძლია გითხრათ:\n- **Karcher**-ის პროდუქტებზე (მაგ. საწმენდი მოწყობილობები, აქსესუარები)\n- **Karchershop**-ის შეთავაზებებზე ან შეკვეთის პროცესზე\n- ან უბრალოდ დაგეხმაროთ ნებისმიერ სხვა საკითხში!\n\nრა გაინტერესებთ კონკრეტულად? 😊	ai	\N	2026-05-26 20:50:22.9
cmpn41jda000dylrifxbxqi5e	cmpn41jd6000bylris3daj9gq	user	რა არის BotForge?	user	\N	2026-05-26 20:51:20.783
cmpn41lg4000fylri1glmjld1	cmpn41jd6000bylris3daj9gq	assistant	BotForge — „Forge your AI. Connect your world.“ — არის AI ჩატბოტების პლატფორმა, რომელიც საშუალებას გაძლევთ შექმნათ, დააკონფიგურიროთ და დაუკავშიროთ ჭკვიანი ასისტენტები თქვენს ბიზნეს არხებს (ვებსაიტი, Shopify, Facebook Messenger, Instagram). იკვებება DeepSeek-ით, მხარს უჭერს RAG-ს, მორგებულ ცოდნის ბაზებს, Agent Panel-ს ადამიანთან გადაცემისთვის და ტოკენებზე დაფუძნებულ ბილინგს.\n\n**რით შემიძლია დაგეხმაროთ?**	ai	\N	2026-05-26 20:51:23.476
cmpn45si00003935n1jgyjc2p	cmpn45shs0001935nrfx5hazz	user	რა არის BotForge?	user	\N	2026-05-26 20:54:39.24
cmpn45w4u0005935ne5ytahit	cmpn45shs0001935nrfx5hazz	assistant	BotForge არის პლატფორმა, რომელიც საშუალებას გაძლევთ შექმნათ საკუთარი AI ჩატბოტი მარტივად — "Forge your AI. Connect your world."\n\nძირითადი შესაძლებლობები:\n- **AI ძრავა**: DeepSeek-ზე დაფუძნებული, RAG ტექნოლოგიით (მონაცემთა მოძიება და გენერაცია) და საკუთარი ცოდნის ბაზის დამატების შესაძლებლობით.\n- **ინტეგრაციები**: ვებსაიტის ვიჯეტი, Shopify, Facebook Messenger, Instagram.\n- **ადამიანის ჩართვა**: Agent Panel — როცა ბოტი ვერ პასუხობს, ზარს გადასცემს ოპერატორს.\n- **ანგარიშსწორება**: ტოკენებზე დაფუძნებული (იხდით მხოლოდ გამოყენებულ რესურსზე).\n\n**ფასები**:\n- **Free** — ძირითადი ფუნქციები, შეზღუდული ტოკენები.\n- **€49/თვე** (Pro) — მეტი ტოკენი, მოწინავე ინტეგრაციები.\n- **€149/თვე** (Enterprise) — სრული ფუნქციონალი, პრიორიტეტული მხარდაჭერა.\n- **Custom** — ინდივიდუალური გადაწყვეტილებები.\n\nდამატებითი კითხვების შემთხვევაში, მოგვწერეთ: **hello@benzos.uk**	ai	\N	2026-05-26 20:54:43.951
cmpn46hbr0009935n8ai0cmgk	cmpn46hbj0007935nsoq0mzrt	user	.	user	\N	2026-05-26 20:55:11.415
cmpn46igq000b935n97hf85ty	cmpn46hbj0007935nsoq0mzrt	assistant	Hey there! 👋 Welcome to BotForge — where you can forge your AI and connect your world.\n\nI'm the BotForge Support Assistant. How can I help you today? Here’s a quick overview of what I can assist with:\n\n- **Features & AI capabilities** (DeepSeek-powered, RAG, custom knowledge base)\n- **Pricing** (Free / €49 Pro / €149 Enterprise / Custom)\n- **Integrations** (Website widget, Shopify, Facebook Messenger, Instagram)\n- **Agent Panel** (human handoff)\n- **Token-based billing**\n\nJust ask away!	ai	\N	2026-05-26 20:55:12.89
cmpn46nsi000d935n8hz9jqbj	cmpn46hbj0007935nsoq0mzrt	user	გამარჯობა	user	\N	2026-05-26 20:55:19.794
cmpnz0prg000393pw13bphqnr	cmpn5aixt0011tex1kcpzkra8	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:18:30.508
cmpn46pz7000f935njrajsawg	cmpn46hbj0007935nsoq0mzrt	assistant	გამარჯობა! 👋 მოგესალმებით BotForge-ში — "გამოიყალიბეთ თქვენი AI, დააკავშირეთ თქვენი სამყარო". \n\nროგორ შემიძლია დაგეხმაროთ? მოკლედ გიამბობთ იმაზე, რაც გვაქვს:\n\n- **AI შესაძლებლობები** (DeepSeek-ზე დაფუძნებული, RAG, მორგებული ცოდნის ბაზა)\n- **ფასები** (უფასო / €49 Pro / €149 Enterprise / მორგებული)\n- **ინტეგრაციები** (ვებსაიტის ვიჯეტი, Shopify, Facebook Messenger, Instagram)\n- **აგენტის პანელი** (ადამიანთან გადართვა)\n- **თოკენებზე დაფუძნებული ბილინგი**\n\nრა გაინტერესებთ? 😊	ai	\N	2026-05-26 20:55:22.627
cmpn4767z000h935nug1jerlk	cmpn46hbj0007935nsoq0mzrt	user	ამხელა ინფო არ მინდა	user	\N	2026-05-26 20:55:43.679
cmpn477bx000j935n1rkoauo1	cmpn46hbj0007935nsoq0mzrt	assistant	გასაგებია, ბოდიშს გიხდით! 😊\n\nრა გაინტერესებთ კონკრეტულად? მოკლედ გიპასუხებთ.	ai	\N	2026-05-26 20:55:45.117
cmpn47ing000l935nh9hhfxvk	cmpn46hbj0007935nsoq0mzrt	user	რა ღირს	user	\N	2026-05-26 20:55:59.788
cmpn47jmf000n935np70591n9	cmpn46hbj0007935nsoq0mzrt	assistant	მოკლედ:\n\n- **უფასო** — საცდელი ვერსია\n- **€49/თვე** — Pro\n- **€149/თვე** — Enterprise\n- **მორგებული ფასი** — თქვენი საჭიროებების მიხედვით\n\nრომელი გაინტერესებთ?	ai	\N	2026-05-26 20:56:01.047
cmpn482vr000p935ntkjecbwr	cmpn46hbj0007935nsoq0mzrt	user	უფასო ვერსია როგორია	user	\N	2026-05-26 20:56:26.007
cmpn484pi000r935nzir5qr7g	cmpn46hbj0007935nsoq0mzrt	assistant	მოკლედ:\n\n- **ლიმიტირებული თოკენები** — საცდელი გამოყენებისთვის საკმარისი\n- **ძირითადი AI ფუნქციები** — DeepSeek-ზე მუშაობს\n- **1 ინტეგრაცია** (ვებსაიტის ვიჯეტი ან სხვა)\n- **ადამიანთან გადართვა** — არ შედის\n\nსაკმარისია გასასინჯად, მაგრამ Pro-ზე გადასვლა მოგიწევთ, თუ მეტი გჭირდებათ.\n\nკიდევ რა გაინტერესებთ?	ai	\N	2026-05-26 20:56:28.374
cmpn48z3g000t935n3ym1ra06	cmpn46hbj0007935nsoq0mzrt	user	კერხერზე რა იცი	user	\N	2026-05-26 20:57:07.757
cmpn490nx000v935n82pm0yyn	cmpn46hbj0007935nsoq0mzrt	assistant	ბოდიშს გიხდით, მაგრამ "კერხერზე" ინფორმაცია არ მაქვს — ეს ჩემი ცოდნის მიღმაა. 😊\n\nთუ BotForge-ზე გაქვთ შეკითხვა (ფასები, ფუნქციები, ინტეგრაციები), სიამოვნებით დაგეხმარებით. წინააღმდეგ შემთხვევაში, შეგიძლიათ მომწეროთ მისამართზე: **hello@benzos.uk**	ai	\N	2026-05-26 20:57:09.788
cmpn4b31r000z935nzkgy4ipt	cmpn4b31i000x935njp8nift5	user	ჰაი	user	\N	2026-05-26 20:58:46.191
cmpn4b3oz0011935n8xpsig3c	cmpn4b31i000x935njp8nift5	assistant	რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 20:58:47.027
cmpn4bcv50013935nrunbbmh0	cmpn4b31i000x935njp8nift5	user	ბოშზე რა იცი	user	\N	2026-05-26 20:58:58.913
cmpn4beji0015935n50uohrsj	cmpn4b31i000x935njp8nift5	assistant	ბოშები (რომები) ეთნიკური ჯგუფია, რომელიც ინდოეთიდან წარმოიშვა და მსოფლიოს სხვადასხვა ქვეყანაში ცხოვრობს. მათ აქვთ საკუთარი კულტურა, ტრადიციები და ენა. ხშირად ისინი მომთაბარე ცხოვრების წესით გამოირჩევიან, თუმცა ბევრი მათგანი დასახლებულადაც ცხოვრობს.	ai	\N	2026-05-26 20:59:01.086
cmpn4d042001b935nk96r3yop	cmpn4d03m0019935ni1wb32cz	user	ჰაი	user	\N	2026-05-26 21:00:15.699
cmpn4d0s9001d935nv72by9le	cmpn4d03m0019935ni1wb32cz	assistant	რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 21:00:16.569
cmpn4d5ny001f935nwngeshg6	cmpn4d03m0019935ni1wb32cz	user	ბოშზე რა იცი	user	\N	2026-05-26 21:00:22.895
cmpn4d7xm001h935ntubnznky	cmpn4d03m0019935ni1wb32cz	assistant	ბოში (ან ბოშა) ქართულ ფოლკლორში ერთ-ერთი ყველაზე ცნობილი პერსონაჟია. ის არის ჭკვიანი, ეშმაკი და იუმორით სავსე გმირი, რომელიც ხშირად ატყუებს მდიდრებს, მღვდლებსა და ხელისუფლებს. მისი ისტორიები ფართოდაა ცნობილი ქართულ ხალხურ ზღაპრებში.	ai	\N	2026-05-26 21:00:25.835
cmpn4di75001j935ngutt1gq2	cmpn4d03m0019935ni1wb32cz	user	რამე ხუმრობა მომიყევი	user	\N	2026-05-26 21:00:39.137
cmpn4dlo1001l935nhpikgstc	cmpn4d03m0019935ni1wb32cz	assistant	რა თქმა უნდა! აი, ერთი მოკლე ხუმრობა:\n\nბოში მიდის ბაზარში და ხედავს, ერთი კაცი თუთიყუშს ყიდის. ეკითხება:\n— ეს რა ღირს?\n— 100 ლარი.\n— რატომ ძვირია?\n— იმიტომ, რომ ყველაფერს იმეორებს, რასაც გაიგონებს.\nბოში ამბობს:\n— აი, 100 ლარი, მომეცი.\nმეორე დღეს ბოში მოდის გაბრაზებული:\n— ეგ შენი თუთიყუში სულ სისულელეებს იმეორებს, წამიყვანე!\nთუთიყუში პასუხობს:\n— მე შენსავით ბოში არ ვარ, რომ 100 ლარი გადავიხადო და მერე ვიჩივლო! 😄	ai	\N	2026-05-26 21:00:43.632
cmpn4gaar001v935nn4ikk7vo	cmpn4gaaj001t935nj6bhbf3o	user	რა შეგიძლია	user	\N	2026-05-26 21:02:48.867
cmpn4gawd001x935nrq98m4ii	cmpn4gaaj001t935nj6bhbf3o	assistant	რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 21:02:49.645
cmpn4gh99001z935nvxkvcoai	cmpn4gaaj001t935nj6bhbf3o	user	რა იცი	user	\N	2026-05-26 21:02:57.885
cmpn4gijq0021935n5ds4h0lq	cmpn4gaaj001t935nj6bhbf3o	assistant	მე ვარ მეგობრული ასისტენტი და შემიძლია დაგეხმაროთ სხვადასხვა კითხვებში, მაგალითად, ინფორმაციის მოძიებაში, რჩევების მიცემაში ან მარტივი ამოცანების შესრულებაში. რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 21:02:59.558
cmpn4jep60003k7m15673stzj	cmpn4jeo70001k7m19vc97tau	user	Hello	user	\N	2026-05-26 21:05:14.538
cmpn4jfdv0005k7m1zbo7fhd6	cmpn4jeo70001k7m19vc97tau	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 21:05:15.427
cmpn4lejt0009k7m1tyuccqsm	cmpn4lejj0007k7m1aqoah29v	user	გამარჯობა	user	\N	2026-05-26 21:06:47.657
cmpn4lf95000bk7m1id0s5ezd	cmpn4lejj0007k7m1aqoah29v	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 21:06:48.569
cmpn4ljyx000dk7m1s2u9p2k4	cmpn4lejj0007k7m1aqoah29v	user	ვინ ხარ	user	\N	2026-05-26 21:06:54.681
cmpn4lkpg000fk7m1jaow6bmx	cmpn4lejj0007k7m1aqoah29v	assistant	მე ვარ მეგობრული ასისტენტი, რომელიც გეხმარებით მარტივად და მოკლედ.	ai	\N	2026-05-26 21:06:55.636
cmpn4lqw1000hk7m1noyjr7bn	cmpn4lejj0007k7m1aqoah29v	user	რა იცი	user	\N	2026-05-26 21:07:03.649
cmpn4ls4h000jk7m1iaek63e7	cmpn4lejj0007k7m1aqoah29v	assistant	ვიცი ბევრი რამ, მაგრამ ვცდილობ მარტივად და მოკლედ გიპასუხო. შემიძლია დაგეხმაროთ კითხვებზე პასუხის გაცემაში, ინფორმაციის მოძიებაში ან რჩევების მიცემაში. კონკრეტულად რა გაინტერესებთ?	ai	\N	2026-05-26 21:07:05.25
cmpn4m1ur000lk7m1qn44uloz	cmpn4lejj0007k7m1aqoah29v	user	ბოშზე რა იცი?	user	\N	2026-05-26 21:07:17.859
cmpn4m3l3000nk7m1oydeucq5	cmpn4lejj0007k7m1aqoah29v	assistant	ბოში (ან ბოშები) ეთნიკური ჯგუფია, რომელიც ძირითადად ინდოეთიდან წარმოშობილი მომთაბარე ტრადიციებითაა ცნობილი. ისინი მსოფლიოს სხვადასხვა ქვეყანაში ცხოვრობენ, მათ შორის საქართველოშიც. აქვთ საკუთარი ენა, კულტურა და ტრადიციები. თუ კონკრეტული კითხვა გაქვთ, დამისვით.	ai	\N	2026-05-26 21:07:20.104
cmpn4o97z0003kp4yb9z2x38c	cmpn4o97c0001kp4yykib1ear	user	ბოშზე რა იცი	user	\N	2026-05-26 21:09:00.72
cmpn4oavf0005kp4yqw8wpjho	cmpn4o97c0001kp4yykib1ear	assistant	ბოშები (რომები) მომთაბარე ეთნიკური ჯგუფია, რომელიც ინდოეთიდან წარმოიშვა და მთელ მსოფლიოში გავრცელდა. ისინი ცნობილნი არიან საკუთარი კულტურით, ენითა და ტრადიციებით. ხშირად განიცდიან დისკრიმინაციასა და სტერეოტიპებს.	ai	\N	2026-05-26 21:09:02.859
cmpn4qfrg0003rcnogg9ednp5	cmpn4qfr70001rcnoyy7qff4m	user	როგორ დავუკავშირდე კერხერს?	user	\N	2026-05-26 21:10:42.508
cmpn4qgya0005rcnoowegxa6y	cmpn4qfr70001rcnoyy7qff4m	assistant	შეგიძლიათ დაუკავშირდეთ კერხერს ტელეფონით: **032 238-03-06** ან ელფოსტით: **sales@karcher.ge** / **service@karcher.ge**.  \nმათ აქვთ ცენტრები თბილისში, ბათუმში, ქუთაისში, ზუგდიდსა და თელავში.	ai	\N	2026-05-26 21:10:44.05
cmpn4r27g0009rcno1d3dfcbr	cmpn4r2780007rcnovc8op8st	user	ჰაი	user	\N	2026-05-26 21:11:11.596
cmpn4r32i000brcnoshewejoc	cmpn4r2780007rcnovc8op8st	assistant	რით შემიძლია დაგეხმაროთ? 😊	ai	\N	2026-05-26 21:11:12.714
cmpn4r620000drcnoyn262pf5	cmpn4r2780007rcnovc8op8st	user	რა იცი	user	\N	2026-05-26 21:11:16.584
cmpn4r79i000frcno62law8o4	cmpn4r2780007rcnovc8op8st	assistant	მე ვარ კერხერის ასისტენტი. შემიძლია დაგეხმაროთ ინფორმაციით კერხერის პროდუქციაზე, მაღაზიების მისამართებზე, ფასებსა და სერვისზე.\n\nრით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 21:11:18.15
cmpn4rj5d0001tvm6cxvohziz	cmpn4r2780007rcnovc8op8st	user	თბილისში სად არის	user	\N	2026-05-26 21:11:33.553
cmpn4rkhv0003tvm6i7u8f5b0	cmpn4r2780007rcnovc8op8st	assistant	თბილისში კერხერის ცენტრები მდებარეობს შემდეგ მისამართებზე:\n\n1. **დიღომი** — ა. ბელიაშვილის ქუჩა 167\n2. **საბურთალო** — ვაჟა-ფშაველას გამზირი 4\n3. **ხეივანი** — დ. აღმაშენებლის ხეივანი 193\n\nტელეფონი: **032 238-03-06** 📞	ai	\N	2026-05-26 21:11:35.299
cmpn4s85w0005tvm6yalwm239	cmpn4r2780007rcnovc8op8st	user	8ზე საღამოს მუშაობს რომელიმე?	user	\N	2026-05-26 21:12:05.973
cmpn4s9f50007tvm6o0bj89pd	cmpn4r2780007rcnovc8op8st	assistant	სამწუხაროდ, ზუსტი სამუშაო საათები არ მაქვს მითითებული. გირჩევთ, დარეკოთ **032 238-03-06**-ზე და გაიგოთ, რომელი ცენტრი მუშაობს საღამოს 8 საათამდე. 📞	ai	\N	2026-05-26 21:12:07.602
cmpn4usly000dtvm69zdn4qu9	cmpn4uslo000btvm672fndozo	user	ჰაი	user	\N	2026-05-26 21:14:05.782
cmpn4utcy000ftvm6nlgo5w63	cmpn4uslo000btvm672fndozo	assistant	რით შემიძლია დაგეხმაროთ? 😊	ai	\N	2026-05-26 21:14:06.754
cmpn4v3w4000htvm6sry9kekb	cmpn4uslo000btvm672fndozo	user	თბილისში რომლამდე მუშაობს მაღაზიები?	user	\N	2026-05-26 21:14:20.404
cmpnx75qt000harcf3sh3cqh0	cmpnx45mv0001arcfdjnlbqd4	assistant	გარანტიის პირობების შესახებ დეტალური ინფორმაციის მისაღებად გთხოვთ, დაუკავშირდეთ ჩვენს სერვის ცენტრს ელფოსტაზე: service@karcher.ge ან დარეკეთ ნომერზე: 032 238-03-06.	ai	\N	2026-05-27 10:27:31.926
cmpn4v5ks000jtvm62wqf8yvs	cmpn4uslo000btvm672fndozo	assistant	კერხერის ცენტრები თბილისში მუშაობს შემდეგ მისამართებზე:\n\n1. **დიღომი** – ა. ბელიაშვილის ქ. 167\n2. **საბურთალო** – ვაჟა-ფშაველას გამზ. 4\n3. **ხეივანი** – დ. აღმაშენებლის ხეივანი 193\n\nსამუშაო საათების შესახებ ზუსტი ინფორმაცია არ მაქვს, გირჩევთ დარეკოთ ნომერზე **032 238-03-06** და გაიგოთ. 😊	ai	\N	2026-05-26 21:14:22.588
cmpn4zkjr000ptvm6bmffy5b2	cmpn4zkjh000ntvm6i6weziou	user	ჰაი	user	\N	2026-05-26 21:17:48.615
cmpn4zl8v000rtvm69q8rpp5v	cmpn4zkjh000ntvm6i6weziou	assistant	რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 21:17:49.519
cmpn4zsqy000ttvm6e0i4zf43	cmpn4zkjh000ntvm6i6weziou	user	რომლამდე მუშაობთ?	user	\N	2026-05-26 21:17:59.242
cmpn4ztlz000vtvm6lhy30i0k	cmpn4zkjh000ntvm6i6weziou	assistant	კერხერ ცენტრები მუშაობენ 10:00-დან 19:00 საათამდე.	ai	\N	2026-05-26 21:18:00.36
cmpn50383000xtvm6rmlboidl	cmpn4zkjh000ntvm6i6weziou	user	ყველა?	user	\N	2026-05-26 21:18:12.82
cmpn5046g000ztvm6x7nhqzjo	cmpn4zkjh000ntvm6i6weziou	assistant	დიახ, ყველა კერხერ ცენტრი (თბილისი, ბათუმი, ქუთაისი, ზუგდიდი, თელავი) მუშაობს 10:00-დან 19:00 საათამდე.	ai	\N	2026-05-26 21:18:14.057
cmpn50f5l0011tvm62ingliyb	cmpn4zkjh000ntvm6i6weziou	user	საღამოს 10 მდე არცერთი მუშაობს!	user	\N	2026-05-26 21:18:28.281
cmpn50g4a0013tvm6a2ecz5or	cmpn4zkjh000ntvm6i6weziou	assistant	სამწუხაროდ, არცერთი კერხერ ცენტრი არ მუშაობს საღამოს 10 საათამდე. ყველა მაღაზია იხურება 19:00 საათზე.	ai	\N	2026-05-26 21:18:29.53
cmpn56c0e0003tex1vqe4r3x4	cmpn56c020001tex1x297jvex	user	ჰაუ	user	\N	2026-05-26 21:23:04.142
cmpn56cs40005tex1nzf7f4d3	cmpn56c020001tex1x297jvex	assistant	გამარჯობა! 👋\n\nრით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 21:23:05.14
cmpn56lyv0007tex1dqfd2ceb	cmpn56c020001tex1x297jvex	user	რომლამდე მუშაობთ ბათუმში?	user	\N	2026-05-26 21:23:17.047
cmpn56mw00009tex196xsgyi7	cmpn56c020001tex1x297jvex	assistant	კერხერ ცენტრი ბათუმში მუშაობს **დილის 10:00-დან საღამოს 19:00-მდე**.	ai	\N	2026-05-26 21:23:18.24
cmpn56x8m000btex1kf5l5ga5	cmpn56c020001tex1x297jvex	user	მეტრო სითი?	user	\N	2026-05-26 21:23:31.655
cmpn56xxl000dtex16kqtvwwn	cmpn56c020001tex1x297jvex	assistant	კერხერ ცენტრი მეტრო სითი მუშაობს **დილის 10:00-დან საღამოს 22:00-მდე**.	ai	\N	2026-05-26 21:23:32.553
cmpn57jhj000ftex1pzkfbtp2	cmpn56c020001tex1x297jvex	user	ალტა?	user	\N	2026-05-26 21:24:00.487
cmpn57knl000htex1s9s7ehoa	cmpn56c020001tex1x297jvex	assistant	ალტას შესახებ ინფორმაცია არ მაქვს. 😊\n\nთუ კერხერის რომელიმე კონკრეტული პროდუქტი ან სერვისი გაინტერესებს, მითხარი, სიამოვნებით დაგეხმარები!	ai	\N	2026-05-26 21:24:02.002
cmpn57rzo000jtex1qpkcg9xj	cmpn56c020001tex1x297jvex	user	Puzzi	user	\N	2026-05-26 21:24:11.509
cmpn57txg000ltex16izcozr0	cmpn56c020001tex1x297jvex	assistant	**Kärcher Puzzi** არის ქიმწმენდის (ექსტრაქციული) აპარატი, რომელიც გამოიყენება ხალიჩების, ტექსტილისა და რბილი ავეჯის ღრმა წმენდისთვის.\n\nმისი საშუალებით შეგიძლიათ წყლისა და საწმენდი საშუალების შესხურება და ჭუჭყიანი წყლის უკან შეწოვა.\n\nდაგაინტერესებთ რომელიმე კონკრეტული მოდელი?	ai	\N	2026-05-26 21:24:14.015
cmpn586n9000ntex1tt4q7617	cmpn56c020001tex1x297jvex	user	რა ღირს?	user	\N	2026-05-26 21:24:30.501
cmpn587z4000ptex1tpm4khuy	cmpn56c020001tex1x297jvex	assistant	Kärcher Puzzi-ს ფასები დამოკიდებულია მოდელზე. მაგალითად:\n\n- **SE 2 Spot Care** – 333 ₾\n- **SE 2 Spot Care** (სხვა ვარიანტი) – 450 ₾\n\nკონკრეტული მოდელი თუ გაინტერესებთ, ზუსტ ფასს გეტყვით.	ai	\N	2026-05-26 21:24:32.225
cmpn59wgq000ttex1a6e61qnt	cmpn59wgh000rtex1ydaeez52	user	გამარჯობა	user	\N	2026-05-26 21:25:50.619
cmpn59x9c000vtex1t6rlugxa	cmpn59wgh000rtex1ydaeez52	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 21:25:51.648
cmpn5a8jz000xtex12fwcb4q2	cmpn59wgh000rtex1ydaeez52	user	Till what hour do you work?	user	\N	2026-05-26 21:26:06.287
cmpn5a9li000ztex125my1pyu	cmpn59wgh000rtex1ydaeez52	assistant	Kärcher-ის ცენტრები მუშაობს 10:00-დან 19:00 საათამდე, გარდა მეტრო სითის ცენტრისა, რომელიც მუშაობს 10:00-დან 22:00 საათამდე.	ai	\N	2026-05-26 21:26:07.638
cmpn5aiy30013tex1bsl6vpe4	cmpn5aixt0011tex1kcpzkra8	user	Hello	user	\N	2026-05-26 21:26:19.756
cmpn5ajlv0015tex1yxt9ueve	cmpn5aixt0011tex1kcpzkra8	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-26 21:26:20.611
cmpnklq9j0001uu5nc1o0h0x1	cmpn5aixt0011tex1kcpzkra8	system	🔄 Customer requested a human agent	system	\N	2026-05-27 04:34:56.695
cmpnkltdj0005uu5n1aomupv2	cmpn5aixt0011tex1kcpzkra8	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-27 04:35:00.728
cmpnkltjw0007uu5nlc0py7cs	cmpn5aixt0011tex1kcpzkra8	agent	Hello! I'm an agent. How can I help you today?	human	\N	2026-05-27 04:35:00.956
cmpnklwig0009uu5n64icuhw8	cmpn5aixt0011tex1kcpzkra8	system	✅ Conversation resolved	system	\N	2026-05-27 04:35:04.792
cmpnkpbo600036tmpd4z2ykd0	cmpn5aixt0011tex1kcpzkra8	system	🔄 Customer requested a human agent	system	\N	2026-05-27 04:37:44.407
cmpnm37ik0003e6do93ipfrnl	cmpnm37h30001e6dokvsnec8t	user	გამარჯობა	user	\N	2026-05-27 05:16:31.82
cmpnm38q70005e6dof7h4pfqj	cmpnm37h30001e6dokvsnec8t	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 05:16:33.391
cmpnm3ef30007e6dol2myrddi	cmpnm37h30001e6dokvsnec8t	user	სად ხართ?	user	\N	2026-05-27 05:16:40.768
cmpnm3gs30009e6dobbfhwt6x	cmpnm37h30001e6dokvsnec8t	assistant	კერხერის ცენტრები განთავსებულია შემდეგ მისამართებზე:\n\n- **თბილისი (დიღომი):** ა. ბელიაშვილის ქ. 167\n- **თბილისი (საბურთალო):** ვაჟა-ფშაველას გამზ. 4\n- **თბილისი (ხეივანი):** დ. აღმაშენებლის ხეივანი 193\n- **ქუთაისი:** შ. რუსთაველის გამზ. 96\n- **ბათუმი:** პ. ბაგრატიონის 129\n- **ზუგდიდი:** დ. აღმაშენებლის გამზ. 6\n- **თელავი:** ალაზნის გამზირი 71\n\nტელეფონი: 032 238-03-06	ai	\N	2026-05-27 05:16:43.828
cmpnm58oh000fe6do8e29f4a6	cmpnm58o6000de6dow0fd8423	user	გამარჯობა	user	\N	2026-05-27 05:18:06.641
cmpnm59hb000he6downfutcir	cmpnm58o6000de6dow0fd8423	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 05:18:07.679
cmpnm5bhr000je6dohl1duzro	cmpnm58o6000de6dow0fd8423	user	სად ხართ?	user	\N	2026-05-27 05:18:10.288
cmpnm5dyr000le6doehsb13rd	cmpnm58o6000de6dow0fd8423	assistant	ჩვენი კერხერ ცენტრები განთავსებულია შემდეგ მისამართებზე:\n\n- **თბილისი (დიღომი):** ა. ბელიაშვილის ქუჩა 167\n- **თბილისი (საბურთალო):** ვაჟა-ფშაველას გამზირი 4\n- **თბილისი (ხეივანი):** დ. აღმაშენებლის ხეივანი 193\n- **ქუთაისი:** შ. რუსთაველის გამზირი 96\n- **ბათუმი:** პ. ბაგრატიონის 129\n- **ზუგდიდი:** დ. აღმაშენებლის გამზირი 6\n- **თელავი:** ალაზნის გამზირი 71\n\nდამატებითი ინფორმაციისთვის შეგიძლიათ დაგვიკავშირდეთ ტელეფონზე: **032 238-03-06**.	ai	\N	2026-05-27 05:18:13.491
cmpnmc7a400031p6qgcj4c7ql	cmpnmc79l00011p6q5mzb3r4k	user	ჰაი	user	\N	2026-05-27 05:23:31.42
cmpnmc8ay00051p6qbqzrlet9	cmpnmc79l00011p6q5mzb3r4k	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ	ai	\N	2026-05-27 05:23:32.747
cmpnmca9p00071p6qfkhe114b	cmpnmc79l00011p6q5mzb3r4k	user	სად ხართ?	user	\N	2026-05-27 05:23:35.293
cmpnmcdwr00091p6q7c3xvo4b	cmpnmc79l00011p6q5mzb3r4k	assistant	ჩვენი კერხერ-ცენტრები განთავსებულია შემდეგ მისამართებზე:\n\n- **კერხერ ცენტრი დიღომი** — ა.ბელიაშვილის ქუჩა 167, თბილისი\n- **კერხერ ცენტრი საბურთალო** — ვაჟა-ფშაველას გამზ. 4, თბილისი\n- **კერხერ ცენტრი ხეივანი** — დ. აღმაშენებლის ხეივანი 193, თბილისი\n- **კერხერ ცენტრი ბათუმი** — პ. ბაგრატიონის 129, ბათუმი\n- **კერხერ ცენტრი ბათუმი (მეტრო სითი)**\n- **კერხერ ცენტრი ქუთაისი** — შ.რუსთაველის გამზ. 96, ქუთაისი\n- **კერხერ ცენტრი ზუგდიდი** — დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n- **კერხერ ცენტრი თელავი** — ალაზნის გამზირი 71, თელავი\n\n**სამუშაო საათები:**\n- ყველა კერხერ-ცენტრი მუშაობს **დილის 10-დან საღამოს 7-მდე**.\n- გამონაკლისია **კერხერ-ცენტრი მეტრო სითი**, რომელიც მუშაობს **დილის 10-დან საღამოს 10-მდე**.\n\nდამატებითი ინფორმაციისთვის შეგიძლიათ დაგვიკავშირდეთ ტელეფონზე: 032 238-03-06.	ai	\N	2026-05-27 05:23:40.007
cmpnmercd000d1p6q7nlko1iq	cmpnmerc3000b1p6q6wkhy63k	user	say something	user	\N	2026-05-27 05:25:30.733
cmpnmes8q000f1p6q5olha01l	cmpnmerc3000b1p6q6wkhy63k	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ	ai	\N	2026-05-27 05:25:31.898
cmpnmevxn000j1p6q0ivc44g9	cmpnmevxa000h1p6q1184wl5r	user	გთხოვთ მითხრათ 3 მთავარი ინფორმაცია კერხერზე	user	\N	2026-05-27 05:25:36.683
cmpnmezap000l1p6qjbzlbz1w	cmpnmevxa000h1p6q1184wl5r	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ\n\nაი, 3 მთავარი ინფორმაცია კერხერზე:\n\n- **კერხერი** — წამყვანი საერთაშორისო კომპანია საწმენდი ტექნიკის წარმოებაში, რომელიც გთავაზობთ როგორც საყოფაცხოვრებო, ისე პროფესიონალურ პროდუქციას (მაღალი წნევის აპარატები, მტვერსასრუტები, ორთქლის აპარატები, ბაღის ტექნიკა და სხვა).\n- **სამუშაო საათები**: ყველა კერხერ-ცენტრი მუშაობს **დილის 10:00-დან საღამოს 19:00-მდე**, გარდა **კერხერ-ცენტრი მეტრო სითისა**, რომელიც მუშაობს **10:00-დან 22:00-მდე**.\n- **საკონტაქტო ინფორმაცია**: ტელეფონი — **032 238-03-06**, ელ.ფოსტა — sales@karcher.ge / service@karcher.ge.	ai	\N	2026-05-27 05:25:41.042
cmpnmg05q000p1p6qdsl497v3	cmpnmg057000n1p6qrcqzquzh	user	სად ხართ	user	\N	2026-05-27 05:26:28.815
cmpnms8g7000fy6mp6dnul4nw	cmpnms22m0007y6mpvwk4qmue	assistant	გამარჯობა, მე ვარ Demo Company-ს მხარდაჭერის ასისტენტი. რით შემიძლია დაგეხმაროთ?\n\nთუ გაინტერესებთ კერხერ-ცენტრების სამუშაო საათები, გაცნობებთ:\n\n• ყველა კერხერ-ცენტრი მუშაობს დილის 10:00-დან საღამოს 19:00-მდე.\n• გამონაკლისია **კერხერ-ცენტრი მეტრო სითი**, რომელიც მუშაობს დილის 10:00-დან საღამოს 22:00-მდე.	ai	\N	2026-05-27 05:35:59.431
cmpnmsimj000hy6mp92mnaau1	cmpnms22m0007y6mpvwk4qmue	user	სად არის მაღაზიები	user	\N	2026-05-27 05:36:12.62
cmpnmg3rr000r1p6qz2a4hpxp	cmpnmg057000n1p6qrcqzquzh	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ\n\nჩვენი კერხერ-ცენტრები მდებარეობს შემდეგ მისამართებზე:\n\n- **კერხერ ცენტრი დიღომი** — ა.ბელიაშვილის ქუჩა 167, თბილისი\n- **კერხერ ცენტრი საბურთალო** — ვაჟა-ფშაველას გამზ. 4, თბილისი\n- **კერხერ ცენტრი ბათუმი** — პ. ბაგრატიონის 129, ბათუმი\n- **კერხერ ცენტრი ქუთაისი** — შ.რუსთაველის გამზ. 96, ქუთაისი\n- **კერხერ ცენტრი ზუგდიდი** — დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n- **კერხერ ცენტრი თელავი** — ალაზნის გამზირი 71, თელავი\n- **კერხერ ცენტრი ხეივანი** — დ. აღმაშენებლის ხეივანი 193, თბილისი\n\n**სამუშაო საათები:**\n- ყველა კერხერ-ცენტრი მუშაობს **დილის 10:00-დან საღამოს 7:00-მდე**\n- გამონაკლისი: **კერხერ-ცენტრი მეტრო სითი (ბათუმი)** მუშაობს **დილის 10:00-დან საღამოს 10:00-მდე**\n\nდამატებითი ინფორმაციისთვის დაგვიკავშირდით ნომერზე: ☎ 032 238-03-06	ai	\N	2026-05-27 05:26:33.495
cmpnmhurg000v1p6q6a6spmts	cmpnmhur4000t1p6quvm28x19	user	სად ხართ	user	\N	2026-05-27 05:27:55.132
cmpnmhxfr000x1p6qksp7uapl	cmpnmhur4000t1p6quvm28x19	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ?\n\nჩვენი კერხერ-ცენტრები განთავსებულია შემდეგ მისამართებზე:\n\n- **თბილისი - დიღომი:** ა. ბელიაშვილის ქუჩა 167\n- **თბილისი - საბურთალო:** ვაჟა-ფშაველას გამზ. 4\n- **თბილისი - ხეივანი:** დ. აღმაშენებლის ხეივანი 193\n- **ბათუმი:** პ. ბაგრატიონის 129\n- **ქუთაისი:** შ. რუსთაველის გამზ. 96\n- **ზუგდიდი:** დ. აღმაშენებლის გამზირი 6\n- **თელავი:** ალაზნის გამზირი 71\n\nსამუშაო საათები: ყველა ცენტრი მუშაობს **10:00-დან 19:00-მდე**, გარდა **კერხერ-ცენტრი მეტრო სითი** (ბათუმი), რომელიც მუშაობს **10:00-დან 22:00-მდე**.	ai	\N	2026-05-27 05:27:58.599
cmpnmomg900111p6q77xz7bpb	cmpnmomft000z1p6qlousvl7j	user	გამარჯობა	user	\N	2026-05-27 05:33:10.954
cmpnmongc00131p6qwkifjb0h	cmpnmomft000z1p6qlousvl7j	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 05:33:12.253
cmpnmos9q00151p6qkkp878po	cmpnmomft000z1p6qlousvl7j	user	სად ხართ	user	\N	2026-05-27 05:33:18.494
cmpnmovya00171p6q0qf9ypc4	cmpnmomft000z1p6qlousvl7j	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ?\n\nკერხერ-ცენტრები მდებარეობს შემდეგ მისამართებზე:\n\n- **კერხერ ცენტრი დიღომი** — ა.ბელიაშვილის ქუჩა 167, თბილისი\n- **კერხერ ცენტრი საბურთალო** — ვაჟა-ფშაველას გამზ. 4, თბილისი\n- **კერხერ ცენტრი ხეივანი** — დ. აღმაშენებლის ხეივანი 193, თბილისი\n- **კერხერ ცენტრი ბათუმი** — პ. ბაგრატიონის 129, ბათუმი\n- **კერხერ ცენტრი ქუთაისი** — შ.რუსთაველის გამზ. 96, ქუთაისი\n- **კერხერ ცენტრი ზუგდიდი** — დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n- **კერხერ ცენტრი თელავი** — ალაზნის გამზირი 71, თელავი\n\n**სამუშაო საათები:**\n- ყველა ცენტრი მუშაობს **10:00 – 19:00** საათამდე\n- გამონაკლისი: **კერხერ-ცენტრი მეტრო სითი** (ბათუმი) მუშაობს **10:00 – 22:00** საათამდე\n\nდაგვიკავშირდით ტელეფონზე: **032 238-03-06** ან ელ. ფოსტაზე: **sales@karcher.ge**  / **service@karcher.ge**	ai	\N	2026-05-27 05:33:23.267
cmpnmq8ci0003y6mpj9r3yyde	cmpnmq8c00001y6mpt6g6d3ba	user	სად ხართ	user	\N	2026-05-27 05:34:25.987
cmpnmqbih0005y6mpb9mp7sul	cmpnmq8c00001y6mpt6g6d3ba	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ\n\nკერხერ-ცენტრები შემდეგ მისამართებზეა:\n\n- **კერხერ ცენტრი დიღომი** — ა.ბელიაშვილის ქუჩა 167, თბილისი\n- **კერხერ ცენტრი საბურთალო** — ვაჟა-ფშაველას გამზ. 4, თბილისი\n- **კერხერ ცენტრი ხეივანი** — დ. აღმაშენებლის ხეივანი 193, თბილისი\n- **კერხერ ცენტრი ბათუმი** — პ. ბაგრატიონის 129, ბათუმი\n- **კერხერ ცენტრი ქუთაისი** — შ.რუსთაველის გამზ. 96, ქუთაისი\n- **კერხერ ცენტრი ზუგდიდი** — დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n- **კერხერ ცენტრი თელავი** — ალაზნის გამზირი 71, თელავი\n\n**სამუშაო საათები:**\n- ყველა ცენტრი: **10:00 – 19:00**\n- გამონაკლისი: **კერხერ-ცენტრი მეტრო სითი** (ბათუმი) მუშაობს **10:00 – 22:00**	ai	\N	2026-05-27 05:34:30.089
cmpnms22v0009y6mpdzrnzmd1	cmpnms22m0007y6mpvwk4qmue	user	ჰაი	user	\N	2026-05-27 05:35:51.176
cmpnms34p000by6mpgtk998pc	cmpnms22m0007y6mpvwk4qmue	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ	ai	\N	2026-05-27 05:35:52.537
cmpnms6da000dy6mp1o91ymdi	cmpnms22m0007y6mpvwk4qmue	user	სად ხარ?	user	\N	2026-05-27 05:35:56.735
cmpnn59zi000p13e3mfnjt88v	cmpnn52st000j13e3lwwrdxq6	user	სად ხართ?	user	\N	2026-05-27 05:46:07.951
cmpnmslew000jy6mpoqy97n38	cmpnms22m0007y6mpvwk4qmue	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ?\n\nკერხერ-ცენტრები განთავსებულია შემდეგ მისამართებზე:\n\n• **კერხერ ცენტრი დიღომი** — ა.ბელიაშვილის ქუჩა 167, თბილისი\n• **კერხერ ცენტრი საბურთალო** — ვაჟა-ფშაველას გამზ. 4, თბილისი\n• **კერხერ ცენტრი ბათუმი** — პ. ბაგრატიონის 129, ბათუმი\n• **კერხერ ცენტრი ქუთაისი** — შ.რუსთაველის გამზ. 96, ქუთაისი\n• **კერხერ ცენტრი ზუგდიდი** — დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n• **კერხერ ცენტრი თელავი** — ალაზნის გამზირი 71, თელავი\n• **კერხერ ცენტრი ხეივანი** — დ. აღმაშენებლის ხეივანი 193, თბილისი	ai	\N	2026-05-27 05:36:16.228
cmpnmt9lt000ny6mp8ory5w2d	cmpnmt9ld000ly6mp5mgmkpbr	user	სად ხართ?	user	\N	2026-05-27 05:36:47.585
cmpnmtdj9000py6mpo2xdc8uj	cmpnmt9ld000ly6mp5mgmkpbr	assistant	გამარჯობა! ჩვენი კერხერ-ცენტრები განლაგებულია შემდეგ მისამართებზე:\n\n- **კერხერ ცენტრი დიღომი** — ა.ბელიაშვილის ქუჩა 167, თბილისი\n- **კერხერ ცენტრი საბურთალო** — ვაჟა-ფშაველას გამზ. 4, თბილისი\n- **კერხერ ცენტრი ხეივანი** — დ. აღმაშენებლის ხეივანი 193, თბილისი\n- **კერხერ ცენტრი ბათუმი** — პ. ბაგრატიონის 129, ბათუმი\n- **კერხერ ცენტრი ქუთაისი** — შ.რუსთაველის გამზ. 96, ქუთაისი\n- **კერხერ ცენტრი ზუგდიდი** — დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n- **კერხერ ცენტრი თელავი** — ალაზნის გამზირი 71, თელავი\n\n**სამუშაო საათები:**\n- ყველა კერხერ-ცენტრი მუშაობს **დილის 10:00-დან საღამოს 19:00-მდე**.\n- **გამონაკლისი:** კერხერ-ცენტრი **მეტრო სითი** (ბათუმი) მუშაობს **დილის 10:00-დან საღამოს 22:00-მდე**.\n\nდამატებითი ინფორმაციისთვის დაგვიკავშირდით ნომერზე: **032 238-03-06** ან მოგვწერეთ ელფოსტაზე: **sales@karcher.ge**.	ai	\N	2026-05-27 05:36:52.676
cmpnmvpso0003u2ra2htbxrs5	cmpnmvprv0001u2rasgaih3a4	user	სად ხართ	user	\N	2026-05-27 05:38:41.881
cmpnmvtv10005u2rax5dd75kv	cmpnmvprv0001u2rasgaih3a4	assistant	გამარჯობა! მე ვარ კერხერის ციფრული ასისტენტი. ჩვენი კერხერ-ცენტრები მდებარეობს შემდეგ მისამართებზე:\n\n- კერხერ ცენტრი დიღომი — ა.ბელიაშვილის ქუჩა 167, თბილისი\n- კერხერ ცენტრი საბურთალო — ვაჟა-ფშაველას გამზ. 4, თბილისი\n- კერხერ ცენტრი ხეივანი — დ. აღმაშენებლის ხეივანი 193, თბილისი\n- კერხერ ცენტრი ქუთაისი — შ.რუსთაველის გამზ. 96, ქუთაისი\n- კერხერ ცენტრი ბათუმი — პ. ბაგრატიონის 129, ბათუმი\n- კერხერ ცენტრი ზუგდიდი — დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n- კერხერ ცენტრი თელავი — ალაზნის გამზირი 71, თელავი\n\nსამუშაო საათები:\n- ყველა ცენტრი მუშაობს 10:00-დან 19:00-მდე\n- გამონაკლისი: კერხერ ცენტრი მეტრო სითი (ბათუმი) მუშაობს 10:00-დან 22:00-მდე\n\nდაგვიკავშირდით ნომერზე: 032 238-03-06 ან ელფოსტით: sales@karcher.ge	ai	\N	2026-05-27 05:38:47.15
cmpnmxhp20009u2rakxxkb5cr	cmpnmxhmm0007u2ra91ntklwj	user	gamarjoba, sad xart?	user	\N	2026-05-27 05:40:04.693
cmpnmxjii000bu2ra92hwyrzi	cmpnmxhmm0007u2ra91ntklwj	assistant	გამარჯობა! მე კარგად ვარ, გმადლობ! როგორ ხარ? რით შემიძლია დაგეხმარო?	ai	\N	2026-05-27 05:40:07.05
cmpnmxqdo000du2raonj7s0m2	cmpnmxhmm0007u2ra91ntklwj	user	sad aris magaziebi	user	\N	2026-05-27 05:40:15.949
cmpnmxthp000fu2ray5u96mz2	cmpnmxhmm0007u2ra91ntklwj	assistant	აი, სად მდებარეობს ყველა კერხერ-ცენტრი:\n\n• კერხერ ცენტრი დიღომი - ა.ბელიაშვილის ქუჩა 167, თბილისი\n• კერხერ ცენტრი საბურთალო - ვაჟა-ფშაველას გამზ. 4, თბილისი\n• კერხერ ცენტრი ბათუმი - პ. ბაგრატიონის 129, ბათუმი\n• კერხერ ცენტრი ქუთაისი - შ.რუსთაველის გამზ. 96, ქუთაისი\n• კერხერ ცენტრი ზუგდიდი - დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n• კერხერ ცენტრი თელავი - ალაზნის გამზირი 71, თელავი\n• კერხერ ცენტრი ხეივანი - დ. აღმაშენებლის ხეივანი 193, თბილისი\n\nსამუშაო საათები:\n• ყველა კერხერ-ცენტრი მუშაობს დილის 10-დან საღამოს 7-მდე\n• გარდა კერხერ-ცენტრი მეტრო სითი, რომელიც მუშაობს დილის 10-დან საღამოს 10-მდე	ai	\N	2026-05-27 05:40:19.982
cmpnmyccx000hu2ra2fagiir7	cmpnmxhmm0007u2ra91ntklwj	user	mtversasruti minda	user	\N	2026-05-27 05:40:44.433
cmpno2xit001tmzcclktwb3nd	cmpno1x0y001fmzccp61q8aa8	user	და რა ვუთხრა	user	\N	2026-05-27 06:12:18.101
cmpnywp810009wutrxi9ghtr2	cmpnywj0t0003wutryxu8ji9v	user	გადამრთე ადამიანთან	user	\N	2026-05-27 11:15:23.185
cmpnz0q0f000793pwdctx6dy4	cmpnz0pzl000593pwgfzj7c94	user	Hello, I need help with an agent	user	\N	2026-05-27 11:18:30.831
cmpnmygx0000ju2ray2tngiv1	cmpnmxhmm0007u2ra91ntklwj	assistant	გმადლობთ კითხვისთვის! მტვერსასრუტების შესახებ ინფორმაცია შეგიძლიათ იხილოთ ჩვენს ონლაინ მაღაზიაში ან გვეწვიოთ ნებისმიერ კერხერ-ცენტრში.\n\nსამუშაო საათები:\n• ყველა კერხერ-ცენტრი მუშაობს დილის 10-დან საღამოს 7-მდე\n• გარდა კერხერ-ცენტრი მეტრო სითი, რომელიც მუშაობს დილის 10-დან საღამოს 10-მდე\n\nკერხერ-ცენტრების მისამართები:\n• კერხერ ცენტრი დიღომი - ა.ბელიაშვილის ქუჩა 167, თბილისი\n• კერხერ ცენტრი საბურთალო - ვაჟა-ფშაველას გამზ. 4, თბილისი\n• კერხერ ცენტრი ბათუმი - პ. ბაგრატიონის 129, ბათუმი\n• კერხერ ცენტრი ქუთაისი - შ.რუსთაველის გამზ. 96, ქუთაისი\n• კერხერ ცენტრი ზუგდიდი - დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n• კერხერ ცენტრი თელავი - ალაზნის გამზირი 71, თელავი\n• კერხერ ცენტრი ხეივანი - დ. აღმაშენებლის ხეივანი 193, თბილისი\n\nკონკრეტულად რა ტიპის მტვერსასრუტი გაინტერესებთ? მაგალითად, ჩვეულებრივი მტვერსასრუტი, სველი წმენდის მტვერსასრუტი, რობოტი მტვერსასრუტი თუ სხვა?	ai	\N	2026-05-27 05:40:50.34
cmpnmyyh8000lu2raqyae2ml6	cmpnmxhmm0007u2ra91ntklwj	user	chveulebrivi minda	user	\N	2026-05-27 05:41:13.1
cmpnmz3wv000nu2raogs0xqrx	cmpnmxhmm0007u2ra91ntklwj	assistant	კარგი, გაიგე. აი, ინფორმაცია ჩვეულებრივი მტვერსასრუტების შესახებ:\n\nჩვენ გვაქვს სხვადასხვა ტიპის მტვერსასრუტები, მათ შორის:\n• ჩვეულებრივი მტვერსასრუტები\n• სველი წმენდის მტვერსასრუტები\n• რობოტი მტვერსასრუტები\n• ელექტრო ცოცხები\n\nთქვენ შეგიძლიათ ნახოთ ჩვეულებრივი მტვერსასრუტების ასორტიმენტი ჩვენს ონლაინ მაღაზიაში ან პირადად ეწვიოთ ნებისმიერ კერხერ-ცენტრს.\n\nსამუშაო საათები:\n• ყველა კერხერ-ცენტრი მუშაობს დილის 10-დან საღამოს 7-მდე\n• გარდა კერხერ-ცენტრი მეტრო სითი, რომელიც მუშაობს დილის 10-დან საღამოს 10-მდე\n\nკერხერ-ცენტრების მისამართები:\n• კერხერ ცენტრი დიღომი - ა.ბელიაშვილის ქუჩა 167, თბილისი\n• კერხერ ცენტრი საბურთალო - ვაჟა-ფშაველას გამზ. 4, თბილისი\n• კერხერ ცენტრი ბათუმი - პ. ბაგრატიონის 129, ბათუმი\n• კერხერ ცენტრი ქუთაისი - შ.რუსთაველის გამზ. 96, ქუთაისი\n• კერხერ ცენტრი ზუგდიდი - დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n• კერხერ ცენტრი თელავი - ალაზნის გამზირი 71, თელავი\n• კერხერ ცენტრი ხეივანი - დ. აღმაშენებლის ხეივანი 193, თბილისი\n\nგთხოვთ, დაგვიკავშირდით ტელეფონით: 032 238-03-06, რათა უფრო დეტალური ინფორმაცია მიიღოთ მოდელებისა და ფასების შესახებ.	ai	\N	2026-05-27 05:41:20.144
cmpnn12w800031qbjg0ewnqq7	cmpnn12vk00011qbjvxxf3yfz	user	როგორი ამინდია დღეს	user	\N	2026-05-27 05:42:52.137
cmpnn15kk00051qbjpl6j9y9c	cmpnn12vk00011qbjvxxf3yfz	assistant	მე ვერ მოგაწვდი ინფორმაციას დღევანდელი ამინდის შესახებ, რადგან ამისთვის საჭირო მონაცემები არ მაქვს.\n\nთუ გინდა, შემიძლია გითხრა კერხერ-ცენტრების სამუშაო საათების შესახებ:\n\n- ყველა კერხერ-ცენტრი მუშაობს დილის 10-დან საღამოს 7-მდე\n- გამონაკლისია კერხერ-ცენტრი მეტრო სითი, რომელიც მუშაობს დილის 10-დან საღამოს 10-მდე	ai	\N	2026-05-27 05:42:55.604
cmpnn15pb00091qbj9maipxb7	cmpnn15ov00071qbjx7rmgzih	user	სად იყიდება კერხერი	user	\N	2026-05-27 05:42:55.775
cmpnn17zv000b1qbj29q01v5p	cmpnn15ov00071qbjx7rmgzih	assistant	კერხერის პროდუქციის შეძენა შეგიძლიათ:\n\n• კერხერის ოფიციალურ ონლაინ მაღაზიაში – karcher.ge\n• კერხერ-ცენტრებში საქართველოს სხვადასხვა ქალაქში\n\nკერხერ-ცენტრები მუშაობს:\n  * ყველა ცენტრი – დილის 10-დან საღამოს 7-მდე\n  * კერხერ-ცენტრი მეტრო სითი (ბათუმი) – დილის 10-დან საღამოს 10-მდე	ai	\N	2026-05-27 05:42:58.747
cmpnn217x000313e3ohey2y1u	cmpnn217g000113e3rxvkyuhc	user	როგორი ამინდია	user	\N	2026-05-27 05:43:36.621
cmpnn23dz000513e385soml3w	cmpnn217g000113e3rxvkyuhc	assistant	მე ვარ კერხერის დამხმარე ასისტენტი და ვპასუხობ კითხვებს კომპანიის პროდუქტებზე, მომსახურებასა და მაღაზიებზე. ამინდის შესახებ ინფორმაცია არ მაქვს. გთხოვთ, დამისვათ შეკითხვა კერხერთან დაკავშირებით.	ai	\N	2026-05-27 05:43:39.431
cmpnn23j1000913e34csqs8wo	cmpnn23iv000713e3bo08lmu2	user	სად იყიდება კერხერი	user	\N	2026-05-27 05:43:39.614
cmpnn278i000b13e3clcpj8z0	cmpnn23iv000713e3bo08lmu2	assistant	კერხერის პროდუქციის შეძენა შეგიძლიათ:\n\n1. **კერხერის ოფიციალურ ონლაინ მაღაზიაში** — karcher.ge\n2. **კერხერ ცენტრებში** შემდეგ მისამართებზე:\n   * კერხერ ცენტრი დიღომი — ა.ბელიაშვილის ქ. 167, თბილისი\n   * კერხერ ცენტრი საბურთალო — ვაჟა-ფშაველას გამზ. 4, თბილისი\n   * კერხერ ცენტრი ხეივანი — დ. აღმაშენებლის ხეივანი 193, თბილისი\n   * კერხერ ცენტრი ბათუმი — პ. ბაგრატიონის 129, ბათუმი\n   * კერხერ ცენტრი ქუთაისი — შ.რუსთაველის გამზ. 96, ქუთაისი\n   * კერხერ ცენტრი ზუგდიდი — დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n   * კერხერ ცენტრი თელავი — ალაზნის გამზირი 71, თელავი\n\n**სამუშაო საათები:**\n* ყველა კერხერ-ცენტრი მუშაობს დილის 10-დან საღამოს 7-მდე\n* გამონაკლისი: კერხერ-ცენტრი მეტრო სითი (ბათუმი) მუშაობს დილის 10-დან საღამოს 10-მდე	ai	\N	2026-05-27 05:43:44.418
cmpnn2if3000f13e39m52guk2	cmpnn2iep000d13e30g7rmkyl	user	გამარჯობა	user	\N	2026-05-27 05:43:58.911
cmpnn2jmq000h13e3wb1i3kwr	cmpnn2iep000d13e30g7rmkyl	assistant	გამარჯობა! 👋\n\nროგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 05:44:00.483
cmpnn52u5000l13e39236xxky	cmpnn52st000j13e3lwwrdxq6	user	გამარჯობა	user	\N	2026-05-27 05:45:58.685
cmpnn557q000n13e3drvothnm	cmpnn52st000j13e3lwwrdxq6	assistant	გამარჯობა! 👋\n\nმოგესალმებით Demo Company-ში. როგორ შემიძლია დაგეხმაროთ?\n\nთუ გაინტერესებთ **კერხერ-ცენტრების სამუშაო საათები**, გთხოვთ, გაითვალისწინოთ:\n\n- ყველა კერხერ-ცენტრი მუშაობს **დილის 10:00-დან საღამოს 7:00-მდე**.\n- გამონაკლისია **კერხერ-ცენტრი მეტრო სითი**, რომელიც მუშაობს **დილის 10:00-დან საღამოს 10:00-მდე**.\n\nრით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 05:46:01.766
cmpnn5drd000r13e3jbcn003k	cmpnn52st000j13e3lwwrdxq6	assistant	ჩვენი კერხერ-ცენტრები განლაგებულია შემდეგ მისამართებზე:\n\n• **კერხერ ცენტრი დიღომი** — ა.ბელიაშვილის ქუჩა 167, თბილისი\n• **კერხერ ცენტრი საბურთალო** — ვაჟა-ფშაველას გამზ. 4, თბილისი\n• **კერხერ ცენტრი ხეივანი** — დ. აღმაშენებლის ხეივანი 193, თბილისი\n• **კერხერ ცენტრი ბათუმი** — პ. ბაგრატიონის 129, ბათუმი\n• **კერხერ ცენტრი ქუთაისი** — შ. რუსთაველის გამზ. 96, ქუთაისი\n• **კერხერ ცენტრი ზუგდიდი** — დ. აღმაშენებლის გამზირი 6, ზუგდიდი\n• **კერხერ ცენტრი თელავი** — ალაზნის გამზირი 71, თელავი\n\n**სამუშაო საათები:**\n\n• ყველა კერხერ-ცენტრი მუშაობს **დილის 10:00-დან საღამოს 7:00-მდე**.\n• გამონაკლისია **კერხერ-ცენტრი მეტრო სითი**, რომელიც მუშაობს **დილის 10:00-დან საღამოს 10:00-მდე**.\n\nდამატებითი ინფორმაციისთვის დაგვიკავშირდით ტელეფონზე: **032 238-03-06**.	ai	\N	2026-05-27 05:46:12.841
cmpnn5s7y000t13e3xxbcj7fm	cmpnn52st000j13e3lwwrdxq6	user	მირჩიე მაღალი წნევით რეცხვის აპარატი	user	\N	2026-05-27 05:46:31.582
cmpnn5xba000v13e3qm2d2k9k	cmpnn52st000j13e3lwwrdxq6	assistant	რა თქმა უნდა! გთავაზობთ მაღალი წნევით რეცხვის აპარატების რამდენიმე მოდელს, რომლებიც ხელმისაწვდომია ჩვენს ონლაინ მაღაზიაში:\n\n• **K Silent Anniversary Edition** — რეგულარული ფასი 795 ₾, გასაყიდი ფასი 588.30 ₾ (დანაზოგი 26%)\n• **K 4 Power Control Flex** — რეგულარული ფასი 995 ₾, გასაყიდი ფასი 736.30 ₾ (დანაზოგი 26%)\n• **K3 Classic** — რეგულარული ფასი 495 ₾, გასაყიდი ფასი 366.30 ₾ (დანაზოგი 26%)\n• **K5 COMPACT** — რეგულარული ფასი 1,150 ₾, გასაყიდი ფასი 851 ₾ (დანაზოგი 26%)\n• **K4 COMPACT** — რეგულარული ფასი 895 ₾, გასაყიდი ფასი 662.30 ₾ (დანაზოგი 26%)\n• **K3 POWER CONTROL** — რეგულარული ფასი 595 ₾, გასაყიდი ფასი 440.30 ₾ (დანაზოგი 26%)\n\nთუ გსურთ რეკომენდაცია, გთხოვთ მიმითითოთ:\n- რა მიზნით გჭირდებათ აპარატი (სახლის, ბაღის თუ პროფესიული გამოყენება)\n- რა ბიუჯეტი გაქვთ\n\nდამატებითი ინფორმაციისთვის ან შესაძენად, შეგიძლიათ ეწვიოთ ჩვენს ონლაინ მაღაზიას ან ერთ-ერთ კერხერ-ცენტრს.	ai	\N	2026-05-27 05:46:38.182
cmpnn6e7o000x13e3maku5ofl	cmpnn52st000j13e3lwwrdxq6	user	ეზოში მინდა ჩემი სონატა რომ გავრეცხო ხოლმე და ხანდახან მოტოც	user	\N	2026-05-27 05:47:00.084
cmpnn6ju3000z13e34uykliwi	cmpnn52st000j13e3lwwrdxq6	assistant	შესანიშნავი არჩევანია! ავტომობილისა და მოტოციკლის რეცხვისთვის გირჩევთ შემდეგ მოდელებს:\n\n• **K3 Classic** — 495 ₾ (ფასდაკლებით 366.30 ₾). კომპაქტური, მარტივი გამოსაყენებელი, იდეალურია მანქანისა და მოტოციკლის პერიოდული რეცხვისთვის.\n• **K3 POWER CONTROL** — 595 ₾ (ფასდაკლებით 440.30 ₾). აქვს წნევის რეგულირების ფუნქცია, რაც მნიშვნელოვანია მოტოციკლის ნაზი რეცხვისთვის.\n• **K Silent Anniversary Edition** — 795 ₾ (ფასდაკლებით 588.30 ₾). მშვიდი მუშაობა, მაღალი ეფექტურობა, შესაფერისია როგორც მანქანის, ასევე მოტოციკლისთვის.\n\n**რჩევა:** მოტოციკლის რეცხვისას გირჩევთ გამოიყენოთ ნაკლები წნევა, რათა არ დააზიანოთ ძრავის ნაწილები. K3 POWER CONTROL იდეალური არჩევანია ამისთვის, რადგან წნევის რეგულირება შეგიძლიათ.\n\n**სამუშაო საათები:**\n\n• ყველა კერხერ-ცენტრი მუშაობს **დილის 10:00-დან საღამოს 7:00-მდე**.\n• გამონაკლისია **კერხერ-ცენტრი მეტრო სითი**, რომელიც მუშაობს **დილის 10:00-დან საღამოს 10:00-მდე**.\n\nშეგიძლიათ მობრძანდეთ ნებისმიერ კერხერ-ცენტრში, სადაც ჩვენი სპეციალისტები დაგეხმარებიან არჩევანში.	ai	\N	2026-05-27 05:47:07.371
cmpnn8z6e001313e3ktzw1wl6	cmpnn8z4y001113e3p8dlwefa	user	როგორი ამინდია	user	\N	2026-05-27 05:49:00.566
cmpnn90qc001513e3n29ykjxq	cmpnn8z4y001113e3p8dlwefa	assistant	მე მხოლოდ იმ ინფორმაციაზე მაქვს წვდომა, რაც ჩემს ცოდნის ბაზაშია. ამინდის შესახებ ინფორმაცია არ მაქვს.	ai	\N	2026-05-27 05:49:02.576
cmpnn9139001913e3k35c7rie	cmpnn912v001713e3mpso7esq	user	სად ხართ	user	\N	2026-05-27 05:49:03.045
cmpnn94gy001b13e35mfxouxr	cmpnn912v001713e3mpso7esq	assistant	გამარჯობა! მე ვარ კერხერის ციფრული ასისტენტი. ჩვენი კერხერ-ცენტრები მდებარეობს შემდეგ მისამართებზე:\n\n• კერხერ ცენტრი დიღომი — ა.ბელიაშვილის ქუჩა 167, თბილისი\n• კერხერ ცენტრი საბურთალო — ვაჟა-ფშაველას გამზ. 4, თბილისი\n• კერხერ ცენტრი ხეივანი — დ. აღმაშენებლის ხეივანი 193, თბილისი\n• კერხერ ცენტრი ქუთაისი — შ.რუსთაველის გამზ. 96, ქუთაისი\n• კერხერ ცენტრი ბათუმი — პ. ბაგრატიონის 129, ბათუმი\n• კერხერ ცენტრი ზუგდიდი — დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n• კერხერ ცენტრი თელავი — ალაზნის გამზირი 71, თელავი\n\nსამუშაო საათები: ყველა ცენტრი მუშაობს 10:00-დან 19:00-მდე, გარდა კერხერ-ცენტრი მეტრო სითი (ბათუმი), რომელიც მუშაობს 10:00-დან 22:00-მდე.	ai	\N	2026-05-27 05:49:07.426
cmpnnb293001f13e3freefpi0	cmpnnb28h001d13e3vwbxsp1t	user	ქიმწმენდა მინდა	user	\N	2026-05-27 05:50:37.863
cmpnnb5s0001h13e34fmbrl1x	cmpnnb28h001d13e3vwbxsp1t	assistant	მოგესალმებით! ქიმწმენდის აპარატები კერხერის ასორტიმენტშია. აი, რა შემიძლია გითხრათ:\n\n  * ქიმწმენდის აპარატი cleaner SE 2 Spot Care — ფასი 333.00 ₾ (რეგულარული ფასი 450.00 ₾, დანაზოგი 26%).\n\nთუ გსურთ, რომ ნახოთ ან შეიძინოთ ეს აპარატი, შეგიძლიათ ეწვიოთ ნებისმიერ კერხერ-ცენტრს. აი სამუშაო საათები:\n\n  * ყველა კერხერ-ცენტრი მუშაობს დილის 10-დან საღამოს 7-მდე.\n  * გამონაკლისია კერხერ-ცენტრი მეტრო სითი, რომელიც მუშაობს დილის 10-დან საღამოს 10-მდე.\n\nდამატებითი ინფორმაციისთვის ან დახმარებისთვის, მომწერეთ.	ai	\N	2026-05-27 05:50:42.433
cmpnnbla1001j13e31d2io0vf	cmpnnb28h001d13e3vwbxsp1t	user	როდემდეა აქცია?	user	\N	2026-05-27 05:51:02.522
cmpnnboa3001l13e3o5ivsafq	cmpnnb28h001d13e3vwbxsp1t	assistant	აქციის შესახებ ზუსტი ინფორმაცია არ მაქვს, რადგან ჩემს ბაზაში მითითებულია მხოლოდ მიმდინარე ფასები (მაგალითად, cleaner SE 2 Spot Care-ზე 26%-იანი ფასდაკლება). გირჩევთ, დაგვიკავშირდეთ ტელეფონზე 032 238-03-06 ან მობრძანდეთ ნებისმიერ კერხერ-ცენტრში, სადაც ზუსტად გეტყვიან აქციის დასრულების თარიღს.\n\n  * ყველა კერხერ-ცენტრი მუშაობს დილის 10-დან საღამოს 7-მდე.\n  * გამონაკლისია კერხერ-ცენტრი მეტრო სითი, რომელიც მუშაობს დილის 10-დან საღამოს 10-მდე.	ai	\N	2026-05-27 05:51:06.412
cmpnncjah001p13e3w0cdylqh	cmpnncja3001n13e3is3r38f9	user	როგორი ამინდია	user	\N	2026-05-27 05:51:46.601
cmpnncktt001r13e3ygxb0jtb	cmpnncja3001n13e3is3r38f9	assistant	სამწუხაროდ, ამინდის შესახებ ინფორმაცია არ მაქვს. მე მხოლოდ კერხერის პროდუქტებსა და მომსახურებაზე შემიძლია გიპასუხოთ.	ai	\N	2026-05-27 05:51:48.593
cmpnndvon0003qu8jp2aeu1wh	cmpnndvnl0001qu8jxoees8hu	user	როგორი ამინდია	user	\N	2026-05-27 05:52:49.319
cmpnndya50005qu8j7ko1x5mx	cmpnndvnl0001qu8jxoees8hu	assistant	ვერ გეტყვით, რადგან მე არ მაქვს რეალურ დროში ამინდის შესახებ ინფორმაციის მიღების შესაძლებლობა. \n\nთუ გსურთ, შემიძლია დაგეხმაროთ:\n- კერხერის პროდუქტების შესახებ ინფორმაციით\n- კერხერ ცენტრების მისამართებითა და სამუშაო საათებით\n- სხვა კითხვებზე პასუხის გაცემით	ai	\N	2026-05-27 05:52:52.685
cmpnndyci0009qu8jw9tl7rnd	cmpnndyc90007qu8jswd350p9	user	რომლამდე მუშაობთ	user	\N	2026-05-27 05:52:52.77
cmpnndzuh000bqu8j5gctppsu	cmpnndyc90007qu8jswd350p9	assistant	კერხერ-ცენტრები მუშაობს:\n\n- ყველა კერხერ-ცენტრი: დილის 10-დან საღამოს 7-მდე\n- კერხერ-ცენტრი მეტრო სითი (ბათუმი): დილის 10-დან საღამოს 10-მდე	ai	\N	2026-05-27 05:52:54.713
cmpnndzwx000fqu8jqo55916d	cmpnndzwn000dqu8j4nfif3mt	user	სად ხართ	user	\N	2026-05-27 05:52:54.8
cmpnne41c000hqu8jg8y0cj7c	cmpnndzwn000dqu8j4nfif3mt	assistant	მე ვარ ხელოვნური ინტელექტის ასისტენტი. ჩემი ფიზიკური მდებარეობა არ მაქვს, მაგრამ მე წარმოვადგენ Kärcher Georgia-ს.\n\nთუ გაინტერესებთ კერხერ ცენტრების მისამართები, აი ისინი:\n\n- კერხერ ცენტრი დიღომი — ა.ბელიაშვილის ქუჩა 167, თბილისი\n- კერხერ ცენტრი საბურთალო — ვაჟა-ფშაველას გამზ. 4, თბილისი\n- კერხერ ცენტრი ხეივანი — დ. აღმაშენებლის ხეივანი 193, თბილისი\n- კერხერ ცენტრი ბათუმი — პ. ბაგრატიონის 129, ბათუმი\n- კერხერ ცენტრი ქუთაისი — შ.რუსთაველის გამზ. 96, ქუთაისი\n- კერხერ ცენტრი ზუგდიდი — დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n- კერხერ ცენტრი თელავი — ალაზნის გამზირი 71, თელავი\n\nსამუშაო საათები:\n- ყველა კერხერ ცენტრი მუშაობს 10:00-დან 19:00-მდე\n- კერხერ ცენტრი მეტრო სითი მუშაობს 10:00-დან 22:00-მდე\n\nტელეფონი: 032 238-03-06	ai	\N	2026-05-27 05:53:00.144
cmpnnfato000lqu8jrhqav5bw	cmpnnfasg000jqu8jki0qiw9d	user	ჰაი	user	\N	2026-05-27 05:53:55.596
cmpnnfc63000nqu8j9zpnonqn	cmpnnfasg000jqu8jki0qiw9d	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 05:53:57.34
cmpnnfjc6000pqu8jhwazpspe	cmpnnfasg000jqu8jki0qiw9d	user	რობოტი მინდა	user	\N	2026-05-27 05:54:06.63
cmpnnfm5z000rqu8jjp9eiakb	cmpnnfasg000jqu8jki0qiw9d	assistant	რა თქმა უნდა! Kärcher-ში წარმოდგენილია რობოტი მტვერსასრუტების რამდენიმე მოდელი. აი ჩამონათვალი:\n\n• RVF 7\n• RVM 4 Comfort Extra\n• RVC 3\n• RVC 3 Comfort\n• RVF 7 Comfort + SC 1 Multi&Up (კომბო ნაკრები)\n\nთუ გაინტერესებთ რომელიმე კონკრეტული მოდელის ფასი ან მახასიათებლები, მითხარით და დაგეხმარებით.\n\nასევე, ყველა კერხერ-ცენტრი მუშაობს **დილის 10-დან საღამოს 7-მდე**, გარდა კერხერ-ცენტრი მეტრო სითისა, რომელიც მუშაობს **დილის 10-დან საღამოს 10-მდე**.	ai	\N	2026-05-27 05:54:10.293
cmpnnfutr000tqu8jj64w8phq	cmpnnfasg000jqu8jki0qiw9d	user	ყველაზე ბიუჯეტური რა ღირს	user	\N	2026-05-27 05:54:21.519
cmpnnfwsy000vqu8jdxfusk15	cmpnnfasg000jqu8jki0qiw9d	assistant	ყველაზე ბიუჯეტური რობოტი მტვერსასრუტია **RVC 3**. მისი ფასია:\n\n• **537.00 ₾** (ფასდაკლებით, რეგულარული ფასი იყო 895.00 ₾)\n\nთუ გსურთ, შემიძლია დაგეხმაროთ სხვა მოდელების ფასებისა და მახასიათებლების შედარებაში.	ai	\N	2026-05-27 05:54:24.082
cmpnnge76000xqu8jl7j6n9o6	cmpnnfasg000jqu8jki0qiw9d	user	ყველაზე ძვირიანს შემიდარე	user	\N	2026-05-27 05:54:46.626
cmpnz0q65000993pwym2152uw	cmpn5aixt0011tex1kcpzkra8	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:18:31.038
cmpnz0r1n000b93pwdyz2dz2j	cmpnz0pzl000593pwgfzj7c94	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 11:18:32.172
cmpnngh3e000zqu8j43ofdbuu	cmpnnfasg000jqu8jki0qiw9d	assistant	აი, Kärcher-ის რობოტი მტვერსასრუტების ფასები ზრდადობით:\n\n• **RVC 3** – 537.00 ₾\n• **RVC 3 Comfort** – 777.00 ₾\n• **RVM 4 Comfort Extra** – 1,437.00 ₾\n• **RVF 7** – 1,677.00 ₾\n• **RVF 7 Comfort + SC 1 Multi&Up** (კომბო ნაკრები) – 3,999.00 ₾\n\nყველაზე ძვირიანია **RVF 7 Comfort + SC 1 Multi&Up** – 3,999.00 ₾. ეს არის კომბო ნაკრები, რომელიც მოიცავს როგორც რობოტ მტვერსასრუტს, ასევე ორთქლის აპარატს.\n\nყველა კერხერ-ცენტრი მუშაობს **დილის 10-დან საღამოს 7-მდე**, გარდა კერხერ-ცენტრი მეტრო სითისა, რომელიც მუშაობს **დილის 10-დან საღამოს 10-მდე**.	ai	\N	2026-05-27 05:54:50.378
cmpnnji580003q910zqyk2w39	cmpnnji4h0001q910rex6uajb	user	რა ღირს karcher-ის რობოტი მტვერსასრუტები?	user	\N	2026-05-27 05:57:11.708
cmpnnjjkx0005q9105us1037h	cmpnnji4h0001q910rex6uajb	assistant	რობოტი მტვერსასრუტების ფასები:\n\n- RVF 7 — 1,677.00 ₾\n- RVM 4 Comfort Extra — 1,437.00 ₾\n- RVC 3 — 537.00 ₾\n- RVC 3 Comfort — 777.00 ₾	ai	\N	2026-05-27 05:57:13.569
cmpnnjos00009q9108hnotigj	cmpnnjorn0007q9109xla6rr6	user	რომლამდე მუშაობთ	user	\N	2026-05-27 05:57:20.304
cmpnnjq98000bq910f1b19pwz	cmpnnjorn0007q9109xla6rr6	assistant	ყველა კერხერ-ცენტრი მუშაობს:\n\n- დილის 10-დან საღამოს 7-მდე\n\n- გამონაკლისია კერხერ-ცენტრი მეტრო სითი, რომელიც მუშაობს დილის 10-დან საღამოს 10-მდე	ai	\N	2026-05-27 05:57:22.221
cmpnnjqbf000fq910q9xsq6cv	cmpnnjqb4000dq9106cp6k8j5	user	მისამართები	user	\N	2026-05-27 05:57:22.3
cmpnnjsvt000hq910vqj7vp6e	cmpnnjqb4000dq9106cp6k8j5	assistant	რა თქმა უნდა, აი, კერხერის ცენტრების მისამართები საქართველოში:\n\n- კერხერ ცენტრი დიღომი: ა.ბელიაშვილის ქუჩა 167, თბილისი\n- კერხერ ცენტრი საბურთალო: ვაჟა-ფშაველას გამზ. 4, თბილისი\n- კერხერ ცენტრი ბათუმი: პ. ბაგრატიონის 129, ბათუმი\n- კერხერ ცენტრი ქუთაისი: შ.რუსთაველის გამზ. 96, ქუთაისი\n- კერხერ ცენტრი ზუგდიდი: დ.აღმაშენებლის გამზირი 6, ზუგდიდი\n- კერხერ ცენტრი თელავი: ალაზნის გამზირი 71, თელავი\n- კერხერ ცენტრი ხეივანი: დ. აღმაშენებლის ხეივანი 193, თბილისი	ai	\N	2026-05-27 05:57:25.626
cmpnnjsyo000lq9103fd0rx0s	cmpnnjsye000jq910sjpmole9	user	როგორი ამინდია	user	\N	2026-05-27 05:57:25.728
cmpnnju0p000nq910dj5qwl7p	cmpnnjsye000jq910sjpmole9	assistant	სამწუხაროდ, მე არ მაქვს ინფორმაცია მიმდინარე ამინდის შესახებ.	ai	\N	2026-05-27 05:57:27.096
cmpnnkqf2000rq910eul3vx72	cmpnnkqe1000pq910krgkntwc	user	ჰაი	user	\N	2026-05-27 05:58:09.087
cmpnnkrvt000tq910qbu3o4gi	cmpnnkqe1000pq910krgkntwc	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 05:58:10.986
cmpnnl6sq000vq910s6pr5l0l	cmpnnkqe1000pq910krgkntwc	user	გაზონის საკრეჭი მინდა	user	\N	2026-05-27 05:58:30.314
cmpnnl8v0000xq91020uxxgee	cmpnnkqe1000pq910krgkntwc	assistant	გაზონის სათიბი (გაზონის საკრეჭი) შეგიძლიათ შეიძინოთ ჩვენს მაღაზიაში. აი, რომლამდე მუშაობს კერხერ-ცენტრები:\n\n• ყველა კერხერ-ცენტრი მუშაობს დილის 10-დან საღამოს 7-მდე\n• გარდა კერხერ-ცენტრი მეტრო სითისა, რომელიც მუშაობს დილის 10-დან საღამოს 10-მდე	ai	\N	2026-05-27 05:58:32.988
cmpnnlif9000zq910eink0qgv	cmpnnkqe1000pq910krgkntwc	user	რა ღირს	user	\N	2026-05-27 05:58:45.382
cmpnnlk910011q910yz9g50gy	cmpnnkqe1000pq910krgkntwc	assistant	თქვენ იკითხეთ ფასი — გაზონის სათიბების ფასები ჩვენს ონლაინ მაღაზიაში არ არის მითითებული. გთხოვთ, მიმართოთ ჩვენს კერხერ-ცენტრებს ან ონლაინ მაღაზიას ზუსტი ფასების გასაგებად.	ai	\N	2026-05-27 05:58:47.749
cmpnnlymi0013q910dzb85rhc	cmpnnkqe1000pq910krgkntwc	user	მაშინ პატარა მტვერსასრუტი მინდა მანქანისთვის	user	\N	2026-05-27 05:59:06.379
cmpnnm1850015q910y8vi8bzu	cmpnnkqe1000pq910krgkntwc	assistant	რა თქმა უნდა! მანქანისთვის პატარა მტვერსასრუტები ჩვენს ასორტიმენტშია.\n\nრაც შეეხება სამუშაო საათებს:\n\n• ყველა კერხერ-ცენტრი მუშაობს დილის 10-დან საღამოს 7-მდე\n• გარდა კერხერ-ცენტრი მეტრო სითისა, რომელიც მუშაობს დილის 10-დან საღამოს 10-მდე\n\nკონკრეტული მოდელების შესარჩევად გირჩევთ, ეწვიოთ ჩვენს მაღაზიას ან ონლაინ კატალოგს.	ai	\N	2026-05-27 05:59:09.749
cmpnnmbmj0017q910ak5rrbwl	cmpnnkqe1000pq910krgkntwc	user	მირჩიე აპარატი	user	\N	2026-05-27 05:59:23.227
cmpno2z7t001vmzccdamf1exo	cmpno1x0y001fmzccp61q8aa8	assistant	უთხარით, რომ შეიძინეთ მტვერსასრუტი, მაგრამ ყუთი ცარიელი აღმოჩნდა. ისინი დაგეხმარებიან შემდგომში.	ai	\N	2026-05-27 06:12:20.297
cmpnywqt8000bwutrf5pg6a0f	cmpnywj0t0003wutryxu8ji9v	assistant	სამწუხაროდ, მე ვერ გადაგიყვანთ ადამიანთან. გთხოვთ, დაგვიკავშირდეთ ტელეფონით: 032 238-03-06 ან მოგვწეროთ ელ.ფოსტაზე: sales@karcher.ge.	ai	\N	2026-05-27 11:15:25.244
cmpnnmer90019q910tgt4yhtl	cmpnnkqe1000pq910krgkntwc	assistant	რა თქმა უნდა! მანქანისთვის პატარა მტვერსასრუტის ასარჩევად გირჩევთ შემდეგს:\n\n• **რობოტი მტვერსასრუტი RVC 3** — კომპაქტური, მარტივი გამოსაყენებელი\n• **ელექტრო ცოცხები** — მსუბუქი წონა, იდეალურია მანქანის სალონისთვის\n\nრაც შეეხება მუშაობის საათებს:\n\n• **ყველა კერხერ-ცენტრი** მუშაობს დილის 10-დან საღამოს 7-მდე\n• **კერხერ-ცენტრი მეტრო სითი** მუშაობს დილის 10-დან საღამოს 10-მდე\n\nზუსტი მოდელისა და ფასის გასაგებად, გთხოვთ, ეწვიოთ ჩვენს მაღაზიას ან ონლაინ კატალოგს.	ai	\N	2026-05-27 05:59:27.285
cmpnnsagb0003mzcc4bmzxaz7	cmpnnsaem0001mzccjn17jnso	user	ჰაი	user	\N	2026-05-27 06:04:01.643
cmpnnsc5y0005mzccskhh64so	cmpnnsaem0001mzccjn17jnso	assistant	გამარჯობა!  \n\nყველა კერხერ-ცენტრი მუშაობს დილის 10:00-დან საღამოს 19:00-მდე, გარდა კერხერ-ცენტრი მეტრო სითისა, რომელიც მუშაობს დილის 10:00-დან საღამოს 22:00-მდე.	ai	\N	2026-05-27 06:04:03.863
cmpnnsiaj0007mzcc8gzwpghh	cmpnnsaem0001mzccjn17jnso	user	არ მაინტერესებს ეგ	user	\N	2026-05-27 06:04:11.804
cmpnnsjor0009mzcckha3udgk	cmpnnsaem0001mzccjn17jnso	assistant	გთხოვთ, დაზუსტოთ, რის შესახებ გსურთ ინფორმაცია?	ai	\N	2026-05-27 06:04:13.611
cmpnntgne000bmzcck5xf0fj1	cmpnnsaem0001mzccjn17jnso	user	ხუმრობები მინდა	user	\N	2026-05-27 06:04:56.33
cmpnntile000dmzccikkw2zts	cmpnnsaem0001mzccjn17jnso	assistant	მე მხოლოდ იმ ინფორმაციის მიწოდება შემიძლია, რაც კერხერის პროდუქტებსა და მომსახურებას უკავშირდება. ხუმრობებს ვერ გაგიზიარებთ.	ai	\N	2026-05-27 06:04:58.85
cmpnntsfz000fmzcc7t4kmvkw	cmpnnsaem0001mzccjn17jnso	user	ხოდა მითხარი რა ღირს k5	user	\N	2026-05-27 06:05:11.615
cmpnnttjx000hmzcc30n3cid6	cmpnnsaem0001mzccjn17jnso	assistant	K5 COMPACT-ის ფასი არის 851.00 ₾ (რეგულარული ფასი 1,150.00 ₾, დანაზოგი 26%).	ai	\N	2026-05-27 06:05:13.053
cmpnntzz6000jmzcce8501l3j	cmpnnsaem0001mzccjn17jnso	user	სად ვიყიდო	user	\N	2026-05-27 06:05:21.378
cmpnnu2bl000lmzcccj8djrpq	cmpnnsaem0001mzccjn17jnso	assistant	კერხერის ოფიციალური ონლაინ მაღაზია არის karcher.ge. ასევე, პროდუქციის შეძენა შეგიძლიათ კერხერ ცენტრებში შემდეგ მისამართებზე:\n\n- თბილისი: ა.ბელიაშვილის ქუჩა 167\n- თბილისი: ვაჟა-ფშაველას გამზ. 4\n- თბილისი: დ. აღმაშენებლის ხეივანი 193\n- ქუთაისი: შ.რუსთაველის გამზ. 96\n- ბათუმი: პ. ბაგრატიონის 129\n- ზუგდიდი: დ.აღმაშენებლის გამზირი 6\n- თელავი: ალაზნის გამზირი 71	ai	\N	2026-05-27 06:05:24.417
cmpnnukp9000nmzccltvpcvh5	cmpnnsaem0001mzccjn17jnso	user	სამუშაო საათები?	user	\N	2026-05-27 06:05:48.237
cmpnnum0c000pmzcctnxpgnpc	cmpnnsaem0001mzccjn17jnso	assistant	ყველა კერხერ-ცენტრი მუშაობს დილის 10:00-დან საღამოს 19:00-მდე, გარდა კერხერ-ცენტრი მეტრო სითისა, რომელიც მუშაობს დილის 10:00-დან საღამოს 22:00-მდე.	ai	\N	2026-05-27 06:05:49.932
cmpnnv87b000tmzcccevimde2	cmpnnv86l000rmzccq9iu360l	user	გამარჯობა	user	\N	2026-05-27 06:06:18.695
cmpnnv9o9000vmzccs0cwx54n	cmpnnv86l000rmzccq9iu360l	assistant	გამარჯობა!\n\nყველა კერხერ-ცენტრი მუშაობს დილის 10:00-დან საღამოს 19:00-მდე.\n\nგამონაკლისია კერხერ-ცენტრი მეტრო სითი, რომელიც მუშაობს დილის 10:00-დან საღამოს 22:00-მდე.	ai	\N	2026-05-27 06:06:20.6
cmpnnzcdh0011mzccsw2hvtu3	cmpnnzcd4000zmzccvggggpfq	user	ჰაი	user	\N	2026-05-27 06:09:30.725
cmpnnzdaz0013mzcc5wqkm8nk	cmpnnzcd4000zmzccvggggpfq	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 06:09:31.931
cmpnnzg4t0015mzccoq2br64h	cmpnnzcd4000zmzccvggggpfq	user	როგორ ხარ	user	\N	2026-05-27 06:09:35.598
cmpnnzh5r0017mzcckvjz5o2l	cmpnnzcd4000zmzccvggggpfq	assistant	გამარჯობა! კარგად ვარ, მადლობა. რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 06:09:36.928
cmpnnzo7l0019mzcc9zce53im	cmpnnzcd4000zmzccvggggpfq	user	რობოტი ხარ?	user	\N	2026-05-27 06:09:46.065
cmpnnzpl5001bmzcczdeufbhx	cmpnnzcd4000zmzccvggggpfq	assistant	გამარჯობა! მე ვარ Demo Company-ის მომხმარებელთა მხარდაჭერის თანაშემწე. რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 06:09:47.85
cmpno1x1e001hmzccx946ssnl	cmpno1x0y001fmzccp61q8aa8	user	გამარჯობა	user	\N	2026-05-27 06:11:30.818
cmpno1y3l001jmzccytol0svo	cmpno1x0y001fmzccp61q8aa8	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 06:11:32.193
cmpno21ek001lmzcc1ptw9f5f	cmpno1x0y001fmzccp61q8aa8	user	როგორ ხარ?	user	\N	2026-05-27 06:11:36.477
cmpno22v4001nmzcc98l59ltg	cmpno1x0y001fmzccp61q8aa8	assistant	კარგად, გმადლობ! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 06:11:38.369
cmpno2dod001pmzcc9d8uinye	cmpno1x0y001fmzccp61q8aa8	user	მტვერსასრუტი ვიყიდე და ყუთი ცარიელია	user	\N	2026-05-27 06:11:52.381
cmpno2f68001rmzcczunm3gww	cmpno1x0y001fmzccp61q8aa8	assistant	დაგიკავშირდით გაყიდვების გუნდთან ან სერვის ცენტრთან შემდეგ მისამართებზე: sales@karcher.ge ან service@karcher.ge. ასევე შეგიძლიათ დარეკოთ ნომერზე 032 238-03-06.	ai	\N	2026-05-27 06:11:54.32
cmpnu3oeu000912bhg99bufk6	cmpnu3hw8000112bh1wzxbicq	assistant	მე ვარ Demo Company-ს მომხმარებელთა მხარდაჭერის ასისტენტი. შემიძლია დაგეხმაროთ Kärcher-ის პროდუქტებთან, ფასებთან, მისამართებთან, სამუშაო საათებთან და სხვა კითხვებში. რა გაინტერესებთ?	ai	\N	2026-05-27 09:00:50.646
cmpnu3xil000b12bh7zanrcom	cmpnu3hw8000112bh1wzxbicq	user	რომლამდე მუშაობთ?	user	\N	2026-05-27 09:01:02.445
cmpnu3z8c000d12bhgzh9tnry	cmpnu3hw8000112bh1wzxbicq	assistant	კერხერ-ცენტრები მუშაობენ დილის 10-დან საღამოს 7-მდე. გამონაკლისია კერხერ-ცენტრი მეტრო სითი, რომელიც მუშაობს დილის 10-დან საღამოს 10-მდე.	ai	\N	2026-05-27 09:01:04.668
cmpnu49xi000f12bhrtr75xq8	cmpnu3hw8000112bh1wzxbicq	user	რა პროდუქცია გაქვთ?	user	\N	2026-05-27 09:01:18.534
cmpnu4cr1000h12bhz6xyfhuc	cmpnu3hw8000112bh1wzxbicq	assistant	ჩვენ გვაქვს პროდუქციის ფართო ასორტიმენტი, მათ შორის: მაღალი წნევის აპარატები, ორთქლის აპარატები, მტვერსასრუტები, სველი წმენდის მტვერსასრუტები, ქიმწმენდის აპარატები, ელექტრო ცოცხები, რობოტი-მტვერსასრუტები, ბაღის ტექნიკა, საწმენდი საშუალებები და აქსესუარები. კონკრეტულად რა გაინტერესებთ?	ai	\N	2026-05-27 09:01:22.19
cmpnu4mjn000j12bh684r6ipc	cmpnu3hw8000112bh1wzxbicq	user	მაღალი წნევა	user	\N	2026-05-27 09:01:34.883
cmpnu4of4000l12bhb9qucc1x	cmpnu3hw8000112bh1wzxbicq	assistant	გთხოვთ, დააზუსტოთ კითხვა. რა გაინტერესებთ მაღალი წნევის აპარატებთან დაკავშირებით?	ai	\N	2026-05-27 09:01:37.312
cmpnu4wfq000n12bhhrzef3jm	cmpnu3hw8000112bh1wzxbicq	user	ყველაზე მძრავრი რომელია?	user	\N	2026-05-27 09:01:47.703
cmpnu4ynu000p12bhin7z7ttd	cmpnu3hw8000112bh1wzxbicq	assistant	Kärcher-ის მაღალი წნევის აპარატებიდან ერთ-ერთი ყველაზე მძლავრი მოდელია K5 COMPACT, რომლის ფასია 851.00 ₾ (რეგულარული ფასი 1,150.00 ₾).	ai	\N	2026-05-27 09:01:50.583
cmpnu59h7000r12bhiy6bylvg	cmpnu3hw8000112bh1wzxbicq	user	პროფესიონალურია?	user	\N	2026-05-27 09:02:04.604
cmpnu5cxs000t12bhtx90gly8	cmpnu3hw8000112bh1wzxbicq	assistant	K5 COMPACT მიეკუთვნება სახლისა და ბაღის კატეგორიას, თუმცა ის საკმაოდ მძლავრია და შესაფერისია როგორც საყოფაცხოვრებო, ასევე მსუბუქი პროფესიონალური გამოყენებისთვის. თუ გაინტერესებთ პროფესიონალური სერიის მოდელები, შემიძლია დაგეხმაროთ მათ შესახებ ინფორმაციის მოძიებაში.	ai	\N	2026-05-27 09:02:09.087
cmpnu5tmm000v12bhbwi9t2q2	cmpnu3hw8000112bh1wzxbicq	user	დიახ, პროფესიონალური ყველაზე ძლიერი მოდელი მინდა	user	\N	2026-05-27 09:02:30.718
cmpnu5w0y000x12bhqyxnva69	cmpnu3hw8000112bh1wzxbicq	assistant	პროფესიონალური კატეგორიის მაღალი წნევის აპარატების შესახებ ზუსტი ინფორმაცია არ მაქვს. გთხოვთ, მიმართოთ ჩვენს კერხერ-ცენტრს ან ეწვიოთ ოფიციალურ ვებგვერდს.	ai	\N	2026-05-27 09:02:33.826
cmpnu64t7000z12bhyb34wskp	cmpnu3hw8000112bh1wzxbicq	user	ნომერი ტელეფონის?	user	\N	2026-05-27 09:02:45.211
cmpnu66jp001112bhr3bf88oi	cmpnu3hw8000112bh1wzxbicq	assistant	ჩვენი საკონტაქტო ნომერია: 032 238-03-06.	ai	\N	2026-05-27 09:02:47.46
cmpnx45ns0003arcf5nh4s2ow	cmpnx45mv0001arcfdjnlbqd4	user	რა ვიყიდო	user	\N	2026-05-27 10:25:11.848
cmpnx47bt0005arcfzh6py2cs	cmpnx45mv0001arcfdjnlbqd4	assistant	მოგესალმებით! გთხოვთ, გამიზიაროთ რა ტიპის პროდუქტი გაინტერესებთ ან რა საჭიროებისთვის გჭირდებათ, რომ დაგეხმაროთ არჩევანში.	ai	\N	2026-05-27 10:25:14.01
cmpnx4mc30007arcf4yjwpm5w	cmpnx45mv0001arcfdjnlbqd4	user	მანანა მინდა გავრეცხო	user	\N	2026-05-27 10:25:33.459
cmpnx4oe40009arcffamtnlm1	cmpnx45mv0001arcfdjnlbqd4	assistant	მოგესალმებით. მანანის დასაბანად შესაფერისია მაღალი წნევით რეცხვის აპარატები. ჩვენს ონლაინ მაღაზიაში შეგიძლიათ იხილოთ სხვადასხვა მოდელი, მაგალითად: K3 Classic (366.30 ₾), K3 Power Control (440.30 ₾), K4 Compact (662.30 ₾) ან K5 Compact (851.00 ₾).	ai	\N	2026-05-27 10:25:36.124
cmpnx6dps000barcfk4ovwi7q	cmpnx45mv0001arcfdjnlbqd4	user	ფილიალები სადაა	user	\N	2026-05-27 10:26:55.6
cmpnx6g12000darcf322f1m8k	cmpnx45mv0001arcfdjnlbqd4	assistant	კერხერ ცენტრები საქართველოში:\n\n- თბილისი: დიღომი, ა.ბელიაშვილის ქუჩა 167\n- თბილისი: საბურთალო, ვაჟა-ფშაველას გამზ. 4\n- თბილისი: ხეივანი, დ. აღმაშენებლის ხეივანი 193\n- ქუთაისი: შ.რუსთაველის გამზ. 96\n- ბათუმი: პ. ბაგრატიონის 129\n- ბათუმი: მეტრო სითი\n- ზუგდიდი: დ.აღმაშენებლის გამზირი 6\n- თელავი: ალაზნის გამზირი 71	ai	\N	2026-05-27 10:26:58.598
cmpnx73x9000farcfzfhb2gr5	cmpnx45mv0001arcfdjnlbqd4	user	გარანტიის პირობები?	user	\N	2026-05-27 10:27:29.565
cmpnywj1b0005wutrkxxdgve6	cmpnywj0t0003wutryxu8ji9v	user	gamarjoba	user	\N	2026-05-27 11:15:15.168
cmpnywjyt0007wutr4ipu3s2b	cmpnywj0t0003wutryxu8ji9v	assistant	გამარჯობა, რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 11:15:16.373
cmpnz0r1y000d93pwnxoyisaw	cmpnz0pzl000593pwgfzj7c94	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:18:32.183
cmpnz0r31000f93pwra1aug3f	cmpnz0pzl000593pwgfzj7c94	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:18:32.221
cmpnz0x5w000j93pw93yteuiv	cmpnz0pzl000593pwgfzj7c94	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:18:40.101
cmpnz0xyp000l93pwvvgy4412	cmpnz0pzl000593pwgfzj7c94	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:18:41.137
cmpnz0y37000n93pwsfg1b82b	cmpnz0pzl000593pwgfzj7c94	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:18:41.299
cmpnz1391000p93pwj343628y	cmpnz0pzl000593pwgfzj7c94	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:18:47.99
cmpnz145g000r93pwdrh7wxzw	cmpnz0pzl000593pwgfzj7c94	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:18:49.156
cmpnzexic000v93pwiabg96lg	cmpnzexhq000t93pwpqay9vv2	user	ჰაი	user	\N	2026-05-27 11:29:33.732
cmpnzeym5000x93pwavlqyej9	cmpnzexhq000t93pwpqay9vv2	assistant	ჰაი, როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 11:29:35.165
cmpnzf85p000z93pw3ipmaxen	cmpnzexhq000t93pwpqay9vv2	user	ნამდვილ ადამიანს მინდა დაველაპარაკო	user	\N	2026-05-27 11:29:47.533
cmpnzf9z2001193pwr29wx0xo	cmpnzexhq000t93pwpqay9vv2	assistant	გეთანხმებით, მე ვარ ხელოვნური ინტელექტის ასისტენტი. თუ გსურთ რეალურ ადამიანთან დაკავშირება, გთხოვთ დაგვიკავშირდეთ ნომერზე 032 238-03-06 ან მოგვწეროთ ელფოსტაზე sales@karcher.ge.	ai	\N	2026-05-27 11:29:49.886
cmpnzjv23000310l1zwpcnxjw	cmpnzjv16000110l1j9cn5eix	user	ნამდვილ ადამიანს მინდა დაველაპარაკო	user	\N	2026-05-27 11:33:23.835
cmpnzjw1f000510l1xp6vob09	cmpnzjv16000110l1j9cn5eix	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:33:25.101
cmpnzjw2m000710l1ahvjw0tp	cmpnzjv16000110l1j9cn5eix	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:33:25.15
cmpnzjw60000b10l1gqjz0bgz	cmpnzjw5o000910l13txvc147	user	ოპერატორთან დამიკავშირდით	user	\N	2026-05-27 11:33:25.273
cmpnzjx7x000d10l1nycgpzk8	cmpnzjw5o000910l13txvc147	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:33:26.637
cmpnzjx8d000f10l1dnsq670i	cmpnzjw5o000910l13txvc147	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:33:26.653
cmpnzjxb1000j10l17oyqm11t	cmpnzjxap000h10l14enqacrw	user	I want to talk to a real person	user	\N	2026-05-27 11:33:26.749
cmpnzjyal000l10l144wua97r	cmpnzjxap000h10l14enqacrw	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:33:28.03
cmpnzjyau000n10l1j2dcdt7n	cmpnzjxap000h10l14enqacrw	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:33:28.038
cmpnzkfz2000r10l1qfolmk0l	cmpnzkfyq000p10l1lkrgtqfa	user	გამარჯობა	user	\N	2026-05-27 11:33:50.942
cmpnzkh0o000t10l1trj1hjl0	cmpnzkfyq000p10l1lkrgtqfa	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 11:33:52.297
cmpnzko7u000v10l1p8g1wcog	cmpnzkfyq000p10l1lkrgtqfa	user	ნამდვილი ადამიანი მინდა	user	\N	2026-05-27 11:34:01.626
cmpnzkpkn000x10l1x4579rax	cmpnzkfyq000p10l1lkrgtqfa	assistant	🔄 მე გადაგიყვანთ რეალურ ადამიანთან...	ai	\N	2026-05-27 11:34:03.383
cmpnzkpoe000z10l1q8hwmypb	cmpnzkfyq000p10l1lkrgtqfa	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:34:03.518
cmpnzl27w001310l100ixnjvg	cmpnzkfyq000p10l1lkrgtqfa	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:34:19.773
cmpnzljil001710l1du8cyty6	cmpnzjv16000110l1j9cn5eix	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:34:42.19
cmpnzljt5001910l1vymivdsb	cmpnzjv16000110l1j9cn5eix	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:34:42.569
cmpnzljy1001b10l17q6hwnpl	cmpnzjv16000110l1j9cn5eix	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:34:42.746
cmpnzlk2w001d10l11l2eyd6p	cmpnzjv16000110l1j9cn5eix	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:34:42.92
cmpnzlkd8001f10l1rhrjdzqi	cmpnzjv16000110l1j9cn5eix	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:34:43.292
cmpnzlkjr001h10l16w3u6ugg	cmpnzjv16000110l1j9cn5eix	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:34:43.528
cmpnzlkoa001j10l1j5epaekt	cmpnzjv16000110l1j9cn5eix	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:34:43.691
cmpnzlp0k001n10l1uwfl23v5	cmpnzjxap000h10l14enqacrw	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:34:49.316
cmpnzlroa001p10l1pliqx47s	cmpnzjxap000h10l14enqacrw	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:34:52.762
cmpnzlrt1001r10l1e6u1m4h6	cmpnzjxap000h10l14enqacrw	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:34:52.933
cmpnzps0e0003x0d2i9zwm852	cmpnzjw5o000910l13txvc147	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:37:59.823
cmpnzq4580007x0d284h6ckd4	cmpnzq44u0005x0d27ptk6pr0	user	გამარჯო	user	\N	2026-05-27 11:38:15.548
cmpnzq5be0009x0d2f4ze2fsz	cmpnzq44u0005x0d27ptk6pr0	assistant	გამარჯობა! \n\nრით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 11:38:17.067
cmpnzqca8000bx0d25cql9c3y	cmpnzq44u0005x0d27ptk6pr0	user	ნამდვილ ადამიანს დამაკავშირე	user	\N	2026-05-27 11:38:26.096
cmpnzqdek000dx0d2vofn2ccn	cmpnzq44u0005x0d27ptk6pr0	assistant	🔄 მე გადაგიყვანთ რეალურ ადამიანთან...	ai	\N	2026-05-27 11:38:27.547
cmpnzqdf8000fx0d27dm7q3cj	cmpnzq44u0005x0d27ptk6pr0	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:38:27.572
cmpnzqj8i000jx0d26sjy6ukh	cmpnzq44u0005x0d27ptk6pr0	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:38:35.107
cmpnzsuso0003nr56cya05chj	cmpnzsuro0001nr56ze1we4qc	user	Hello I need a human agent please	user	\N	2026-05-27 11:40:23.4
cmpnzsvr80005nr56pq2xs0eo	cmpnzsuro0001nr56ze1we4qc	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:40:24.644
cmpnzsvs50007nr56zdlf05ti	cmpnzsuro0001nr56ze1we4qc	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:40:24.677
cmpnzsvub0009nr56fqu4kyl2	cmpnzsuro0001nr56ze1we4qc	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:40:24.755
cmpnzsvwo000dnr56faspxyyi	cmpnzsuro0001nr56ze1we4qc	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-27 11:40:24.84
cmpnzsvxn000fnr56o0cyes6k	cmpnzsuro0001nr56ze1we4qc	agent	Hello from Agent!	human	\N	2026-05-27 11:40:24.875
cmpnztxj6000jnr5650dn0qqw	cmpnztxit000hnr56k36pett9	user	gamarjoba	user	\N	2026-05-27 11:41:13.602
cmpojcg73000jtdruprbo8gnu	cmpoiiuct002nqd4c8fedhf06	agent	Hello from agent! E2E test.	human	\N	2026-05-27 20:47:30.304
cmpnztyiw000lnr561iqljcpe	cmpnztxit000hnr56k36pett9	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 11:41:14.888
cmpnzu2mx000nnr56kicg75a8	cmpnztxit000hnr56k36pett9	user	namdviladamians damakavshire	user	\N	2026-05-27 11:41:20.217
cmpnzu3ve000pnr567rgc5i5j	cmpnztxit000hnr56k36pett9	assistant	გთხოვთ, დამისვით კითხვა და მოგაწვდით ზუსტ ინფორმაციას.	ai	\N	2026-05-27 11:41:21.819
cmpnzuala000rnr563qozwzsz	cmpnztxit000hnr56k36pett9	user	namdvili adamiani minda	user	\N	2026-05-27 11:41:30.526
cmpnzubb2000tnr5601tk8jt9	cmpnztxit000hnr56k36pett9	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:41:31.454
cmpnzura8000vnr5635278z88	cmpnztxit000hnr56k36pett9	user	გადამრთე	user	\N	2026-05-27 11:41:52.161
cmpnzus57000xnr567zybpw1f	cmpnztxit000hnr56k36pett9	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:41:53.276
cmpnzv8qr0011nr56ynw5b4rc	cmpnzv8qa000znr56kihwmfh2	user	ნამდვილ ადამიანთან გადამრთე	user	\N	2026-05-27 11:42:14.787
cmpnzv9fd0013nr566qmdjraj	cmpnzv8qa000znr56kihwmfh2	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:42:15.673
cmpnzv9ft0015nr56x4spbd3l	cmpnzv8qa000znr56kihwmfh2	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:42:15.689
cmpnzvduc0019nr5691xjdfyu	cmpnzv8qa000znr56kihwmfh2	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:42:21.396
cmpnzvfvd001bnr56e2j3c5x4	cmpnzv8qa000znr56kihwmfh2	agent	გამარჯობა	human	\N	2026-05-27 11:42:24.025
cmpnzvpdd001dnr56fmbwx1qm	cmpnzv8qa000znr56kihwmfh2	agent	რით შემიძლია დაგეხმაროთ?	human	\N	2026-05-27 11:42:36.337
cmpnzxefz001hnr569oshnx1z	cmpnzxeej001fnr56xzefo5fj	user	I need human support	user	\N	2026-05-27 11:43:55.487
cmpnzxfbo001jnr56zbp6iunc	cmpnzxeej001fnr56xzefo5fj	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:43:56.628
cmpnzxfd6001lnr56k804h9yc	cmpnzxeej001fnr56xzefo5fj	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:43:56.682
cmpnzxfem001nnr56xz7inq6b	cmpnzxeej001fnr56xzefo5fj	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:43:56.735
cmpnzxfgm001rnr56mhla3ove	cmpnzxeej001fnr56xzefo5fj	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-27 11:43:56.807
cmpnzxfh5001tnr56xvrwyw6y	cmpnzxeej001fnr56xzefo5fj	agent	Hello from Agent! This is a test reply.	human	\N	2026-05-27 11:43:56.826
cmpnzz0wn001xnr56c8bswp0s	cmpnzz0w6001vnr56g42oosqr	user	I want to speak to an agent please	user	\N	2026-05-27 11:45:11.255
cmpnzz1o7001znr56n011ei2j	cmpnzz0w6001vnr56g42oosqr	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:45:12.247
cmpnzz1op0021nr56eqvnpr07	cmpnzz0w6001vnr56g42oosqr	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:45:12.265
cmpnzz1q70023nr56137pwucd	cmpnzz0w6001vnr56g42oosqr	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:45:12.319
cmpnzz1ww0027nr5680lq5w32	cmpnzz0w6001vnr56g42oosqr	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-27 11:45:12.559
cmpnzz1yp0029nr5697bd9x48	cmpnzz0w6001vnr56g42oosqr	agent	Hello! This is Agent support. How can I help you?	human	\N	2026-05-27 11:45:12.625
cmpnzzqfj002dnr56b80gb2ol	cmpnzzqf5002bnr568dr9gj4d	user	I want to speak to a human agent	user	\N	2026-05-27 11:45:44.335
cmpnzzr6u002fnr564oftlf1s	cmpnzzqf5002bnr568dr9gj4d	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:45:45.318
cmpnzzr7d002hnr56g1mgfsrk	cmpnzzqf5002bnr568dr9gj4d	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:45:45.337
cmpnzzucr002lnr56cokkjjuk	cmpnzzuc2002jnr56jy1o8ht8	user	test to create conversation	user	\N	2026-05-27 11:45:49.419
cmpnzzv2g002nnr56vw697rmv	cmpnzzuc2002jnr56jy1o8ht8	assistant	გამარჯობა!	ai	\N	2026-05-27 11:45:50.344
cmpo00kyt002rnr56hhs53rmn	cmpo00kxr002pnr56ruv6t4k8	user	I need to speak with a human agent please	user	\N	2026-05-27 11:46:23.909
cmpo00ltt002tnr567jh0fquk	cmpo00kxr002pnr56ruv6t4k8	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:46:25.025
cmpo00lu9002vnr56q2ltd9nx	cmpo00kxr002pnr56ruv6t4k8	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:46:25.041
cmpo00ouk002znr5669q49mo8	cmpo00oua002xnr5665pie7cd	user	test conversation for agent reply	user	\N	2026-05-27 11:46:28.94
cmpo00pmr0031nr56rbcsoltz	cmpo00oua002xnr5665pie7cd	assistant	test conversation for agent reply	ai	\N	2026-05-27 11:46:29.955
cmpo00pn60033nr560krri9gb	cmpo00oua002xnr5665pie7cd	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:46:29.97
cmpo00poh0035nr5635mnnks3	cmpo00oua002xnr5665pie7cd	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:46:30.017
cmpo01clh0039nr5641bc4vvs	cmpo01cl90037nr56e9qhp204	user	test join repair	user	\N	2026-05-27 11:46:59.717
cmpo01dl6003bnr56xbzrkopo	cmpo01cl90037nr56e9qhp204	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 11:47:01.002
cmpo01dq0003dnr56xkjm73ms	cmpo01cl90037nr56e9qhp204	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:47:01.176
cmpo01dri003hnr56je413wqm	cmpo01cl90037nr56e9qhp204	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-27 11:47:01.231
cmpo025xi003lnr56gmi9phht	cmpo025x2003jnr56f12ldk4y	user	I need to speak to a real person	user	\N	2026-05-27 11:47:37.734
cmpo026p4003nnr56kx2uq8k9	cmpo025x2003jnr56f12ldk4y	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:47:38.728
cmpo026pk003pnr56sggrpscu	cmpo025x2003jnr56f12ldk4y	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:47:38.745
cmpo029ue003tnr56vpyvz6ex	cmpo025x2003jnr56f12ldk4y	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-27 11:47:42.806
cmpo029vc003vnr562oaxf29i	cmpo025x2003jnr56f12ldk4y	agent	Hello! Agent here. How can I assist you today?	human	\N	2026-05-27 11:47:42.84
cmpo02x31003znr56g4xud9y9	cmpnzzqf5002bnr568dr9gj4d	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:48:12.925
cmpo0315z0043nr56cb2ued9i	cmpo00oua002xnr5665pie7cd	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:48:18.216
cmpo035ga0047nr562kpfbfiq	cmpo00kxr002pnr56ruv6t4k8	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:48:23.77
cmpo03dkh004bnr56s7whrhsk	cmpo03dk20049nr56gb5mx307	user	ნამდვილთან გადამრთე	user	\N	2026-05-27 11:48:34.289
cmpo03ebf004dnr56jrhn5296	cmpo03dk20049nr56gb5mx307	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 11:48:35.258
cmpo03ebm004fnr56c45vn30k	cmpo03dk20049nr56gb5mx307	system	🔄 Customer requested a human agent	system	\N	2026-05-27 11:48:35.266
cmpo03jjk004jnr56thacf532	cmpo03dk20049nr56gb5mx307	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 11:48:42.032
cmpo03lu8004lnr56zdg7nfdy	cmpo03dk20049nr56gb5mx307	agent	გამარჯობა	human	\N	2026-05-27 11:48:45.008
cmpo0lsh20003j2fdnfdql76y	cmpo0lsgf0001j2fdg7eaxc4j	user	adamiantan damakavshire	user	\N	2026-05-27 12:02:53.414
cmpo0ltuh0005j2fduq8jyzhx	cmpo0lsgf0001j2fdg7eaxc4j	assistant	გამარჯობა! გთხოვთ, დამისვით თქვენი შეკითხვა.	ai	\N	2026-05-27 12:02:55.193
cmpo0m36y0009j2fd3stvbj1a	cmpo0m36o0007j2fdpumomud3	user	adamiantan damakavshire	user	\N	2026-05-27 12:03:07.307
cmpo0m49y000bj2fdkit0p4il	cmpo0m36o0007j2fdpumomud3	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 12:03:08.703
cmpo0m4gq000fj2fdknql2pev	cmpo0m4gi000dj2fdhz837nf5	user	I need to speak to a human agent	user	\N	2026-05-27 12:03:08.954
cmpo0m52n000hj2fdl7dkwnk2	cmpo0m4gi000dj2fdhz837nf5	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 12:03:09.743
cmpo0m531000jj2fdbzt1sy8z	cmpo0m4gi000dj2fdhz837nf5	system	🔄 Customer requested a human agent	system	\N	2026-05-27 12:03:09.757
cmpo0m56z000nj2fddbja57vk	cmpo0m56q000lj2fdmck8isie	user	ადამიანთან დამაკავშირე	user	\N	2026-05-27 12:03:09.9
cmpo0m5x9000pj2fdof4e4l1i	cmpo0m56q000lj2fdmck8isie	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 12:03:10.845
cmpo0m5xi000rj2fdfh8hn23h	cmpo0m56q000lj2fdmck8isie	system	🔄 Customer requested a human agent	system	\N	2026-05-27 12:03:10.854
cmpo0m62d000vj2fd7rvsj3fa	cmpo0m61y000tj2fd03hs3lyf	user	operatori damakavshire	user	\N	2026-05-27 12:03:11.029
cmpo0m6ui000xj2fdhf7nwuqf	cmpo0m61y000tj2fd03hs3lyf	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 12:03:12.042
cmpo0m6uw000zj2fdjw6dqktw	cmpo0m61y000tj2fd03hs3lyf	system	🔄 Customer requested a human agent	system	\N	2026-05-27 12:03:12.056
cmpo0o49e0003qd4cbgmqh9rj	cmpo0o48v0001qd4csziv48e7	user	adamiantan damakavshire	user	\N	2026-05-27 12:04:42.002
cmpo0o5820005qd4ctjtqkfpp	cmpo0o48v0001qd4csziv48e7	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 12:04:43.251
cmpo0o58f0007qd4caq7zgl0t	cmpo0o48v0001qd4csziv48e7	system	🔄 Customer requested a human agent	system	\N	2026-05-27 12:04:43.264
cmpo0o5gr000bqd4c5pabyh3t	cmpo0o5gj0009qd4ccn15l6zc	user	nadmnili operatori midzghvane	user	\N	2026-05-27 12:04:43.563
cmpo0o6b2000dqd4cuux8fxfl	cmpo0o5gj0009qd4ccn15l6zc	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 12:04:44.654
cmpo0o6bj000fqd4cf9p8od69	cmpo0o5gj0009qd4ccn15l6zc	system	🔄 Customer requested a human agent	system	\N	2026-05-27 12:04:44.672
cmpo0o6f8000jqd4cmap10jwz	cmpo0o6ez000hqd4cnzzb983a	user	damexmare mchirdeba realuri adamiani	user	\N	2026-05-27 12:04:44.804
cmpo0o75a000lqd4c1ptb6qqf	cmpo0o6ez000hqd4cnzzb983a	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 12:04:45.742
cmpo0o75n000nqd4czp3hji3a	cmpo0o6ez000hqd4cnzzb983a	system	🔄 Customer requested a human agent	system	\N	2026-05-27 12:04:45.755
cmpo0odio000rqd4czetmiwbj	cmpo0odij000pqd4cs3pfqmt9	user	adamiantan damakavshire	user	\N	2026-05-27 12:04:54.001
cmpo0oef0000tqd4cyy19qpi9	cmpo0odij000pqd4cs3pfqmt9	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 12:04:55.164
cmpo0oeff000vqd4cakd03u81	cmpo0odij000pqd4cs3pfqmt9	system	🔄 Customer requested a human agent	system	\N	2026-05-27 12:04:55.18
cmpo0pelz000zqd4c8xe2gly6	cmpo0odij000pqd4cs3pfqmt9	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 12:05:42.071
cmpo0phi90013qd4ci1gvsm9m	cmpo0o6ez000hqd4cnzzb983a	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 12:05:45.826
cmpo0pk0c0017qd4cn84cctdj	cmpo0o5gj0009qd4ccn15l6zc	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 12:05:49.069
cmpo0pn6s001bqd4c8gx7rakh	cmpo0o48v0001qd4csziv48e7	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 12:05:53.188
cmpo0pse3001fqd4cfmaj5ob0	cmpo0m61y000tj2fd03hs3lyf	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 12:05:59.932
cmpo0pwv1001jqd4cbasrqp80	cmpo0m56q000lj2fdmck8isie	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 12:06:05.725
cmpo0q3wj001nqd4cwbffpc9e	cmpo0m4gi000dj2fdhz837nf5	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 12:06:14.851
cmpo0qa8x001rqd4c4hvoa9qs	cmpo0qa8l001pqd4cryk8dev0	user	გადამრთე	user	\N	2026-05-27 12:06:23.074
cmpo0qb5o001tqd4clsosaimz	cmpo0qa8l001pqd4cryk8dev0	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 12:06:24.252
cmpo0qnts001vqd4cgall536d	cmpo0qa8l001pqd4cryk8dev0	user	ჰე გადამრთე ნამდვილ ადამიანთან	user	\N	2026-05-27 12:06:40.672
cmpo0qotg001xqd4cnre80h1f	cmpo0qa8l001pqd4cryk8dev0	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 12:06:41.956
cmpo0qou6001zqd4cxhg33g58	cmpo0qa8l001pqd4cryk8dev0	system	🔄 Customer requested a human agent	system	\N	2026-05-27 12:06:41.983
cmpo0qv7f0023qd4c24jp1qye	cmpo0qa8l001pqd4cryk8dev0	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-27 12:06:50.236
cmpo0qx1p0025qd4ccr060d5z	cmpo0qa8l001pqd4cryk8dev0	agent	გამარჯ	human	\N	2026-05-27 12:06:52.622
cmpo0r5wi0027qd4cy5k07353	cmpo0qa8l001pqd4cryk8dev0	system	✅ Conversation resolved	system	\N	2026-05-27 12:07:04.099
cmpo0r6gq0029qd4cpzi91wxd	cmpo0qa8l001pqd4cryk8dev0	system	✅ Conversation resolved	system	\N	2026-05-27 12:07:04.826
cmpo0r6p1002bqd4c8i4jtzfr	cmpo0qa8l001pqd4cryk8dev0	system	✅ Conversation resolved	system	\N	2026-05-27 12:07:05.125
cmpo0r6tj002dqd4cnvoizubx	cmpo0qa8l001pqd4cryk8dev0	system	✅ Conversation resolved	system	\N	2026-05-27 12:07:05.287
cmpoihtmb002hqd4c59z5bori	cmpoihtlw002fqd4ckmayyry6	user	adamiantan damakavshire	user	\N	2026-05-27 20:23:41.363
cmpoihuij002jqd4cy13ozjzh	cmpoihtlw002fqd4ckmayyry6	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 20:23:42.523
cmpoihuiw002lqd4cfhse73qx	cmpoihtlw002fqd4ckmayyry6	system	🔄 Customer requested a human agent	system	\N	2026-05-27 20:23:42.536
cmpoiiuda002pqd4cgx0g3wsq	cmpoiiuct002nqd4c8fedhf06	user	adamiantan damakavshire	user	\N	2026-05-27 20:24:28.99
cmpoiiv49002rqd4c7a1b4xv0	cmpoiiuct002nqd4c8fedhf06	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 20:24:29.961
cmpoiiv4m002tqd4ckx87c1tn	cmpoiiuct002nqd4c8fedhf06	system	🔄 Customer requested a human agent	system	\N	2026-05-27 20:24:29.974
cmpoimq3c0003tdrulwby9v4x	cmpoimq2x0001tdrurr0h5dxa	user	adamiantan damakavshire	user	\N	2026-05-27 20:27:30.073
cmpoimqx70005tdruwaj7od3u	cmpoimq2x0001tdrurr0h5dxa	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 20:27:31.147
cmpoimqxu0007tdrussa7cx44	cmpoimq2x0001tdrurr0h5dxa	system	🔄 Customer requested a human agent	system	\N	2026-05-27 20:27:31.171
cmpojaaw0000btdruathcimqq	cmpoimq2x0001tdrurr0h5dxa	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-27 20:45:50.112
cmpojacq5000dtdru7zm00uyh	cmpoimq2x0001tdrurr0h5dxa	agent	Hello from Benzo! Test E2E.	human	\N	2026-05-27 20:45:52.493
cmpojcehn000htdruwhiihcm7	cmpoiiuct002nqd4c8fedhf06	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-27 20:47:28.091
cmpojd25k000ptdruq3sk4ns2	cmpojd25b000ntdru4n18y0wk	user	hello adamiantan damakavshire	user	\N	2026-05-27 20:47:58.761
cmpojd2y1000rtdruw7o37xyy	cmpojd25b000ntdru4n18y0wk	assistant	გამარჯობა! 👋\n\nროგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 20:47:59.785
cmpojd2ye000ttdruje9d10rq	cmpojd25b000ntdru4n18y0wk	system	🔄 Customer requested a human agent	system	\N	2026-05-27 20:47:59.798
cmpojdoj2000xtdrut0aa3wqx	cmpojdoip000vtdru7ubzv2o0	user	adamiantan damakavshire	user	\N	2026-05-27 20:48:27.758
cmpojdpau000ztdrupygz4fm5	cmpojdoip000vtdru7ubzv2o0	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-27 20:48:28.758
cmpojdpb90011tdrucmd48app	cmpojdoip000vtdru7ubzv2o0	system	🔄 Customer requested a human agent	system	\N	2026-05-27 20:48:28.774
cmpojdyvc0015tdruw57fs84u	cmpojdoip000vtdru7ubzv2o0	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-27 20:48:41.16
cmpoje1dy0017tdruldgywtrj	cmpojdoip000vtdru7ubzv2o0	agent	Hello from agent! Test message.	human	\N	2026-05-27 20:48:44.422
cmpojejlr001btdruqzgeksfh	cmpojejlh0019tdru8mqhwjty	user	nadmnili operatori mchirdeba	user	\N	2026-05-27 20:49:08.031
cmpojek84001dtdruncgcun9k	cmpojejlh0019tdru8mqhwjty	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-27 20:49:08.837
cmpojek8i001ftdru3goxhwsw	cmpojejlh0019tdru8mqhwjty	system	🔄 Customer requested a human agent	system	\N	2026-05-27 20:49:08.85
cmpp1wwqa001jtdrukfw1dnwz	cmpojejlh0019tdru8mqhwjty	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-28 05:27:17.938
cmpp1x17v001ntdruc58eouuu	cmpojd25b000ntdru4n18y0wk	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-28 05:27:23.756
cmpp1x53h001rtdruo6zx5bkk	cmpoihtlw002fqd4ckmayyry6	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-28 05:27:28.782
cmpp1xfvr001vtdruhogt6bqg	cmpp1xfvh001ttdrup96rzsr0	user	ჰაი	user	\N	2026-05-28 05:27:42.76
cmpp1xgox001xtdrue83skuu9	cmpp1xfvh001ttdrup96rzsr0	assistant	ჰაი! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 05:27:43.809
cmpp1xmrx001ztdru2wir2rnt	cmpp1xfvh001ttdrup96rzsr0	user	გადამრთე რეალურ ადამიანთან	user	\N	2026-05-28 05:27:51.693
cmpp1xnss0021tdrud0cgo8d4	cmpp1xfvh001ttdrup96rzsr0	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-28 05:27:53.02
cmpp1xnu00023tdruh5ya8u84	cmpp1xfvh001ttdrup96rzsr0	system	🔄 Customer requested a human agent	system	\N	2026-05-28 05:27:53.064
cmpp1xs6g0027tdruy7x52jte	cmpp1xfvh001ttdrup96rzsr0	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-28 05:27:58.696
cmpp1xuz00029tdrucvlj04f2	cmpp1xfvh001ttdrup96rzsr0	agent	გამარჯობა	human	\N	2026-05-28 05:28:02.317
cmpp21qal002dtdrumiih3npn	cmpp21q9u002btdruz4rzgpp8	user	adamiani damakavshire	user	\N	2026-05-28 05:31:02.877
cmpp21rbl002ftdruhp4i18i8	cmpp21q9u002btdruz4rzgpp8	assistant	გამარჯობა! 👋\n\nმიხარია, რომ გაინტერესებთ BotForge. როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 05:31:04.21
cmpp21rdh002htdru0o12o568	cmpp21q9u002btdruz4rzgpp8	system	🔄 Customer requested a human agent	system	\N	2026-05-28 05:31:04.278
cmpp222wm002ltdru9622rrka	cmpp21q9u002btdruz4rzgpp8	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 05:31:19.223
cmpp224zb002ntdruf4jggdgv	cmpp21q9u002btdruz4rzgpp8	agent	Hello from agent! This is a test message.	human	\N	2026-05-28 05:31:21.911
cmpp248av002rtdruhilw1hpq	cmpp248ae002ptdru37hosng8	user	ra unda gavaketo am shemtxvevashi?? damakavshire adamianstan	user	\N	2026-05-28 05:32:59.528
cmpp249vf002ttdruq2urwie6	cmpp248ae002ptdru37hosng8	assistant	გმადლობთ, რომ დაგვიკავშირდით! 😊\n\nთქვენი მოთხოვნა გავიგე — გსურთ რეალურ ადამიანთან დაკავშირება. \n\n🔄 **გადაგიყვანთ რეალურ ადამიანთან...** გთხოვთ, დარჩით ხაზზე.	ai	\N	2026-05-28 05:33:01.561
cmpp249z7002vtdru94pgclnc	cmpp248ae002ptdru37hosng8	system	🔄 Customer requested a human agent	system	\N	2026-05-28 05:33:01.691
cmpp24ava002ztdruujnld238	cmpp248ae002ptdru37hosng8	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 05:33:02.854
cmpp24dur0031tdrur47vodj5	cmpp248ae002ptdru37hosng8	agent	Gamarjoba! Me var agenti, rogor dagexmarot?	human	\N	2026-05-28 05:33:06.723
cmpp266fq0003yzqxovotbksc	cmpp266fa0001yzqx5jr6r0dh	user	test	user	\N	2026-05-28 05:34:30.422
cmpp2675c0005yzqx7esn28n3	cmpp266fa0001yzqx5jr6r0dh	assistant	Hi there! 👋 Welcome to BotForge Support. How can I help you today?	ai	\N	2026-05-28 05:34:31.344
cmpp26bxu0009yzqx72obn4w7	cmpp26bxl0007yzqx1ojap9ke	user	damakavshire adamianstan	user	\N	2026-05-28 05:34:37.554
cmpp26dsl000byzqx4tshwj01	cmpp26bxl0007yzqx1ojap9ke	assistant	It sounds like you're asking about **Damakavshire** and **Adamianstan**, but these terms don't appear to be related to **BotForge** or its features.\n\nCould you clarify your question? I'm here to help with:\n- BotForge AI chatbot setup and features\n- Pricing (Free / €49 Pro / €149 Enterprise)\n- Integrations (website, Shopify, Messenger, Instagram)\n- AI capabilities (DeepSeek, RAG, custom knowledge base)\n- Agent Panel for human handoff\n- Token-based billing\n\nIf you're referring to something else entirely, feel free to provide more context — or if you need to speak to a real person, just let me know and I'll transfer you.	ai	\N	2026-05-28 05:34:39.957
cmpp26dsz000dyzqxo9mu4erl	cmpp26bxl0007yzqx1ojap9ke	system	🔄 Customer requested a human agent	system	\N	2026-05-28 05:34:39.971
cmpp26e00000hyzqxx17ppbxl	cmpp26bxl0007yzqx1ojap9ke	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 05:34:40.225
cmpp26h9n000jyzqx09ifle6z	cmpp26bxl0007yzqx1ojap9ke	agent	Hello	human	\N	2026-05-28 05:34:44.459
cmpp26o7j000lyzqxxcb3jfrr	cmpp26bxl0007yzqx1ojap9ke	system	✅ Conversation resolved	system	\N	2026-05-28 05:34:53.455
cmpp2cvae000pyzqxqau64hcq	cmpp2cv9z000nyzqxj8hppavh	user	გადამრთე რეალურ ადამიანთან	user	\N	2026-05-28 05:39:42.566
cmpp2cw7a000ryzqxuzwnurhx	cmpp2cv9z000nyzqxj8hppavh	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-28 05:39:43.75
cmpp2cw7s000tyzqx39yomimb	cmpp2cv9z000nyzqxj8hppavh	system	🔄 Customer requested a human agent	system	\N	2026-05-28 05:39:43.768
cmpp2d5o6000xyzqx0lbfdpzr	cmpp2cv9z000nyzqxj8hppavh	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-28 05:39:56.023
cmpp2d6ms000zyzqxgfil0kqi	cmpp2cv9z000nyzqxj8hppavh	agent	ასდ	human	\N	2026-05-28 05:39:57.268
cmpp2ifug0003t1pq19b8zpb7	cmpp2ifsr0001t1pq2e2ih66z	user	გადამრთე ადამიანთან	user	\N	2026-05-28 05:44:02.488
cmpp2igx40005t1pqc9dyq5yi	cmpp2ifsr0001t1pq2e2ih66z	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-28 05:44:03.88
cmpp2igxh0007t1pqplj4s8mc	cmpp2ifsr0001t1pq2e2ih66z	system	🔄 Customer requested a human agent	system	\N	2026-05-28 05:44:03.893
cmpp2im5m000bt1pq10vb0pke	cmpp2ifsr0001t1pq2e2ih66z	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-28 05:44:10.666
cmpp2iqwo000dt1pqozgodrd4	cmpp2ifsr0001t1pq2e2ih66z	agent	ასდასდ	human	\N	2026-05-28 05:44:16.825
cmpp2j2ov000ft1pq1excijz8	cmpp2ifsr0001t1pq2e2ih66z	system	✅ Conversation resolved	system	\N	2026-05-28 05:44:32.093
cmpp2j3bj000ht1pqav3rh4no	cmpp2ifsr0001t1pq2e2ih66z	system	✅ Conversation resolved	system	\N	2026-05-28 05:44:32.911
cmpp2j3g0000jt1pqcngzffbu	cmpp2ifsr0001t1pq2e2ih66z	system	✅ Conversation resolved	system	\N	2026-05-28 05:44:33.072
cmpp2j447000lt1pqhjd8evnt	cmpp2ifsr0001t1pq2e2ih66z	system	✅ Conversation resolved	system	\N	2026-05-28 05:44:33.943
cmpp2j49z000nt1pqrgz5rnp6	cmpp2ifsr0001t1pq2e2ih66z	system	✅ Conversation resolved	system	\N	2026-05-28 05:44:34.152
cmpp2j8d9000pt1pq2x426bha	cmpp2cv9z000nyzqxj8hppavh	system	✅ Conversation resolved	system	\N	2026-05-28 05:44:39.453
cmpp2jewh000rt1pqqt7yu4ae	cmpn5aixt0011tex1kcpzkra8	system	✅ Conversation resolved	system	\N	2026-05-28 05:44:47.922
cmpp2jj48000tt1pqycp4rorm	cmpnz0pzl000593pwgfzj7c94	system	✅ Conversation resolved	system	\N	2026-05-28 05:44:53.384
cmpp2jp7k000vt1pqabqo75d6	cmpnzkfyq000p10l1lkrgtqfa	system	✅ Conversation resolved	system	\N	2026-05-28 05:45:01.28
cmpp2jrw2000xt1pq5fqal2ej	cmpnzjv16000110l1j9cn5eix	system	✅ Conversation resolved	system	\N	2026-05-28 05:45:04.754
cmpp2jtwp000zt1pqoxf9bjbq	cmpnzjw5o000910l13txvc147	system	✅ Conversation resolved	system	\N	2026-05-28 05:45:07.369
cmpp2jvjm0011t1pqxchmxh6d	cmpnzv8qa000znr56kihwmfh2	system	✅ Conversation resolved	system	\N	2026-05-28 05:45:09.49
cmpp2k4mr0013t1pqq4vcd2dt	cmpp1xfvh001ttdrup96rzsr0	system	✅ Conversation resolved	system	\N	2026-05-28 05:45:21.267
cmpp2kbny0015t1pqiq2hwn7w	cmpoihtlw002fqd4ckmayyry6	system	✅ Conversation resolved	system	\N	2026-05-28 05:45:30.382
cmpp2kfnm0017t1pqa8fqxvnm	cmpojd25b000ntdru4n18y0wk	system	✅ Conversation resolved	system	\N	2026-05-28 05:45:35.554
cmpp2kjm30019t1pqomkebyt5	cmpojejlh0019tdru8mqhwjty	system	✅ Conversation resolved	system	\N	2026-05-28 05:45:40.683
cmpp2kn0w001bt1pq976asze9	cmpojdoip000vtdru7ubzv2o0	system	✅ Conversation resolved	system	\N	2026-05-28 05:45:45.102
cmpp2kqym001dt1pqhnfqhqkg	cmpoiiuct002nqd4c8fedhf06	system	✅ Conversation resolved	system	\N	2026-05-28 05:45:50.206
cmpp2kv0q001ft1pqilanxqua	cmpoimq2x0001tdrurr0h5dxa	system	✅ Conversation resolved	system	\N	2026-05-28 05:45:55.466
cmpp2kymj001ht1pqqszkfw4q	cmpo0m4gi000dj2fdhz837nf5	system	✅ Conversation resolved	system	\N	2026-05-28 05:46:00.139
cmpp2l5td001jt1pqwwst8mqy	cmpo0m56q000lj2fdmck8isie	system	✅ Conversation resolved	system	\N	2026-05-28 05:46:09.457
cmpp2ld35001lt1pqu4az17in	cmpo0m61y000tj2fd03hs3lyf	system	✅ Conversation resolved	system	\N	2026-05-28 05:46:18.882
cmpp2lhvr001nt1pq7r2pcwka	cmpo0o48v0001qd4csziv48e7	system	✅ Conversation resolved	system	\N	2026-05-28 05:46:25.095
cmpp2lno4001pt1pq7n5z8y6o	cmpo0o5gj0009qd4ccn15l6zc	system	✅ Conversation resolved	system	\N	2026-05-28 05:46:32.596
cmpp2lq3x001rt1pqm3miel2m	cmpo0o6ez000hqd4cnzzb983a	system	✅ Conversation resolved	system	\N	2026-05-28 05:46:35.758
cmpp2lvgv001tt1pqz0xu216m	cmpo0odij000pqd4cs3pfqmt9	system	✅ Conversation resolved	system	\N	2026-05-28 05:46:42.703
cmpp2lzd4001vt1pqhf6ktwe6	cmpo03dk20049nr56gb5mx307	system	✅ Conversation resolved	system	\N	2026-05-28 05:46:47.752
cmpp2m6bz001xt1pqgxfi30ap	cmpo00kxr002pnr56ruv6t4k8	system	✅ Conversation resolved	system	\N	2026-05-28 05:46:56.783
cmpp2mcos001zt1pqoc11ta4k	cmpo00oua002xnr5665pie7cd	system	✅ Conversation resolved	system	\N	2026-05-28 05:47:05.02
cmpp2mh2a0021t1pqtdod0jgk	cmpnzzqf5002bnr568dr9gj4d	system	✅ Conversation resolved	system	\N	2026-05-28 05:47:10.69
cmpp2mlox0023t1pqacn9uhcz	cmpo025x2003jnr56f12ldk4y	system	✅ Conversation resolved	system	\N	2026-05-28 05:47:16.689
cmpp2mpfi0025t1pqcwi153i5	cmpo01cl90037nr56e9qhp204	system	✅ Conversation resolved	system	\N	2026-05-28 05:47:21.534
cmpp2mw510027t1pq6rp1z70h	cmpnzz0w6001vnr56g42oosqr	system	✅ Conversation resolved	system	\N	2026-05-28 05:47:30.229
cmpp2mzms0029t1pqzv1r620w	cmpnzxeej001fnr56xzefo5fj	system	✅ Conversation resolved	system	\N	2026-05-28 05:47:34.756
cmpp2n4p0002bt1pqbc592xen	cmpnzsuro0001nr56ze1we4qc	system	✅ Conversation resolved	system	\N	2026-05-28 05:47:41.316
cmpp2n7mc002dt1pq5jbnuf8y	cmpnzq44u0005x0d27ptk6pr0	system	✅ Conversation resolved	system	\N	2026-05-28 05:47:45.108
cmpp2nbis002ft1pqtqwlxui0	cmpnzjxap000h10l14enqacrw	system	✅ Conversation resolved	system	\N	2026-05-28 05:47:50.164
cmpp2u8s7002jt1pqhzrb3m0k	cmpp2u8rn002ht1pqb6xubaag	user	damakavshire adamianstan	user	\N	2026-05-28 05:53:13.207
cmpp2uafo002lt1pq5plaiosq	cmpp2u8rn002ht1pqb6xubaag	assistant	It sounds like you may be referencing a name or place — but that doesn't quite match anything in the BotForge system or common queries. \n\nCould you clarify what you'd like to know? I'm here to help with:\n- BotForge features and setup\n- Pricing and plans\n- Integrations (website, Shopify, Messenger, Instagram)\n- AI capabilities (DeepSeek, RAG, custom knowledge base)\n- Agent Panel for human handoff\n- Token-based billing\n\nLet me know how I can assist!	ai	\N	2026-05-28 05:53:15.348
cmpp2uag3002nt1pqhu5fj6ku	cmpp2u8rn002ht1pqb6xubaag	system	🔄 Customer requested a human agent	system	\N	2026-05-28 05:53:15.363
cmpp2ualq002rt1pqa4g2g3tb	cmpp2u8rn002ht1pqb6xubaag	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 05:53:15.567
cmpp2uaop002tt1pqkktl0yp7	cmpp2u8rn002ht1pqb6xubaag	agent	Hello from agent	human	\N	2026-05-28 05:53:15.673
cmpp2uxm6002xt1pq6o7t1sax	cmpp2uxlw002vt1pq3v3ml565	user	gamarjoba ra gixdi	user	\N	2026-05-28 05:53:45.39
cmpp2uyhh002zt1pqxzjxz3ca	cmpp2uxlw002vt1pq3v3ml565	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 05:53:46.517
cmpp2vflv0033t1pq1kpa2ezb	cmpp2vfll0031t1pq9rg3hba7	user	adamiani damakavshire	user	\N	2026-05-28 05:54:08.707
cmpp2vgiq0035t1pq1dpa3bhu	cmpp2vfll0031t1pq9rg3hba7	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 05:54:09.891
cmpp2vgj00037t1pqn89t2l9x	cmpp2vfll0031t1pq9rg3hba7	system	🔄 Customer requested a human agent	system	\N	2026-05-28 05:54:09.9
cmpp2vxaf003bt1pq7bkqhb09	cmpp2vxa40039t1pqyli5adk4	user	adamiani damakavshire	user	\N	2026-05-28 05:54:31.623
cmpp2vy9u003dt1pq3fstx70s	cmpp2vxa40039t1pqyli5adk4	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 05:54:32.899
cmpp2vya3003ft1pqoncl6aht	cmpp2vxa40039t1pqyli5adk4	system	🔄 Customer requested a human agent	system	\N	2026-05-28 05:54:32.907
cmpp2w1ad003jt1pq0yv1dvgj	cmpp2vxa40039t1pqyli5adk4	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 05:54:36.804
cmpp2w1dq003lt1pq05n0tbmn	cmpp2vxa40039t1pqyli5adk4	agent	Gamarjoba! Agent here!	human	\N	2026-05-28 05:54:36.926
cmpp33m3v003pt1pqchp4fml3	cmpp2vfll0031t1pq9rg3hba7	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-28 06:00:30.38
cmpp33qd5003rt1pqt4buuitn	cmpp2vxa40039t1pqyli5adk4	system	✅ Conversation resolved	system	\N	2026-05-28 06:00:35.897
cmpp33shj003tt1pqt96f9bmy	cmpp2vfll0031t1pq9rg3hba7	system	✅ Conversation resolved	system	\N	2026-05-28 06:00:38.647
cmpp33wrj003vt1pqwrz7mimg	cmpp2vfll0031t1pq9rg3hba7	system	✅ Conversation resolved	system	\N	2026-05-28 06:00:44.192
cmpp341oh003zt1pqunnwawyj	cmpp341o4003xt1pq30jb8w0k	user	ასდ	user	\N	2026-05-28 06:00:50.561
cmpp342li0041t1pq6nc7lcyu	cmpp341o4003xt1pq30jb8w0k	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 06:00:51.75
cmpp344560043t1pqq0bu3zfo	cmpp341o4003xt1pq30jb8w0k	user	რეფერფ	user	\N	2026-05-28 06:00:53.754
cmpp3454w0045t1pq9ecutcbn	cmpp341o4003xt1pq30jb8w0k	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 06:00:55.039
cmpp346o30047t1pqjgfhqqxc	cmpp341o4003xt1pq30jb8w0k	user	ქწექწე	user	\N	2026-05-28 06:00:57.027
cmpp347hp0049t1pqqdz32b5g	cmpp341o4003xt1pq30jb8w0k	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 06:00:58.094
cmpp34bb0004bt1pqallhqoct	cmpp341o4003xt1pq30jb8w0k	user	გადამრთე	user	\N	2026-05-28 06:01:03.037
cmpp34c9r004dt1pq1kky9dek	cmpp341o4003xt1pq30jb8w0k	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-28 06:01:04.287
cmpp34kgd004ft1pqnhkri0a6	cmpp341o4003xt1pq30jb8w0k	user	აგენტთან გადამრთე	user	\N	2026-05-28 06:01:14.894
cmpp34lnu004ht1pqba8k50h4	cmpp341o4003xt1pq30jb8w0k	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-28 06:01:16.458
cmpp34unx004jt1pq9n22fb44	cmpp341o4003xt1pq30jb8w0k	user	ნამდვილ ადამიანთან დამაკავშირე	user	\N	2026-05-28 06:01:28.126
cmpp34vee004lt1pqndxe2a6o	cmpp341o4003xt1pq30jb8w0k	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-28 06:01:29.078
cmpp34ver004nt1pqmo3viay4	cmpp341o4003xt1pq30jb8w0k	system	🔄 Customer requested a human agent	system	\N	2026-05-28 06:01:29.091
cmpp35181004rt1pqvv7bw75d	cmpp341o4003xt1pq30jb8w0k	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-28 06:01:36.625
cmpp352ux004tt1pq7lk1dasn	cmpp341o4003xt1pq30jb8w0k	agent	ასდ	human	\N	2026-05-28 06:01:38.745
cmpp3jz2o004xt1pqslelyk9f	cmpp3jz1p004vt1pqvxfi2zcr	user	damakavshire adamianstan	user	\N	2026-05-28 06:13:13.68
cmpp3k10e004zt1pqkz7l5f8n	cmpp3jz1p004vt1pqvxfi2zcr	assistant	Hello! 👋 It sounds like you might be asking about something specific, but I'm not quite sure what "damakavshire adamianstan" refers to. Could you please clarify or rephrase your question?\n\nIf you're interested in learning about **BotForge** — our AI chatbot platform — I'd be happy to help! Here are some things I can assist with:\n\n- **Features**: DeepSeek-powered AI, custom knowledge base, RAG, Agent Panel for human handoff\n- **Pricing**: Free plan, €49 Pro, €149 Enterprise, Custom options\n- **Integrations**: Website widget, Shopify, Facebook Messenger, Instagram\n- **Billing**: Token-based system\n\nLet me know how I can help! 😊	ai	\N	2026-05-28 06:13:16.19
cmpp3k11q0051t1pqi182w175	cmpp3jz1p004vt1pqvxfi2zcr	system	🔄 Customer requested a human agent	system	\N	2026-05-28 06:13:16.239
cmpp3k17e0055t1pqe17z8pmg	cmpp3jz1p004vt1pqvxfi2zcr	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 06:13:16.443
cmpp3k1a20057t1pq6qelvhr0	cmpp3jz1p004vt1pqvxfi2zcr	agent	Gamarjoba! Me var agenti!	human	\N	2026-05-28 06:13:16.538
cmpp3kd6u005bt1pqokzzqxln	cmpp3kd6i0059t1pqssibnnxd	user	adamiani damakavshire	user	\N	2026-05-28 06:13:31.974
cmpp3kea0005dt1pqdsqou6zt	cmpp3kd6i0059t1pqssibnnxd	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 06:13:33.384
cmpp3keaf005ft1pqxm1j0c0x	cmpp3kd6i0059t1pqssibnnxd	system	🔄 Customer requested a human agent	system	\N	2026-05-28 06:13:33.399
cmpp3kfl8005jt1pqscbcgyzv	cmpp3kd6i0059t1pqssibnnxd	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 06:13:35.084
cmpp3kfo5005lt1pqeaymftwk	cmpp3kd6i0059t1pqssibnnxd	agent	Gamarjoba! Me var agenti!	human	\N	2026-05-28 06:13:35.189
cmpp3rkhy005pt1pqmn1ump9p	cmpp3rkh5005nt1pqgjuvl7qb	user	ასდ	user	\N	2026-05-28 06:19:08.038
cmpp3rlmr005rt1pqr564jq7t	cmpp3rkh5005nt1pqgjuvl7qb	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 06:19:09.508
cmpp3rrb5005tt1pqg7zeqx41	cmpp3rkh5005nt1pqgjuvl7qb	user	გადამრთე ადამიანთან	user	\N	2026-05-28 06:19:16.865
cmpp3rs8u005vt1pqlr9wzppz	cmpp3rkh5005nt1pqgjuvl7qb	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-28 06:19:18.078
cmpp3rs9y005xt1pqn0qao044	cmpp3rkh5005nt1pqgjuvl7qb	system	🔄 Customer requested a human agent	system	\N	2026-05-28 06:19:18.118
cmpp3s4v80061t1pqcpt55vqp	cmpp3rkh5005nt1pqgjuvl7qb	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-28 06:19:34.436
cmpp3s77v0063t1pqitweabd2	cmpp3rkh5005nt1pqgjuvl7qb	agent	ეწრწერ	human	\N	2026-05-28 06:19:37.483
cmpp3sk0o0065t1pqw3jqtg54	cmpp3rkh5005nt1pqgjuvl7qb	agent	ეფგდგ	human	\N	2026-05-28 06:19:54.072
cmpp3somk0067t1pq630nm7q7	cmpp3rkh5005nt1pqgjuvl7qb	agent	დფგდფგდფგ	human	\N	2026-05-28 06:20:00.044
cmpp3wm9e006bt1pqrgsgl57j	cmpp3wm900069t1pql2u9fr1o	user	adamiani damakavshire	user	\N	2026-05-28 06:23:03.603
cmpp3wn6h006dt1pqlg2n4rpm	cmpp3wm900069t1pql2u9fr1o	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 06:23:04.793
cmpp3wn6v006ft1pqfya3ike3	cmpp3wm900069t1pql2u9fr1o	system	🔄 Customer requested a human agent	system	\N	2026-05-28 06:23:04.807
cmpp3xcwy006jt1pq3fgy9hps	cmpp3xcwe006ht1pqurdr7oqd	user	adamiani damakavshire	user	\N	2026-05-28 06:23:38.146
cmpp3xe1x006lt1pqo7rstakp	cmpp3xcwe006ht1pqurdr7oqd	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 06:23:39.621
cmpp3xe2d006nt1pqyckjbome	cmpp3xcwe006ht1pqurdr7oqd	system	🔄 Customer requested a human agent	system	\N	2026-05-28 06:23:39.637
cmpp3xgv1006rt1pq83bisuvq	cmpp3xcwe006ht1pqurdr7oqd	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 06:23:43.262
cmpp3xgvz006tt1pq1h8nmu59	cmpp3xcwe006ht1pqurdr7oqd	agent	Gamarjoba! Agent here, how can I help?	human	\N	2026-05-28 06:23:43.296
cmpp3zj4o006xt1pqo601rt6s	cmpp3zj41006vt1pqtigruxju	user	adamiani damakavshire	user	\N	2026-05-28 06:25:19.512
cmpp3zk7j006zt1pqpk7kusfe	cmpp3zj41006vt1pqtigruxju	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 06:25:20.911
cmpp3zkcc0071t1pqyw3h8iiq	cmpp3zj41006vt1pqtigruxju	system	🔄 Customer requested a human agent	system	\N	2026-05-28 06:25:21.084
cmpp3zn150075t1pq5x5zyh9e	cmpp3zj41006vt1pqtigruxju	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 06:25:24.569
cmpp3zn1s0077t1pq0p1uenyb	cmpp3zj41006vt1pqtigruxju	agent	Gamarjoba! Agent here!	human	\N	2026-05-28 06:25:24.592
cmpp41hhm0079t1pqd2tu6wqg	cmpp3zj41006vt1pqtigruxju	system	✅ Conversation resolved	system	\N	2026-05-28 06:26:50.698
cmpp41jjb007bt1pq6uvqbm4g	cmpp3xcwe006ht1pqurdr7oqd	system	✅ Conversation resolved	system	\N	2026-05-28 06:26:53.351
cmpp41l26007dt1pqtkep1k4h	cmpp3kd6i0059t1pqssibnnxd	system	✅ Conversation resolved	system	\N	2026-05-28 06:26:55.326
cmpp41mlb007ft1pqnad519r3	cmpp341o4003xt1pq30jb8w0k	system	✅ Conversation resolved	system	\N	2026-05-28 06:26:57.312
cmpp41pce007ht1pqx5s80rvy	cmpp3rkh5005nt1pqgjuvl7qb	system	✅ Conversation resolved	system	\N	2026-05-28 06:27:00.878
cmpp42i0y007lt1pqqfufkb1x	cmpp3wm900069t1pql2u9fr1o	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 06:27:38.051
cmpp42irn007nt1pqcs5cx0ys	cmpp3wm900069t1pql2u9fr1o	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 06:27:39.011
cmpp42q08007pt1pq28qwfl43	cmpp3wm900069t1pql2u9fr1o	system	✅ Conversation resolved	system	\N	2026-05-28 06:27:48.392
cmpp42w4i007rt1pqly6hyjwu	cmpp3wm900069t1pql2u9fr1o	system	✅ Conversation resolved	system	\N	2026-05-28 06:27:56.323
cmpp42zlo007tt1pqdwzeyutv	cmpp3wm900069t1pql2u9fr1o	system	✅ Conversation resolved	system	\N	2026-05-28 06:28:00.829
cmpp438rd007xt1pqb3rxmk9q	cmpp438qe007vt1pqrs77fhxb	user	გადამრთე რეალურ ადამიანთან	user	\N	2026-05-28 06:28:12.698
cmpp439qt007zt1pq5a35mwpi	cmpp438qe007vt1pqrs77fhxb	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-28 06:28:13.973
cmpp439r60081t1pq9bkdxnl0	cmpp438qe007vt1pqrs77fhxb	system	🔄 Customer requested a human agent	system	\N	2026-05-28 06:28:13.986
cmpp43f8d0085t1pqx17p3ck3	cmpp438qe007vt1pqrs77fhxb	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-28 06:28:21.085
cmpp43i4g0087t1pqf3mj6aow	cmpp438qe007vt1pqrs77fhxb	agent	ასდ	human	\N	2026-05-28 06:28:24.832
cmpp4and60089t1pqo67lwiw5	cmpp438qe007vt1pqrs77fhxb	system	✅ Conversation resolved	system	\N	2026-05-28 06:33:58.218
cmpp4awt9008dt1pqpsnln9cl	cmpp4awsv008bt1pqdpb1jphz	user	გადამრთე რეალურ აგენტთან	user	\N	2026-05-28 06:34:10.461
cmpp4axk8008ft1pqkn78wu4g	cmpp4awsv008bt1pqdpb1jphz	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-28 06:34:11.432
cmpp4axko008ht1pqs93dkkf3	cmpp4awsv008bt1pqdpb1jphz	system	🔄 Customer requested a human agent	system	\N	2026-05-28 06:34:11.448
cmpp4b34y008jt1pq0x3le3a3	cmpp4awsv008bt1pqdpb1jphz	agent	ასდ	human	\N	2026-05-28 06:34:18.659
cmpp4b9ki008lt1pqoggppe1s	cmpp4awsv008bt1pqdpb1jphz	agent	დსფდსფ	human	\N	2026-05-28 06:34:26.993
cmpp4omco008nt1pqlfy4jv13	cmpp4awsv008bt1pqdpb1jphz	system	✅ Conversation resolved	system	\N	2026-05-28 06:44:50.088
cmpp4onng008pt1pq77aq1ojw	cmpp4awsv008bt1pqdpb1jphz	system	✅ Conversation resolved	system	\N	2026-05-28 06:44:51.773
cmpp4onwd008rt1pq8j0l3zmi	cmpp4awsv008bt1pqdpb1jphz	system	✅ Conversation resolved	system	\N	2026-05-28 06:44:52.094
cmpp4oozv008tt1pqi27w1xwp	cmpp4awsv008bt1pqdpb1jphz	system	✅ Conversation resolved	system	\N	2026-05-28 06:44:53.515
cmpp4opb5008vt1pqn50nppxo	cmpp4awsv008bt1pqdpb1jphz	system	✅ Conversation resolved	system	\N	2026-05-28 06:44:53.922
cmpp4t0k300036q21nul8mvfi	cmpp4t0jl00016q2124xzauzi	user	adamiani damakavshire	user	\N	2026-05-28 06:48:15.123
cmpp4t1i900056q21s70qeoeg	cmpp4t0jl00016q2124xzauzi	assistant	გამარჯობა! როგორ შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 06:48:16.353
cmpp4t1ir00076q21rgt6ytoa	cmpp4t0jl00016q2124xzauzi	system	🔄 Customer requested a human agent	system	\N	2026-05-28 06:48:16.371
cmpp4t4fk000b6q21ruzh7ybf	cmpp4t0jl00016q2124xzauzi	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 06:48:20.145
cmpp4t4gi000d6q21sd3tjh6r	cmpp4t0jl00016q2124xzauzi	agent	SSE real-time test!	human	\N	2026-05-28 06:48:20.179
cmpp4w07d000h6q2124cu88xt	cmpp4w06y000f6q21sryahue7	user	გადამრთე რეალურ აგენტთნ	user	\N	2026-05-28 06:50:34.634
cmpp4w127000j6q21oo2dm9pa	cmpp4w06y000f6q21sryahue7	assistant	🔄 I'm transferring you to a real person...	ai	\N	2026-05-28 06:50:35.743
cmpp4w12j000l6q211fn8h11i	cmpp4w06y000f6q21sryahue7	system	🔄 Customer requested a human agent	system	\N	2026-05-28 06:50:35.755
cmpp4w6nc000p6q210y4avdqg	cmpp4w06y000f6q21sryahue7	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 06:50:42.985
cmpp4w8hh000r6q21bk5ml2cv	cmpp4w06y000f6q21sryahue7	agent	ასდ	human	\N	2026-05-28 06:50:45.365
cmpp4weaq000t6q21smrho7qw	cmpp4w06y000f6q21sryahue7	agent	სდფდს	human	\N	2026-05-28 06:50:52.899
cmpp6svn50003f4c5twewiwgv	cmpp6svmb0001f4c5xhd7bhjk	user	გამარჯობა	user	\N	2026-05-28 07:44:07.985
cmpp6swxn0005f4c5x7o83qtc	cmpp6svmb0001f4c5xhd7bhjk	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 07:44:09.659
cmpp6t1ie0007f4c57gehqtgq	cmpp6svmb0001f4c5xhd7bhjk	user	ვინ ხარ შენ?	user	\N	2026-05-28 07:44:15.59
cmpp6t3n30009f4c5tfbr4esn	cmpp6svmb0001f4c5xhd7bhjk	assistant	მე ვარ კერხერის მეგობრული ასისტენტი. ვეხმარები პროდუქტების, მაღაზიების, ფასების და სხვა ინფორმაციის მოძიებაში.	ai	\N	2026-05-28 07:44:18.351
cmpp6ttme000bf4c58imv1cg8	cmpp6svmb0001f4c5xhd7bhjk	system	🔄 Customer requested a human agent	system	\N	2026-05-28 07:44:52.022
cmpp6typ7000ff4c5hbyyf90z	cmpp6svmb0001f4c5xhd7bhjk	system	👤 Agent Dachi has joined the conversation	system	\N	2026-05-28 07:44:58.603
cmpp6u01b000hf4c50nwdgq14	cmpp6svmb0001f4c5xhd7bhjk	agent	hai	human	\N	2026-05-28 07:45:00.331
cmpp6u1nr000jf4c5tmcq0wag	cmpp6svmb0001f4c5xhd7bhjk	agent	სადასდ	human	\N	2026-05-28 07:45:02.44
cmpp6xr3p000lf4c5ysmeqk0o	cmpp6svmb0001f4c5xhd7bhjk	system	✅ Conversation resolved	system	\N	2026-05-28 07:47:55.382
cmpp6xy91000nf4c5z5unajji	cmpp4w06y000f6q21sryahue7	system	✅ Conversation resolved	system	\N	2026-05-28 07:48:04.645
cmpp6y01c000pf4c5eeir66pa	cmpp4t0jl00016q2124xzauzi	system	✅ Conversation resolved	system	\N	2026-05-28 07:48:06.96
cmpp7301p00014wym9j5vl036	cmpp6svmb0001f4c5xhd7bhjk	user	ასდ	user	\N	2026-05-28 07:52:00.253
cmpp731ha00034wym3rn80t5m	cmpp6svmb0001f4c5xhd7bhjk	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 07:52:02.108
cmpp73gvq00054wympiyg0nfm	cmpp6svmb0001f4c5xhd7bhjk	system	🔄 Customer requested a human agent	system	\N	2026-05-28 07:52:22.07
cmpp73su000074wymtz2jnwpv	cmpp6svmb0001f4c5xhd7bhjk	agent	გამარჯობა	human	\N	2026-05-28 07:52:37.56
cmpp74xq300094wymbvnbnzj9	cmpp6svmb0001f4c5xhd7bhjk	agent	ლკმნკჯ	human	\N	2026-05-28 07:53:30.555
cmpp7a8at00015mhq7yi366vp	cmpp6svmb0001f4c5xhd7bhjk	user	ჰაი	user	\N	2026-05-28 07:57:37.541
cmpp7aj1900035mhqbfz8loot	cmpp6svmb0001f4c5xhd7bhjk	agent	ასდ	human	\N	2026-05-28 07:57:51.454
cmpp7allk00055mhqz01eexj2	cmpp6svmb0001f4c5xhd7bhjk	user	ასდსად	user	\N	2026-05-28 07:57:54.776
cmpp7axcb00075mhqfo48trq3	cmpp6svmb0001f4c5xhd7bhjk	agent	სსსს	human	\N	2026-05-28 07:58:09.994
cmpp7azkg00095mhq050r48rd	cmpp6svmb0001f4c5xhd7bhjk	user	ააააა	user	\N	2026-05-28 07:58:12.881
cmpp7p7q00001111xxpua6prr	cmpp6svmb0001f4c5xhd7bhjk	system	✅ Conversation resolved	system	\N	2026-05-28 08:09:16.632
cmpp7pu4y0003111x61phk2s2	cmpp6svmb0001f4c5xhd7bhjk	user	ჰაი	user	\N	2026-05-28 08:09:45.683
cmpp7pv4l0005111x8bvjmcjo	cmpp6svmb0001f4c5xhd7bhjk	assistant	გამარჯობა! რით შემიძლია დაგეხმაროთ?	ai	\N	2026-05-28 08:09:46.965
cmpp7qt0d0007111x2sw7z1wt	cmpp6svmb0001f4c5xhd7bhjk	system	🔄 Customer requested a human agent	system	\N	2026-05-28 08:10:30.878
cmpp7qvey0009111xgd37eike	cmpp6svmb0001f4c5xhd7bhjk	system	🔄 Customer requested a human agent	system	\N	2026-05-28 08:10:33.994
cmpp7r49x000d111xq5hslf8w	cmpp6svmb0001f4c5xhd7bhjk	system	👤 Agent Demo Admin has joined the conversation	system	\N	2026-05-28 08:10:45.478
cmpp7r9pt000f111xetkxegnq	cmpp6svmb0001f4c5xhd7bhjk	agent	ასდ	human	\N	2026-05-28 08:10:52.529
cmpp7renx000h111x0jthf2qq	cmpp6svmb0001f4c5xhd7bhjk	agent	ასდსად	human	\N	2026-05-28 08:10:58.942
cmpp7ro0h000j111xl3vr9tyl	cmpp6svmb0001f4c5xhd7bhjk	user	ფგჰფგჰგფჰ	user	\N	2026-05-28 08:11:11.057
cmpp7sdre0001ezbotupfek7s	cmpp6svmb0001f4c5xhd7bhjk	user	ასდსდა	user	\N	2026-05-28 08:11:44.427
cmpp7shlj0003ezbo7xbghyph	cmpp6svmb0001f4c5xhd7bhjk	agent	ასდას	human	\N	2026-05-28 08:11:49.399
cmpp7sklr0005ezbofuy4u0j7	cmpp6svmb0001f4c5xhd7bhjk	user	სდფდსფ	user	\N	2026-05-28 08:11:53.295
cmpp7sxbr0007ezbom9a1xq35	cmpp6svmb0001f4c5xhd7bhjk	system	✅ Conversation resolved	system	\N	2026-05-28 08:12:09.784
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PasswordResetToken" (id, email, token, "expiresAt", used, "createdAt") FROM stdin;
cmpnkht7p0004hf9j0jh8djkq	admin@demo.com	0a046d36a8b17e5ebcfe6a4dea18788f744377fe53f0f8e630ffae8568020189	2026-05-27 05:31:53.891	t	2026-05-27 04:31:53.893
cmpnki4e10005hf9j9qcdxsu5	admin@demo.com	0b482c1f5a20d9738f89fd870e761b0063cb8567d864759046bccc1af58a927e	2026-05-27 05:32:08.376	t	2026-05-27 04:32:08.377
\.


--
-- Data for Name: PlatformSetting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PlatformSetting" (id, key, value) FROM stdin;
cmpn2kc4p0000856i7m01y82x	ai_provider	deepseek
cmpn2kc580001856ib0jky66s	ai_model	deepseek-chat
cmpn2kc5f0002856iodi33t12	ai_api_key	sk-e96bd41990f74b68b6919e828ea79220
cmpnli0270000bgn7tep7gq7r	smtp_host	smtp.mailgun.org
cmpnli0580001bgn7r1pufipy	smtp_port	587
cmpnli0820002bgn74h6o40rl	smtp_user	
cmpnli0880003bgn79xxxl18x	smtp_pass	
cmpnli08e0004bgn7k85hkxqm	smtp_from	noreply@benzos.uk
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "sessionToken", "userId", expires) FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, name, password, image, role, "companyId", active, "createdAt", "updatedAt") FROM stdin;
cmpn21mu00000105ostvsbm3l	admin@benzos.uk	Super Admin	$2b$10$J/mE0TsmmyvOwpSz/2t8ye1W8YGWsOYxkL37GtI/SRdT6/9SJ5tl.	\N	super_admin	\N	t	2026-05-26 19:55:26.04	2026-05-26 19:55:26.04
cmpn21mz20003105ol5l8xyjw	admin@demo.com	Demo Admin	$2b$12$8.JwdBDwhdibDBSir7K.g.6kMD4KxnInriGYl9VSVlMLTG4PQBdg.	\N	company_admin	cmpn21muo0001105o9aefgepi	t	2026-05-26 19:55:26.222	2026-05-27 04:32:14.404
cmpnkidsq0009hf9jz2htq7xg	test-subagent@example.com	Test Admin	$2b$12$7Jdp3jl89uSGAb6lqmN6n.71UCrYt6NeYcTkbsTIV0WzrF6zBSyXS	\N	company_admin	cmpnkidsk0007hf9ja8uxgeb2	t	2026-05-27 04:32:20.57	2026-05-27 04:32:20.57
cmpnyqwnx0001wutrystfl3fg	dachi@benzos.uk	Dachi	$2b$10$GEksl3lKHcxKX5Lzvye4fejQuXVLu0TWcCI7ROcKK7Rkk/UT9PgHW	\N	agent	cmpn21muo0001105o9aefgepi	t	2026-05-27 11:10:52.893	2026-05-27 11:10:52.893
\.


--
-- Data for Name: VerificationToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VerificationToken" (identifier, token, expires) FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
24d74487-2248-48e4-a28e-e0bfff9d5269	3882ac8add672d099b595a80e017e44d4a5fa11b65d387d33807912f0456f018	2026-05-26 19:54:44.907085+00	20260526195444_init	\N	\N	2026-05-26 19:54:44.570506+00	1
7de747b6-15e0-42ad-9dc6-fef4719c22db	d9f0f5d5422a0243ee63bff2c98285590758c8f8a46dd75cb45a46cc0220a94f	2026-05-26 20:09:06.551072+00	20260526200906_add_platform_settings	\N	\N	2026-05-26 20:09:06.512447+00	1
9acc0355-8009-4868-b8ca-40270f088b5d	70f5b1276513fa4d4aa2f485af06c5049c17b60be0c092960f52c97121036bd7	2026-05-27 04:22:15.710576+00	20260527042215_add_password_reset	\N	\N	2026-05-27 04:22:15.641089+00	1
\.


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: AgentChat AgentChat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AgentChat"
    ADD CONSTRAINT "AgentChat_pkey" PRIMARY KEY (id);


--
-- Name: BillingLog BillingLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BillingLog"
    ADD CONSTRAINT "BillingLog_pkey" PRIMARY KEY (id);


--
-- Name: Bot Bot_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Bot"
    ADD CONSTRAINT "Bot_pkey" PRIMARY KEY (id);


--
-- Name: ChatWidget ChatWidget_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatWidget"
    ADD CONSTRAINT "ChatWidget_pkey" PRIMARY KEY (id);


--
-- Name: Company Company_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Company"
    ADD CONSTRAINT "Company_pkey" PRIMARY KEY (id);


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeBase KnowledgeBase_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."KnowledgeBase"
    ADD CONSTRAINT "KnowledgeBase_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: PlatformSetting PlatformSetting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PlatformSetting"
    ADD CONSTRAINT "PlatformSetting_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Account_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Account_provider_providerAccountId_key" ON public."Account" USING btree (provider, "providerAccountId");


--
-- Name: AgentChat_agentId_conversationId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AgentChat_agentId_conversationId_key" ON public."AgentChat" USING btree ("agentId", "conversationId");


--
-- Name: ChatWidget_botId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ChatWidget_botId_key" ON public."ChatWidget" USING btree ("botId");


--
-- Name: ChatWidget_widgetCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ChatWidget_widgetCode_key" ON public."ChatWidget" USING btree ("widgetCode");


--
-- Name: Company_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Company_slug_key" ON public."Company" USING btree (slug);


--
-- Name: PasswordResetToken_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PasswordResetToken_email_idx" ON public."PasswordResetToken" USING btree (email);


--
-- Name: PasswordResetToken_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PasswordResetToken_token_idx" ON public."PasswordResetToken" USING btree (token);


--
-- Name: PasswordResetToken_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PasswordResetToken_token_key" ON public."PasswordResetToken" USING btree (token);


--
-- Name: PlatformSetting_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PlatformSetting_key_key" ON public."PlatformSetting" USING btree (key);


--
-- Name: Session_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Session_sessionToken_key" ON public."Session" USING btree ("sessionToken");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: VerificationToken_identifier_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "VerificationToken_identifier_token_key" ON public."VerificationToken" USING btree (identifier, token);


--
-- Name: VerificationToken_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "VerificationToken_token_key" ON public."VerificationToken" USING btree (token);


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentChat AgentChat_agentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AgentChat"
    ADD CONSTRAINT "AgentChat_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentChat AgentChat_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AgentChat"
    ADD CONSTRAINT "AgentChat_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BillingLog BillingLog_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BillingLog"
    ADD CONSTRAINT "BillingLog_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Bot Bot_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Bot"
    ADD CONSTRAINT "Bot_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatWidget ChatWidget_botId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatWidget"
    ADD CONSTRAINT "ChatWidget_botId_fkey" FOREIGN KEY ("botId") REFERENCES public."Bot"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatWidget ChatWidget_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatWidget"
    ADD CONSTRAINT "ChatWidget_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Conversation Conversation_botId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_botId_fkey" FOREIGN KEY ("botId") REFERENCES public."Bot"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Conversation Conversation_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KnowledgeBase KnowledgeBase_botId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."KnowledgeBase"
    ADD CONSTRAINT "KnowledgeBase_botId_fkey" FOREIGN KEY ("botId") REFERENCES public."Bot"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KnowledgeBase KnowledgeBase_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."KnowledgeBase"
    ADD CONSTRAINT "KnowledgeBase_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict ccY4hWoKNeLPjmBBhMqkTbGCbr7O1jUTC2C1c8UH8Dv6qsiJoqe57pHpXNfi9u3

