# BotForge — Full Restoration Guide
> Backup created: 2026-05-28 10:14 CET
> Live at: https://chat.benzos.uk

## What's in this backup

| File | Contents |
|------|----------|
| `botforge-src.tar.gz` | Full source code (excl node_modules, .next, .git) |
| `botforge-db.sql` | PostgreSQL database dump (schema + data) |
| `schema.prisma` | Prisma schema (DB structure) |
| `migrations/` | Prisma migration history |
| `package.json` | Dependencies & scripts |
| `package-lock.json` | Locked dependency versions |
| `.env` | Environment variables (DB, NextAuth) |
| `nginx-chat.benzos.uk.conf` | Nginx reverse proxy config |
| `pm2-botforge.txt` | PM2 process info |
| `tsconfig.json` | TypeScript config |
| `next.config.ts` | Next.js config |
| `postcss.config.mjs` | PostCSS config |

## Restore Instructions

### 1. Extract Source Code
```bash
mkdir -p /root/.openclaw/workspace/botforge
cd /root/.openclaw/workspace/botforge
tar xzf ../botforge-backup/botforge-src.tar.gz
```

### 2. Install Dependencies
```bash
cd /root/.openclaw/workspace/botforge
npm install
```

### 3. Restore Environment
```bash
cp botforge-backup/.env.bak /root/.openclaw/workspace/botforge/.env
# Edit .env if needed (DB host/port changes)
```

### 4. Restore Database

The database runs in a Docker PostgreSQL container:

```bash
# Start PostgreSQL if not running
docker run -d --name botforge-db \
  -e POSTGRES_USER=hr_user \
  -e POSTGRES_PASSWORD=hr_pass \
  -e POSTGRES_DB=botforge \
  -p 5432:5432 \
  postgres:16-alpine

# Restore from dump
export PGPASSWORD=hr_pass
psql -h localhost -U hr_user -d botforge < botforge-backup/botforge-db.sql
```

If you need a fresh database with just the schema:
```bash
# Prisma migrate instead
cd /root/.openclaw/workspace/botforge
npx prisma migrate deploy
npx prisma db seed  # if seed script exists
```

### 5. Restore Nginx Config
```bash
cp botforge-backup/nginx-chat.benzos.uk.conf /etc/nginx/sites-available/chat.benzos.uk
ln -sf /etc/nginx/sites-available/chat.benzos.uk /etc/nginx/sites-enabled/
nginx -t && nginx -s reload
```

### 6. Build & Start
```bash
cd /root/.openclaw/workspace/botforge
npm run build
pm2 start npm --name botforge -- start
```

### 7. Verify
```bash
curl -s -o /dev/null -w "%{http_code}" https://chat.benzos.uk
# Should return 200
```

## Key Architecture Notes

**Stack:** Next.js 14, TypeScript, Tailwind CSS v3, Prisma 5, PostgreSQL, NextAuth v5
**Port:** 3001 (Next.js dev), PM2 on port 3001
**Domain:** chat.benzos.uk → nginx proxy → localhost:3001
**Auth:** NextAuth + JWT (2 roles: super_admin, company_admin)

### SSE Endpoints
- `GET /api/sse/[conversationId]` — Widget SSE stream
- `POST /api/handoff` — Handoff lifecycle (request/join/message/resolve)
- `GET /api/handoff/status` — Poll handoff status

### Critical Nginx Settings for SSE
```
proxy_buffering off;
proxy_read_timeout 86400s;
``` 

## Related Services

| Service | URL | Location |
|---------|-----|----------|
| BotForge | https://chat.benzos.uk | PM2 botforge |
| Digital Signage | https://benzos.uk | Gunicorn on 8000 |
| Feedback | https://feedback. | PM2 feedback |
| Karcher HR | https://hr.benzos.uk | PM2 karcher-hr |

## Database Connection
- Host: localhost:5432
- User: hr_user
- Password: hr_pass
- Database: botforge
- Schema: public
